START /WAIT "TC_SRL" "C:\toolbase\pdt_toolchain\1v75.1\ToolChain.exe"  -S "|C:\temp\PDT\JAP\MDG1\Prerun_Toolchain\PreRun\MG1CA020\WF221490\P_Run_TC_Prerun_D2P.xml|"

