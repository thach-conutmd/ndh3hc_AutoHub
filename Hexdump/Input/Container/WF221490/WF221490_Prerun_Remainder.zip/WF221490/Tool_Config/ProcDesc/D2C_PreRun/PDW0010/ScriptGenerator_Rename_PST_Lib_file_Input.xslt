 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="AddressModelFile"  select="concat($WorkingDir, '\AddressModel.xml')" />
<xsl:variable name="InfotableLogFile"  select="concat($WorkingDir, '\InfotableLog.xml')" />

<xsl:template match="/">

    <ToolInput>
    <Mode> Prepare Scripts </Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>		
			<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>SCRIPT_RENAME_PST_LIB_FILE</Key>
				<Comment>Script for reading BootCtrl version</Comment>
				<ScriptTemplate>
				  <xsl:call-template name="GetEnvironmentValue">
				    <xsl:with-param name="LookUpItem" select="'SCRIPT_RENAME_PST_LIB_FILE'"/>
				  </xsl:call-template>
				</ScriptTemplate>
				<DataBase>
				  <Datas>
				 <WORKING_DIRECTORY><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WORKING_DIRECTORY>
				 <PST_LIB_NAME><xsl:call-template name="GetContainerName_PST_Lib"/></PST_LIB_NAME>
				  </Datas>
				</DataBase>
			</Script>
		</Scripts>
		<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
