<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 

    <xsl:template match="/">
    
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<ResultingFiles>
			<File>
						<FileClassID>PST_LIB_FILE</FileClassID>
						<FileClassName>PST_LIB_FILE</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								 <xsl:variable name="srcFileName">
								<xsl:call-template name="RunTime_FileList_GetFileName">
								  <xsl:with-param name="FileClassID" select="'SourceLibraryFile'"/>
								  <xsl:with-param name="GetValue" select="'yes'"/>
								</xsl:call-template>
							  </xsl:variable>
							  <xsl:variable name="prefix" select="'LIB_TOOLCHAIN_'"/>
							  <xsl:variable name="restOfName" select="substring-after($srcFileName, $prefix)"/>
							  <xsl:variable name="containerName">
								<xsl:call-template name="GetContainerName_PST_Lib"/>
							  </xsl:variable>
							  <xsl:value-of select="concat($prefix, $containerName, '_', $restOfName)"/>
							</Name>
						</Location>
					</File>

    		</ResultingFiles>    		 		   		
		</Output>
		<ReturnInformation>
			<ReturnCode></ReturnCode>
			<TimeStart></TimeStart>
			<TimeFinish></TimeFinish>
			<ErrorInformation>
				<ErrorNumber/>
				<ErrorMessage/>
			</ErrorInformation>
		</ReturnInformation>   
	 		
	</ToolOutput> 
 
    </xsl:template>
</xsl:stylesheet>
