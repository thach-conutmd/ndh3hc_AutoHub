<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">      
	<xsl:output method="xml" omit-xml-declaration='yes' cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!--
		Main Idea: Walk through the toolchain's data step by step. Copy each node using default-rules.
		Some parts of the toolchain's data can be overwritten without any knowledge about the internal
		structure.
		For each part there exist two variables:
		- The first has to be used by the calling stylesheet. It is prefixed by either "UC" (UseCase)
		  or "RT" (RunTime). It is initialized empty in this basic library. A calling stylesheet can
		  overwrite this initial value.
		- Correspondig to this externally used variable we have an internal reference. It is prefixed 
		  "REF" and contains an XPATH. This XPATH describes the part to be replaced.	
	    On principle it is assumed that in the toolchain's data the part to be overwritten already exists
	    It may be empty but it should exist. Occasionally it could be possible to newly introduce data.
	  
	    The Stylesheet calling this library only has 
		- to provide XPATHs for the variables mentioned abobve to be used for extracting data from the 
		  tool output 
		It is not necessary to call any template. This is done within the library.				
  -->
  
	<!-- Path to the toolchain's data file                        -->
	<xsl:variable name="UseCaseXML" select="''" />
	<!-- Variables to be used by the calling stylesheet(s)    -->
<xsl:variable name="RT_PST_LIB_FILE_NAME" select="''"/>
<xsl:variable name="RT_PST_Folder" select="''"/>
<xsl:variable name="RT_ULF_FILE" select="''"/>
<xsl:variable name="RT_LST_FILE" select="''"/>
<xsl:variable name="RT_SCAN_LST_FLAG" select="''"/>	
<xsl:variable name="RT_APPLICATION_FILESLIST" select="''"/>	
<xsl:variable name="RT_SSD_COMPLIANCE_CHECK" select="''"/> 
<xsl:variable name="RT_SSD_COMPLIANCE_REFERENCE" select="''"/>
<xsl:variable name="RT_SSD_COMPLIANCE_A2L" select="''"/>
<xsl:variable name="RT_A2L_File" select="''"/>
<xsl:variable name="RT_A2L_FILE_MASTER" select="''"/>
<xsl:variable name="RT_SSD_COMPLIANCE_A2L_ERROR" select="''"/> 
<xsl:variable name="RT_SSD_COMPLIANCE_LABEL_COUNT_A2L" select="''"/>
<xsl:variable name="RT_SSD_COMPLIANCE_LABEL_FAILURE_COUNT" select="''"/>
<xsl:variable name="RT_SSD_COMPLIANCE_CHECK_ERROR" select="''"/>
<xsl:variable name="RT_PRERUN_EXPORT_XML" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_1" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_2" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_3" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_4" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_5" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_6" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_7" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_8" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_9" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_10" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_11" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_12" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_13" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_14" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_15" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_16" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_17" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_18" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_19" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_20" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_21" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_22" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_23" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_24" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_25" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_26" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_27" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_28" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_29" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_30" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_31" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_32" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_33" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_34" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_35" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_36" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_37" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_38" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_39" select="''"/>
<xsl:variable name="RT_APPLIEDFILE_40" select="''"/>
<!-- <xsl:variable name="RT_CRITICAL_DATA_ACCESS_LST" select="''"/>
<xsl:variable name="RT_CRITICAL_DATA_ACCESS_ULF" select="''"/> -->
<xsl:variable name="RT_RESIZED_APPLIEDFILES" select="''"/>

<xsl:variable name="RT_BIN_File" select="''"/>
  <xsl:variable name="RT_VBF" select="''"/>
  <xsl:variable name="RT_VBF_Header_File" select="''"/>
  <xsl:variable name="RT_Converted_VBF_File" select="''"/>
  <xsl:variable name="RT_VBF_FILE_Checksum" select="''"/>
  <xsl:variable name="RT_BIN_Checksum" select="''"/>
  <xsl:variable name="RT_BIN_Checksum_Value" select="''"/>
  <xsl:variable name="RT_AppliedFile_Extension" select="''"/>
  
  <xsl:variable name="RT_ReadMatrixInfo_SRVChecker" select="''" />
  <xsl:variable name="RT_ReadMatrixInfo_SSDCheckCompliance" select="''" />
<xsl:variable name="RT_SRVCHECKER_ERROR" select="''"/>
	<xsl:variable name="RT_SRVCHECKER_PVER_LABEL_COUNT" select="''"/>
	<xsl:variable name="RT_SRVCHECKER_AFFECTED_LABEL_COUNT" select="''"/>
	<xsl:variable name="RT_Tools" select="''" />
	
	<xsl:variable name="RT_DECRYPT_BIN_File" select="''"/>
	<xsl:variable name="RT_BIN_TO_HEX_CONVERSION" select="''"/>
	<xsl:variable name="RT_CHECKSUM_VALIDATION" select="''"/>
	<xsl:variable name="RT_BIN_TO_HEX" select="''"/>
	<xsl:variable name="RT_SRVChecker_LatestToolVersion" select="''"/>
	
	<xsl:variable name="RT_SRVCheckerTool" select="''"/>
	<xsl:variable name="RT_SRVChecker_PVERToolVersion" select="''"/>
	<xsl:variable name="RT_PVER_SCAN" select="''" />
	<xsl:variable name="RT_ECUSECU_FLAG" select="''" />
	
	<xsl:variable name="RT_AlternateA2L_File" select="''" />
	<xsl:variable name="RT_A2L_FILE_FLAG" select="''"/>	
	<xsl:variable name="RT_BUGGY_SCAN_LST" select="''" />
	<xsl:variable name="RT_FILE" select="''" />
		<xsl:variable name="RT_RUNTIME_FILE" select="''" />
		<!-- <xsl:variable name="RT_SSD_SRV_A2L_File" select="''" /> -->
		<!-- <xsl:variable name="RT_SSD_A2L_File" select="''" />
		<xsl:variable name="RT_SRV_A2L_File" select="''" /> -->
		
		<xsl:variable name="RT_SSD_A2L_File" select="''"/>
		<xsl:variable name="RT_SRV_A2L_File" select="''"/>
		<xsl:variable name="RT_ECU_SECU_FILE" select="''"/>
		<xsl:variable name="RT_PVER_PATH" select="''"/>
		<xsl:variable name="RT_FIND_SECURITY_INFO" select="''"/>
		<xsl:variable name="RT_ECUSECU_VERSION" select="''"/>	
		<xsl:variable name="RT_ECUSECU_AESKEYS_ARXML" select="''"/>
		<xsl:variable name="RT_VALID_SECURITY_VERSION" select="''"/>	
		<xsl:variable name="RT_MESSAGE" select="''"/>	
	
	 <xsl:variable name="RT_HexMod_BootCtrl_Version_Xml" select="''"/>
	<xsl:variable name="RT_XADDRESS" select="''"/>
	<xsl:variable name="RT_MODE_TYPE" select="''"/>
	<xsl:variable name="RT_BOOTCTRL_VERSION" select="''"/>	
	 <xsl:variable name="RT_Toworkflow_Data_To_Usecase" select="''"/>
	<xsl:variable name="RT_BootCtrlVersion_Hex" select="''" />
	<xsl:variable name="RT_MergedConfig_ModeType_XPATH" select="''" />
	<xsl:variable name="RT_GUAM_FLAG" select="''"/>
	<xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="''"/>
	<xsl:variable name="RT_BOOTCTRL_HEX" select="''"/>
	<xsl:variable name="RT_MDG_Type" select="''"/>	
	
	
<xsl:variable name="Ref_SSD_COMPLIANCE_CHECK" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_CHECK']/tctypes:Location" />
<xsl:variable name="Ref_SSD_COMPLIANCE_REFERENCE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_REFERENCE']/tctypes:Location" />
<xsl:variable name="Ref_SSD_COMPLIANCE_A2L" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_A2L']/tctypes:Location" />
<xsl:variable name="Ref_A2L_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='A2L_FILE']/tctypes:Location" />
<xsl:variable name="Ref_PRERUN_EXPORT_XML" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='PRERUN_EXPORT_XML']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_1']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_2" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_2']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_3" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_3']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_4" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_4']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_5" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_5']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_6" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_6']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_7" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_7']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_8" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_8']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_9" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_9']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_10" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_10']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_11" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_11']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_12" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_12']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_13" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_13']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_14" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_14']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_15" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_15']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_16" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_16']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_17" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_17']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_18" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_18']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_19" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_19']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_20" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_20']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_21" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_21']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_22" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_22']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_23" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_23']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_24" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_24']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_25" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_25']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_26" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_26']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_27" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_27']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_28" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_28']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_29" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_29']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_30" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_30']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_31" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_31']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_32" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_32']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_33" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_33']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_34" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_34']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_35" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_35']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_36" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_36']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_37" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_37']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_38" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_38']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_39" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_39']/tctypes:Location" />
<xsl:variable name="Ref_APPLIEDFILE_40" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='APPLIEDFILE_40']/tctypes:Location" />

<xsl:variable name="Ref_SSD_COMPLIANCE_LABEL_COUNT_A2L" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_LABEL_COUNT_A2L']/tctypes:Value"/>
<xsl:variable name="Ref_SSD_COMPLIANCE_A2L_ERROR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_A2L_ERROR']/tctypes:Value"/>
<xsl:variable name="Ref_SSD_COMPLIANCE_LABEL_FAILURE_COUNT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_LABEL_FAILURE_COUNT']/tctypes:Value"/>
<xsl:variable name="Ref_SSD_COMPLIANCE_CHECK_ERROR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_CHECK_ERROR']/tctypes:Value"/>
<xsl:variable name="Ref_APPLICATION_FILESLIST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HEX_FILE_LIST']/tctypes:Location" />
<xsl:variable name="Ref_SCAN_LST_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SCAN_LST_FLAG']/tctypes:Value"/>
<!--<xsl:variable name="Ref_CRITICAL_DATA_ACCESS_LST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CRITICAL_DATA_ACCESS_LST']/tctypes:Location" />
<xsl:variable name="Ref_CRITICAL_DATA_ACCESS_ULF" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CRITICAL_DATA_ACCESS_ULF']/tctypes:Location" />-->
<xsl:variable name="Ref_RESIZED_APPLIEDFILES" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RESIZED_APPLIEDFILES']/tctypes:Location" />
<xsl:variable name="Ref_PST_Folder" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Root_PST_Folder']/tctypes:Value"/>
<xsl:variable name="Ref_ULF_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CRITICAL_DATA_ACCESS_ULF']/tctypes:Location" />
<xsl:variable name="Ref_LST_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CRITICAL_DATA_ACCESS_LST']/tctypes:Location" />
<xsl:variable name="Ref_A2L_FILE_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='A2L_FILE_FLAG']/tctypes:Value"/>
 <xsl:variable name="Ref_BIN_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BIN_File']/tctypes:Location"/>
 <xsl:variable name="Ref_VBF" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VBF_DataBlock_Info']/tctypes:VBF"/>
 <xsl:variable name="Ref_VBF_Header_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='VBF_Header_File_Checksum']/tctypes:Location"/>
 <xsl:variable name="Ref_Converted_VBF_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Converted_VBF_File']/tctypes:Location"/>
 <xsl:variable name="Ref_VBF_FILE_Checksum" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VBF_File_Checksum']/tctypes:Value"/>
 <xsl:variable name="Ref_BIN_Checksum" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BIN_checksum_file']/tctypes:Location"/>  
 <xsl:variable name="Ref_BIN_Checksum_Value" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BIN_File_Checksum']/tctypes:Value"/>  
  <!-- <xsl:variable name="Ref_AppliedFile_Extension" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='AppliedFile_Extension']/tctypes:Value"/> -->
  
  <xsl:variable name="Ref_ReadMatrixInfo_SRVChecker" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:ToolRunSRVChecker"/>
<xsl:variable name="Ref_ReadMatrixInfo_SSDCheckCompliance" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:ToolRunSSDCheckCompliance"/>
<xsl:variable name="Ref_PVER_SCAN" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SRVChecker_PVER_Scan"/>
<xsl:variable name="Ref_ECUSECU_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:ECUSECU_FLAG"/>
<xsl:variable name="Ref_AppliedFile_Extension" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:AppliedFile_Extension"/>
<xsl:variable name="Ref_AlternateA2L_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:AlternateA2L"/>
<!-- <xsl:variable name="Ref_SSD_SRV_A2L_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SSD_SRV_A2L"/> -->
<xsl:variable name="Ref_SSD_A2L_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SSD_A2L"/>
<xsl:variable name="Ref_SRV_A2L_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SRV_A2L"/>
  
  <xsl:variable name="Ref_SRVCHECKER_PVER_LABEL_COUNT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SRVCHECKER_PVER_LABEL_COUNT']/tctypes:Value"/>  
  <xsl:variable name="Ref_SRVCHECKER_ERROR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SRVCHECKER_ERROR']/tctypes:Value"/>  
  <xsl:variable name="Ref_SRVCHECKER_AFFECTED_LABEL_COUNT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SRVCHECKER_AFFECTED_LABEL_COUNT']/tctypes:Value"/>  
  <!-- <xsl:variable name="Ref_ReadMatrixInfo_SRCVChecker" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ToolRunSRCVChecker']/tctypes:Value"/> -->
<!-- <xsl:variable name="Ref_ReadMatrixInfo_SSDCheckCompliance" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ToolRunSSDCheckCompliance']/tctypes:Value"/> -->
<xsl:variable name="Ref_Tools" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools" />
<xsl:variable name="Ref_DECRYPT_BIN_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BIN_DECRYPTED']/tctypes:Location"/>
<xsl:variable name="Ref_BIN_TO_HEX_CONVERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Script_BIN_TO_HEX_CONVERSION']/tctypes:Value"/>
<xsl:variable name="Ref_CHECKSUM_VALIDATION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Script_CHECKSUM_VALIDATION']/tctypes:Value"/>

<xsl:variable name="Ref_BIN_TO_HEX" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BIN_TO_HEX']/tctypes:Location"/>
<xsl:variable name="Ref_SRVChecker_LatestToolVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SRVChecker_LatestToolVersion']/tctypes:Value"/>
<xsl:variable name="Ref_SRVChecker_PVERToolVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SRVCHECKER_PVER_TOOLVERSION']/tctypes:Value"/>

<xsl:variable name="Ref_SRVCheckerTool" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SRVCHECKER_TOOL']/tctypes:Location" />
<xsl:variable name="Ref_A2L_FILE_MASTER" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='A2L_FILE_MASTER']/tctypes:Location" />
<xsl:variable name="Ref_BUGGY_SCAN_LST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SRVChecker_Buggy_Scan_LST"/>
<xsl:variable name="Ref_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files" />
<xsl:variable name="Ref_ECU_SECU_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:ECUSECU_FILE"/>
<xsl:variable name="Ref_PVER_PATH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:PVER_PATH_FOR_TOOL_RUN"/>
<xsl:variable name="Ref_FIND_SECURITY_INFO" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:FindSecurityInformation"/>
<xsl:variable name="Ref_ECUSECU_VERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ECUSECU_VERSION']/tctypes:Value"/>
<xsl:variable name="Ref_ECUSECU_AESKEYS_ARXML" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ECUSECU_AESKEYS_ARXML']/tctypes:Location" />
<xsl:variable name="Ref_VALID_SECURITY_VERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='IS_SECURITY_VERSION_VALID']/tctypes:Value"/>
<xsl:variable name="Ref_MESSAGE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SECURITY_VERSION_MAIL_MESSAGE']/tctypes:Value"/>

<xsl:variable name="Ref_HexMod_BootCtrl_Version_Xml" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexmodX_BootCtrl_Version_xml']/tctypes:Location"/>

<xsl:variable name="Ref_XADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='XADDRESS']/tctypes:Value"/>

<xsl:variable name="Ref_MODE_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='MODETYPE']/tctypes:Value"/>
<xsl:variable name="Ref_BOOTCTRL_VERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BOOTCTRL_VERSION']/tctypes:Value"/>
<xsl:variable name="Ref_MDG_Type" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:MDG_Type"/>
<xsl:variable name="Ref_Toworkflow_Data_To_Usecase" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas"/>
<xsl:variable name="Ref_BootCtrlVersion_Hex" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:BOOTCRL_VERSION_HEX"/>
<xsl:variable name="Ref_MergedConfig_ModeType_XPATH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='MergedConfig_ModeType_XPATH']/tctypes:Value"/>
<xsl:variable name="Ref_GUAM_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:GUAM_FLAG"/>
<xsl:variable name="Ref_CFGEXP_MACHINE_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_MACHINE_TYPE']/tctypes:Value"/>
<xsl:variable name="Ref_BOOTCTRL_HEX" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BOOTCTRL_HEX']/tctypes:Location"/>
<xsl:variable name="Ref_PST_LIB_FILE_NAME" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PST_LIB_FILE_NAME']/tctypes:Value"/>  


   <!-- Starting point -->
<xsl:template match="/">
	<xsl:call-template name="WriteBack" />
</xsl:template>
<!-- The initial template. Starts processing of the toolcahin's data -->
<xsl:template name="WriteBack">
	<xsl:apply-templates select="document($UseCaseXML)/*" />
</xsl:template>
<!-- recurcively step throug the toolchain's data -->
<xsl:template match="*">
	<xsl:choose>			
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_CHECK)=1 and $RT_SSD_COMPLIANCE_CHECK">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_SSD_COMPLIANCE_CHECK/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_REFERENCE)=1 and $RT_SSD_COMPLIANCE_REFERENCE">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_SSD_COMPLIANCE_REFERENCE/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_A2L)=1 and $RT_SSD_COMPLIANCE_A2L">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_SSD_COMPLIANCE_A2L/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_A2L_File)=1 and $RT_A2L_File">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_A2L_File/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_LABEL_COUNT_A2L)=1 and $RT_SSD_COMPLIANCE_LABEL_COUNT_A2L">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SSD_COMPLIANCE_LABEL_COUNT_A2L"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_LABEL_FAILURE_COUNT)=1 and $RT_SSD_COMPLIANCE_LABEL_FAILURE_COUNT">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SSD_COMPLIANCE_LABEL_FAILURE_COUNT"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_CHECK_ERROR)=1 and $RT_SSD_COMPLIANCE_CHECK_ERROR">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SSD_COMPLIANCE_CHECK_ERROR"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_PST_Folder)=1 and $RT_PST_Folder">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_PST_Folder"/>
			</xsl:element>
		</xsl:when>
		
		
		
		<xsl:when test="count(. | $Ref_SSD_COMPLIANCE_A2L_ERROR)=1 and $RT_SSD_COMPLIANCE_A2L_ERROR">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SSD_COMPLIANCE_A2L_ERROR"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_ECUSECU_AESKEYS_ARXML)=1 and $RT_ECUSECU_AESKEYS_ARXML">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_ECUSECU_AESKEYS_ARXML/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_APPLIEDFILE_1)=1 and $RT_APPLIEDFILE_1">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_1/*" />
			</xsl:element>
		</xsl:when>
					
		<xsl:when test="count(. | $Ref_PRERUN_EXPORT_XML)=1 and $RT_PRERUN_EXPORT_XML">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_PRERUN_EXPORT_XML/*" />
			</xsl:element>
		</xsl:when>
					
		<xsl:when test="count(. | $Ref_APPLIEDFILE_2)=1 and $RT_APPLIEDFILE_2">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_2/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_APPLIEDFILE_3)=1 and $RT_APPLIEDFILE_3">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_3/*" />
			</xsl:element>
		</xsl:when>
			
		<xsl:when test="count(. | $Ref_APPLIEDFILE_4)=1 and $RT_APPLIEDFILE_4">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_4/*" />
			</xsl:element>
		</xsl:when>
			
		<xsl:when test="count(. | $Ref_APPLIEDFILE_5)=1 and $RT_APPLIEDFILE_5">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_5/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_APPLIEDFILE_6)=1 and $RT_APPLIEDFILE_6">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_6/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_7)=1 and $RT_APPLIEDFILE_7">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_7/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_8)=1 and $RT_APPLIEDFILE_8">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_8/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_9)=1 and $RT_APPLIEDFILE_9">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_9/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_10)=1 and $RT_APPLIEDFILE_10">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_10/*" />
			</xsl:element>
		</xsl:when>
		  <xsl:when test="count(. | $Ref_APPLIEDFILE_11)=1 and $RT_APPLIEDFILE_11">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_APPLIEDFILE_11/*" />
      </xsl:element>
    </xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_12)=1 and $RT_APPLIEDFILE_12">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_12/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_13)=1 and $RT_APPLIEDFILE_13">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_13/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_14)=1 and $RT_APPLIEDFILE_14">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_14/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_15)=1 and $RT_APPLIEDFILE_15">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_15/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_16)=1 and $RT_APPLIEDFILE_16">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_16/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_17)=1 and $RT_APPLIEDFILE_17">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_17/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_18)=1 and $RT_APPLIEDFILE_18">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_18/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_19)=1 and $RT_APPLIEDFILE_19">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_19/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_20)=1 and $RT_APPLIEDFILE_20">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_20/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_21)=1 and $RT_APPLIEDFILE_21">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_21/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_22)=1 and $RT_APPLIEDFILE_22">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_22/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_23)=1 and $RT_APPLIEDFILE_23">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_23/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_24)=1 and $RT_APPLIEDFILE_24">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_24/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_25)=1 and $RT_APPLIEDFILE_25">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_25/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_26)=1 and $RT_APPLIEDFILE_26">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_26/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_27)=1 and $RT_APPLIEDFILE_27">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_27/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_30)=1 and $RT_APPLIEDFILE_30">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_30/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_28)=1 and $RT_APPLIEDFILE_28">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_28/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_29)=1 and $RT_APPLIEDFILE_29">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_29/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_APPLIEDFILE_31)=1 and $RT_APPLIEDFILE_31">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_31/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_32)=1 and $RT_APPLIEDFILE_32">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_32/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_33)=1 and $RT_APPLIEDFILE_33">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_33/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_34)=1 and $RT_APPLIEDFILE_34">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_34/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_35)=1 and $RT_APPLIEDFILE_35">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_35/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_36)=1 and $RT_APPLIEDFILE_36">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_36/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_37)=1 and $RT_APPLIEDFILE_37">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_37/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_38)=1 and $RT_APPLIEDFILE_38">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_38/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_39)=1 and $RT_APPLIEDFILE_39">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_39/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_APPLIEDFILE_40)=1 and $RT_APPLIEDFILE_40">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLIEDFILE_40/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_APPLICATION_FILESLIST)=1 and $RT_APPLICATION_FILESLIST">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_APPLICATION_FILESLIST/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SCAN_LST_FLAG)=1 and $RT_SCAN_LST_FLAG">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SCAN_LST_FLAG"/>
			</xsl:element>
		</xsl:when>
		
		<!-- <xsl:when test="count(. | $Ref_CRITICAL_DATA_ACCESS_LST)=1 and $RT_CRITICAL_DATA_ACCESS_LST">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_CRITICAL_DATA_ACCESS_LST/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_CRITICAL_DATA_ACCESS_ULF)=1 and $RT_CRITICAL_DATA_ACCESS_ULF">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_CRITICAL_DATA_ACCESS_ULF/*" />
			</xsl:element>
		</xsl:when> -->
		<xsl:when test="count(. | $Ref_RESIZED_APPLIEDFILES)=1 and $RT_RESIZED_APPLIEDFILES">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_RESIZED_APPLIEDFILES/*" />
			</xsl:element>
		</xsl:when>
		
			<xsl:when test="count(. | $Ref_ULF_FILE)=1 and $RT_ULF_FILE">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_ULF_FILE/*" />
			</xsl:element>
		</xsl:when>
		
					<xsl:when test="count(. | $Ref_SRVCheckerTool)=1 and $RT_SRVCheckerTool">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_SRVCheckerTool/*" />
			</xsl:element>
		</xsl:when>
		
		
		
			<xsl:when test="count(. | $Ref_LST_FILE)=1 and $RT_LST_FILE">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_LST_FILE/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_BIN_File)=1 and $RT_BIN_File">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_BIN_File/*"/>
			</xsl:element>
		</xsl:when>

    <xsl:when test="count(. | $Ref_VBF)=1 and $RT_VBF">
      <xsl:element name="VBF">
        <xsl:copy-of select="$RT_VBF/*"/>
      </xsl:element>
    </xsl:when>
		
		
		<xsl:when test="count(. | $Ref_VBF_Header_File)=1 and $RT_VBF_Header_File">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_VBF_Header_File/*"/>
      </xsl:element>
    </xsl:when>
	 <xsl:when test="count(. | $Ref_Converted_VBF_File)=1 and $RT_Converted_VBF_File">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_Converted_VBF_File/*"/>
      </xsl:element>      
    </xsl:when>
	 <xsl:when test="count(. | $Ref_VBF_FILE_Checksum)=1 and $RT_VBF_FILE_Checksum">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_VBF_FILE_Checksum"/>
      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_BIN_Checksum)=1 and $RT_BIN_Checksum">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_BIN_Checksum/*"/>
      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_BIN_Checksum_Value)=1 and $RT_BIN_Checksum_Value">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_BIN_Checksum_Value"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_AppliedFile_Extension)=1 and $RT_AppliedFile_Extension">
				<xsl:element name="AppliedFile_Extension">
				<xsl:value-of select="$RT_AppliedFile_Extension"/>
			</xsl:element>
		</xsl:when>	
		
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_SRVChecker)=1 and $RT_ReadMatrixInfo_SRVChecker">
			   <xsl:element name="ToolRunSRVChecker">
			     <xsl:value-of select="$RT_ReadMatrixInfo_SRVChecker" />
			   </xsl:element>
			</xsl:when>

			 
			<xsl:when test="count(. | $Ref_ReadMatrixInfo_SSDCheckCompliance)=1 and $RT_ReadMatrixInfo_SSDCheckCompliance">
			   <xsl:element name="ToolRunSSDCheckCompliance">
			     <xsl:value-of select="$RT_ReadMatrixInfo_SSDCheckCompliance" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_SRVCHECKER_ERROR)=1 and $RT_SRVCHECKER_ERROR">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_SRVCHECKER_ERROR"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_PST_LIB_FILE_NAME)=1 and $RT_PST_LIB_FILE_NAME">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_PST_LIB_FILE_NAME"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_SRVCHECKER_PVER_LABEL_COUNT)=1 and $RT_SRVCHECKER_PVER_LABEL_COUNT">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_SRVCHECKER_PVER_LABEL_COUNT"/>
      </xsl:element>
    </xsl:when>
	
		<xsl:when test="count(. | $Ref_SRVCHECKER_AFFECTED_LABEL_COUNT)=1 and $RT_SRVCHECKER_AFFECTED_LABEL_COUNT">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_SRVCHECKER_AFFECTED_LABEL_COUNT"/>
      </xsl:element>
    </xsl:when>
	
			<xsl:when test="count(. | $Ref_Tools)=1 and $RT_Tools">
			<xsl:element name="Tools">
				<xsl:copy-of select="$RT_Tools/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_DECRYPT_BIN_File)=1 and $RT_DECRYPT_BIN_File">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_DECRYPT_BIN_File/*"/>
			</xsl:element>
		</xsl:when>
		

		
		<xsl:when test="count(. | $Ref_CHECKSUM_VALIDATION)=1 and $RT_CHECKSUM_VALIDATION">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_CHECKSUM_VALIDATION"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_BIN_TO_HEX_CONVERSION)=1 and $RT_BIN_TO_HEX_CONVERSION">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_BIN_TO_HEX_CONVERSION"/>
			</xsl:element>
		</xsl:when>	
		
		<xsl:when test="count(. | $Ref_BIN_TO_HEX)=1 and $RT_BIN_TO_HEX">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_BIN_TO_HEX/*"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SRVChecker_LatestToolVersion)=1 and $RT_SRVChecker_LatestToolVersion">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_SRVChecker_LatestToolVersion"/>
		</xsl:element>
	</xsl:when>
		<xsl:when test="count(. | $Ref_SRVChecker_PVERToolVersion)=1 and $RT_SRVChecker_PVERToolVersion">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_SRVChecker_PVERToolVersion"/>
		</xsl:element>
	</xsl:when>
		
		<xsl:when test="count(. | $Ref_PVER_SCAN)=1 and $RT_PVER_SCAN">
			   <xsl:element name="SRVChecker_PVER_Scan">
			     <xsl:value-of select="$RT_PVER_SCAN" />
			   </xsl:element>
			</xsl:when>

		<xsl:when test="count(. | $Ref_AlternateA2L_File)=1 and $RT_AlternateA2L_File">
			   <xsl:element name="AlternateA2L">
			     <xsl:value-of select="$RT_AlternateA2L_File" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_A2L_FILE_FLAG)=1 and $RT_A2L_FILE_FLAG">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_A2L_FILE_FLAG"/>
			</xsl:element>
		</xsl:when>
	
	<xsl:when test="count(. | $Ref_A2L_FILE_MASTER)=1 and $RT_A2L_FILE_MASTER">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_A2L_FILE_MASTER/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_BUGGY_SCAN_LST)=1 and $RT_BUGGY_SCAN_LST">
			   <xsl:element name="SRVChecker_Buggy_Scan_LST">
			     <xsl:value-of select="$RT_BUGGY_SCAN_LST" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_FILE)=1 and $RT_FILE">			
			      <!-- <xsl:copy-of select="$RT_RUNTIME_FILE/*" /> -->
				 <!-- <xsl:element name="Files"> -->
			     <xsl:copy-of select="$RT_FILE/*" />
				 <!-- </xsl:element> -->
			</xsl:when>
			
		<!-- <xsl:when test="count(. | $Ref_RUNTIME_FILE)=1 and $RT_RUNTIME_FILE">			 -->
			    
			     <!-- <xsl:copy-of select="$RT_RUNTIME_FILE/*" /> -->
							
			<!-- </xsl:when> -->
			
				<!-- 	<xsl:when test="count(. | $Ref_SSD_SRV_A2L_File)=1 and $RT_SSD_SRV_A2L_File">
			   <xsl:element name="SSD_SRV_A2L">
			     <xsl:value-of select="$RT_SSD_SRV_A2L_File" />
			   </xsl:element>
			</xsl:when> -->
			
				<xsl:when test="count(. | $Ref_SSD_A2L_File)=1 and $RT_SSD_A2L_File">
			   <xsl:element name="SSD_A2L">
			     <xsl:value-of select="$RT_SSD_A2L_File" />
			   </xsl:element>
			</xsl:when>
			
					<xsl:when test="count(. | $Ref_SRV_A2L_File)=1 and $RT_SRV_A2L_File">
			   <xsl:element name="SRV_A2L">
			     <xsl:value-of select="$RT_SRV_A2L_File" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_FIND_SECURITY_INFO)=1 and $RT_FIND_SECURITY_INFO">
			   <xsl:element name="FindSecurityInformation">
			     <xsl:value-of select="$RT_FIND_SECURITY_INFO" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_ECUSECU_FLAG)=1 and $RT_ECUSECU_FLAG">
			   <xsl:element name="ECUSECU_FLAG">
			     <xsl:value-of select="$RT_ECUSECU_FLAG" />
			   </xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_ECU_SECU_FILE)=1 and $RT_ECU_SECU_FILE">
			   <xsl:element name="ECUSECU_FILE">
			     <xsl:value-of select="$RT_ECU_SECU_FILE" />
			   </xsl:element>
			</xsl:when>
			
				<xsl:when test="count(. | $Ref_PVER_PATH)=1 and $RT_PVER_PATH">
			   <xsl:element name="PVER_PATH_FOR_TOOL_RUN">
			     <xsl:value-of select="$RT_PVER_PATH" />
			   </xsl:element>
			</xsl:when>
			
		
		<xsl:when test="count(. | $Ref_ECUSECU_VERSION)=1 and $RT_ECUSECU_VERSION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_ECUSECU_VERSION"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_MESSAGE)=1 and $RT_MESSAGE">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_MESSAGE"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_VALID_SECURITY_VERSION)=1 and $RT_VALID_SECURITY_VERSION">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_VALID_SECURITY_VERSION"/>
		</xsl:element>
	</xsl:when>
			
	 <xsl:when test="count(. | $Ref_HexMod_BootCtrl_Version_Xml)=1 and $RT_HexMod_BootCtrl_Version_Xml">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_HexMod_BootCtrl_Version_Xml/*"/>
      </xsl:element>
    </xsl:when>
	
     <xsl:when test="count(. | $Ref_XADDRESS)=1 and $RT_XADDRESS">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_XADDRESS"/>
      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_MODE_TYPE)=1 and $RT_MODE_TYPE">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_MODE_TYPE"/>
      </xsl:element>
    </xsl:when>
	 
		<xsl:when test="count(. | $Ref_BOOTCTRL_VERSION)=1 and $RT_BOOTCTRL_VERSION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_BOOTCTRL_VERSION"/>
      </xsl:element>
    </xsl:when>
	 
		<xsl:when test="count(. | $Ref_MDG_Type)=1 and $RT_MDG_Type">
      <xsl:element name="MDG_Type">
        <xsl:value-of select="$RT_MDG_Type"/>
      </xsl:element>
    </xsl:when>
	
	 <xsl:when test="count(. | $Ref_Toworkflow_Data_To_Usecase)=1 and $RT_Toworkflow_Data_To_Usecase">     
			<xsl:element name="Datas">      
				<xsl:copy-of select="$RT_Toworkflow_Data_To_Usecase/*"/>       
			</xsl:element>    
		</xsl:when> 
	
	<xsl:when test="count(. | $Ref_BootCtrlVersion_Hex)=1 and $RT_BootCtrlVersion_Hex">
			<xsl:element name="BOOTCRL_VERSION_HEX">
			<xsl:value-of select="$RT_BootCtrlVersion_Hex"/>
		</xsl:element>
	</xsl:when>	
		<xsl:when test="count(. | $Ref_MergedConfig_ModeType_XPATH)=1 and $RT_MergedConfig_ModeType_XPATH">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_MergedConfig_ModeType_XPATH"/>
      </xsl:element>
    </xsl:when>	
	<xsl:when test="count(. | $Ref_GUAM_FLAG)=1 and $RT_GUAM_FLAG">
		<xsl:element name="GUAM_FLAG">
			<xsl:value-of select="$RT_GUAM_FLAG"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_CFGEXP_MACHINE_TYPE)=1 and $RT_CFGEXP_MACHINE_TYPE">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_MACHINE_TYPE"/>
			</xsl:element>
	</xsl:when>	
	
		

			
			
			
		
	<xsl:when test="count(. | $Ref_BOOTCTRL_HEX)=1 and $RT_BOOTCTRL_HEX">
	<xsl:element name="Location">
		<xsl:copy-of select="$RT_BOOTCTRL_HEX/*" />
	</xsl:element>
</xsl:when>

		
	<xsl:otherwise>
			<xsl:element name="{name()}">
				<xsl:apply-templates select="@*" />
				<xsl:apply-templates />
			</xsl:element>
	</xsl:otherwise>
	</xsl:choose>
</xsl:template>       
<xsl:template match="@*">
		<xsl:choose>
			<xsl:when test="false"></xsl:when>
			<xsl:otherwise>
				<xsl:attribute name="{name()}">
					<xsl:value-of select="." />
				</xsl:attribute>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
