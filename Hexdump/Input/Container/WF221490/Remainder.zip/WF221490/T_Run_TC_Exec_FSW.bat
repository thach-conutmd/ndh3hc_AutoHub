START /WAIT "TC_SRL" "C:\toolbase\pdt_toolchain\1v60.2\ToolChain.exe"  -S "|C:\temp\PDT\JAP\MDG1\MDG1_JAP_Honda_PDW0001\D2P\Honda\MG1CA020\WF221490\P_Run_TC_Exec_FSW.xml|"

