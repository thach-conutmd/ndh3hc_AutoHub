<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:output method="xml" omit-xml-declaration='yes' 
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

 <!--
		Main Idea: Walk through the toolchain's data step by step. Copy each node using default-rules.
		Some parts of the toolchain's data can be overwritten without any knowledge about the internal
		structure.
		For each part there exist two variables:
		- The first has to be used by the calling stylesheet. It is prefixed by either "UC" (UseCase)
		  or "RT" (RunTime). It is initialized empty in this basic library. A calling stylesheet can
		  overwrite this initial value.
		- Correspondig to this externally used variable we have an internal reference. It is prefixed 
		  "REF" and contains an XPATH. This XPATH describes the part to be replaced.	
	    On principle it is assumed that in the toolchain's data the part to be overwritten already exists
	    It may be empty but it should exist. Occasionally it could be possible to newly introduce data.
	  
	    The Stylesheet calling this library only has 
		- to provide XPATHs for the variables mentioned abobve to be used for extracting data from the 
		  tool output 
		It is not necessary to call any template. This is done within the library.				
  --> 
 <!-- Path to the toolchain's data file                        -->
 <xsl:variable name="UseCaseXML" select="''"/>
 

 <!-- Variables to be used by the calling stylesheet(s)    -->
 
  <xsl:variable name="RT_HexModX_HSMTrimmed_Hex" select="''"/>
 <xsl:variable name="RT_AES_Key_ParaSet_File" select="''"/>
   <xsl:variable name="RT_MAC_UC_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_MAC_UP_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_RSA_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_ECC_Key_ParaSet_File" select="''"/>
 <xsl:variable name="RT_BSW_RELEASE_VALUE" select="''"/>
 <xsl:variable name="RT_TRIM_ERASE_RANGE" select="''"/>
 <xsl:variable name="RT_E_NR_IB_Value" select="''"/>
 <xsl:variable name="RT_HexMod_PatchedHexfile" select="''"/> 
  <xsl:variable name="RT_FEE_EMULATION_TYPE_HSM" select="''"/>
 <xsl:variable name="RT_FEE_EMULATION_TYPE_HOST" select="''"/>
 <xsl:variable name="RT_EEE_TYPE" select="''"/>
 <xsl:variable name="RT_ABM_START_ADDRESS" select="''" />
  <xsl:variable name="RT_ABM_END_ADDRESS" select="''" />
  <xsl:variable name="RT_CERTIFICATE_SIZE" select="''" />
 <xsl:variable name="RT_InjCrv_numInjMaxSys_C" select="''"/> 
 <xsl:variable name="RT_CWEVAB" select="''"/> 
 <xsl:variable name="RT_BOOT_MODE_INDEX" select="''"/>
 <xsl:variable name="RT_CFGEXP_MACHINE_DEV" select="''"/>
 <xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="''"/>
 
 <xsl:variable name="RT_Hexfile_Variant_Code" select="''"/>
 <xsl:variable name="RT_VC_Hexfile_Variant_Code" select="''"/>
 <xsl:variable name="RT_VariantHexFile" select="''"/>
 
 <xsl:variable name="RT_InfotablePatchPath" select="''" />
	<xsl:variable name="RT_CustVariableList" select="''" />
	<xsl:variable name="RT_Replaced_Infotable_PatchFile" select="''"/>
 
   <xsl:variable name="RT_HexMod_Update_FileclassID" select="''" />
   <xsl:variable name="RT_HexMod_Update_VC_FileclassID" select="''" />
  <xsl:variable name="RT_VDS_FILESLIST" select="''"/>
 <xsl:variable name="RT_Update_VDS_StartAddress" select="''"/>
 <xsl:variable name="RT_Ped_Script_HexCompare" select="''"/>
 <xsl:variable name="RT_HEX_COMPARE_LOGISTIC_LOG" select="''"/>
 
 <xsl:variable name="RT_UpdateCRC32_SB" select="''"/>
 <xsl:variable name="RT_UpdateCRC32_TP" select="''"/>
 <xsl:variable name="RT_UpdateCRC32_HSM0" select="''"/>
 <xsl:variable name="RT_UpdateCRC32_HSM1" select="''"/>
 
 <xsl:variable name="RT_SB_CRC32_CHECKSUM" select="''"/>
 <xsl:variable name="RT_TPROT_CRC32_CHECKSUM" select="''"/>
 <xsl:variable name="RT_HSM0_CRC32_CHECKSUM" select="''"/>
 <xsl:variable name="RT_HSM1_CRC32_CHECKSUM" select="''"/>
 
<xsl:variable name="RT_Update_CBversion" select="''"/>
<xsl:variable name="RT_Update_CBversion_ToWorkFlow" select="''"/>
<xsl:variable name="RT_Update_TPROTversion" select="''"/>
<xsl:variable name="RT_Update_TPROTversion_ToWorkFlow" select="''"/>
<xsl:variable name="RT_Update_CBversion_ToReplace" select="''"/>
<xsl:variable name="RT_Update_CBversion_ReplaceValue" select="''"/>

  <xsl:variable name="RT_SECURITY_VARIANT" select="''"/>
  <xsl:variable name="RT_SIGNING_METHOD_VALUE" select="''"/>
 
 <xsl:variable name="RT_HexMod_CBVersion_Value_Xml" select="''"/>
 <xsl:variable name="RT_HEXMODX_READ_CBTPROTVERSION" select="''"/> 
 
 <xsl:variable name="RT_HWRefValue" select="''"/> 
 <xsl:variable name="RT_UpdateHW_Ref_ToWorkFlow" select="''"/>
 <xsl:variable name="RT_UpdateHW_Ref_Job_ToWorkFlow" select="''"/>
 
 <xsl:variable name="RT_ReadMatrixInfo_EEP_TYPE" select="''"/> 
 <xsl:variable name="RT_AddressLayout_Value" select="''"/>
 <xsl:variable name="RT_FLASH_CONFIG_SY" select="''"/>
 <xsl:variable name="RT_EOL_CB_SY" select="''"/>
 <xsl:variable name="RT_DIAG_SVRPTCOL_SY" select="''"/>
 <xsl:variable name="RT_SIA_GENR_SY" select="''"/>

 <xsl:variable name="RT_ReadMatrixInfo_FlashSignedFlag" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_HSMSignedFlag" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_ECU_TYPE" select="''"/> 
 
 <xsl:variable name="RT_Flash0_AdjustChksum" select="''"/>
 <xsl:variable name="RT_ECU_Mem_Cont" select="''"/>
 <xsl:variable name="RT_HexMod_EraseHexFile" select="''" />
 <xsl:variable name="RT_HexMod_EraseHexFile_To_WorkFlow" select="''" />
 
 <xsl:variable name="RT_REPROGRAM_SIGNATURE_SIZE" select="''" />
 <xsl:variable name="RT_REPROGRAM_SIGNATURE_SIZE_Flash0" select="''" />
 <xsl:variable name="RT_REPROG_DATABLOCKS_TEMPLATE_Flash0" select="''"/>
 
  <xsl:variable name="RT_SignTool_Reprog_HashValue" select="''"/>
  
 <xsl:variable name="RT_RawFileUpdated" select="''" />
<xsl:variable name="RT_RawFileNameUpdated" select="''" />
 <xsl:variable name="RT_NrDatapointers" select="''"/>
 
  <xsl:variable name="RT_LASTRUN_HEXMOD_HASHOUTPUT" select="''" />
  <xsl:variable name="RT_LASTRUN_WITHOUTHSM_HASHOUTPUT" select="''" />
  <xsl:variable name="RT_LASTRUN_FALSH0_HASHOUTPUT" select="''" />
  <xsl:variable name="RT_LASTRUN_Reprog_HASHOUTPUT" select="''" />
  <xsl:variable name="RT_LASTRUN_GUAM_HASHOUTPUT" select="''" />
 
 <xsl:variable name="RT_FEE_Report_ParaSet_File" select="''"/>
 <xsl:variable name="RT_CHECKSUMME_FILE" select="''"/>
 <xsl:variable name="RT_Hex_Compare_File" select="''"/>
 <xsl:variable name="RT_BC_Gen_log" select="''"/>
 <xsl:variable name="RT_BC_Gen_Log_Complete" select="''"/>
 <xsl:variable name="RT_Patch_Info" select="''"/>
 <xsl:variable name="RT_PAT_INF_To_WorkFlow" select="''"/>
 <xsl:variable name="RT_PAT_INF" select="''"/>
 
 <xsl:variable name="RT_Knownoutput_log" select="''"/>
 <xsl:variable name="RT_Unknownoutput_log" select="''"/>
 <xsl:variable name="RT_Knownoutput_log_To_WorkFlow" select="''"/>
 <xsl:variable name="RT_HEX_CMP" select="''"/>
 <xsl:variable name="RT_Unknownoutput_log_To_WorkFlow" select="''"/>
 <xsl:variable name="RT_HEX_CMP_UN" select="''"/>
 
 
 <xsl:variable name="RT_ReadMatrixInfo_RAWMCSVersion" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_VariableListFile" select="''" />
 
 <xsl:variable name="RT_HexMod_Reprog_HashValue" select="''"/>
 <xsl:variable name="RT_HexMod_Reprog_SignedValues" select="''"/>
 
 <xsl:variable name="RT_Updated_CHECKSUM_VALUE" select="''"/>
  <xsl:variable name="RT_CB_INFOBLOCKID_302" select="''"/>
 <xsl:variable name="RT_UpdateCheckumsinUseCase_Data" select="''"/>
 
 <xsl:variable name="RT_FSW_AddressModel_File" select="''"/>
 <xsl:variable name="RT_DATA_POINTERS_FILE" select="''"/> 
 <xsl:variable name="RT_CHECKSUMS_XMLFILE" select="''"/>
 
 <xsl:variable name="RT_HEXMODX_CHECKSUM_SCRIPT" select="''"/> 
 <xsl:variable name="RT_REPROG_DATABLOCKS_TEMPLATE" select="''"/>
 
 <xsl:variable name="RT_HexMod_Flash0_HashValue" select="''"/>
 <xsl:variable name="RT_HexMod_Flash0_SignedValues" select="''"/>
 
  <xsl:variable name="RT_HexMod_Flash0_GUAM_HashValue" select="''"/>
 
 <xsl:variable name="RT_Create_Flash_0" select="''"/>
 <xsl:variable name="RT_Flash0_HexFile_Full" select="''"/>
 <xsl:variable name="RT_Flash0_Signed" select="''"/>
 <xsl:variable name="RT_Flash0" select="''"/>
 <xsl:variable name="RT_FLASH_0_AdrMod" select="''"/>
 
 <xsl:variable name="RT_HexMod_HashValue" select="''"/>
 <xsl:variable name="RT_HexMod_SignedValues" select="''"/>
 
  <xsl:variable name="RT_HexMod_WithoutHSM_HashValue" select="''"/>
 
 <xsl:variable name="RT_OTP_Key" select="''"/>
 <xsl:variable name="RT_OTP_Overview" select="''"/>
 <xsl:variable name="RT_OTP_Key_Overview_File" select="''"/> 
 <xsl:variable name="RT_UpdateOTP_Ref_InUseCase_Data" select="''"/>
 <xsl:variable name="RT_UpdateOTP_Ref_ToWorkFlow" select="''"/> 
 <xsl:variable name="RT_Update_OTP_Ref_Code_To_UseCase" select="''"/> 
 <xsl:variable name="RT_Update_OTP_Ref_Code_To_WorkFlow" select="''"/>   
 
 <xsl:variable name="RT_HEXMODX_PATCH_MAIN_XML" select="''"/>
 <xsl:variable name="RT_ENDIAN_TYPE" select="''"/>
  <xsl:variable name="RT_ENDIAN_TYPE_CNT" select="''"/>
	
 <xsl:variable name="RT_ReadMatrixInfo_FlashSigned" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_FlashOpt" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_HSMSigned" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_HSMOpt" select="''"/> 
 <xsl:variable name="RT_ReadMatrixInfo_DebugSigned" select="''"/> 
 
 <xsl:variable name="RT_KDNR_Parameter" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_SY_WFS" select="''"/>
 <xsl:variable name="RT_Imo_idxLab_C_VW" select="''"/>
 <xsl:variable name="RT_KONSERVE_PATCHANDCHECK_LABELS" select="''"/>
 <xsl:variable name="RT_Imo_idxLab_C_VW_Value" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_KUNDENMARKE" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_FAZITDB1" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_WFSSELECT" select="''"/>
 <xsl:variable name="RT_ReadMatrixInfo_EELayout" select="''"/> 
 <xsl:variable name="RT_CNT_TYPE" select="''"/>
 <xsl:variable name="RT_RAW_CONTAINER" select="''"/>
 <xsl:variable name="RT_E_STATUS_PO" select="''"/>
 <xsl:variable name="RT_ContainerType_ID" select="''"/>
 
 <xsl:variable name="RT_RELEASEPST" select="''"/>
 <xsl:variable name="RT_HexModx_SignedHexfile_Complete_To_WorkFlow" select="''"/>
 <xsl:variable name="RT_HexMod_SignedHexfile_Complete" select="''"/>
 
 <xsl:variable name="RT_A2L_FILE_CUST_ToUsecase" select="''"/>
 
 <xsl:variable name="RT_RELEASEPST_CUST" select="''"/>
 <xsl:variable name="RT_HexMod_SignedHexfile" select="''"/>
 <xsl:variable name="RT_HexMod_SignedHexfile_To_WorkFlow" select="''"/>
 <xsl:variable name="RT_LabelAddress_Cust_To_WorkFlow" select="''"/>
 
 
 <xsl:variable name="RT_PatchPath" select="''" />
 <xsl:variable name="RT_Fee_VariableList" select="''" />
 <xsl:variable name="RT_DoSerPatchFile" select="''"/> 
 <xsl:variable name="RT_Patch_Script_File" select="''"/>
 <xsl:variable name="RT_HexModx_PatchedHexfile" select="''" />
 <xsl:variable name="RT_HexModx_SWTTNR_PatchedHexfile" select="''"/>
 <xsl:variable name="RT_Signed_Hexfile" select="''"/>
 
 <xsl:variable name="RT_HexModX_IntegrationFile_withoutData" select="''"/>
 <xsl:variable name="RT_HexModX_AppliedFile_withoutProg" select="''"/>
 <xsl:variable name="RT_HexModX_MergedHexfile_withoutData" select="''"/>
 <xsl:variable name="RT_Hexfile_Infotable_Patched" select="''"/>
 
 <xsl:variable name="RT_User_LastName" select="''"/>
 <xsl:variable name="RT_User_FirstName" select="''"/>
 <xsl:variable name="RT_User_Company" select="''"/>
 <xsl:variable name="RT_User_Department" select="''"/>
 <xsl:variable name="RT_User_Role" select="''"/>
 <xsl:variable name="RT_User_ZIP" select="''"/>
 <xsl:variable name="RT_User_City" select="''"/>
 <xsl:variable name="RT_User_Phone" select="''"/>
 <xsl:variable name="RT_User_Fax" select="''"/>
 <xsl:variable name="RT_User_EMail" select="''"/>
 <xsl:variable name="RT_User_Address" select="''"/>
 
 
 <xsl:variable name="RT_Eep_EnvRamClr_CW" select="''"/>
<xsl:variable name="RT_Eep_EnFirstInit_CW" select="''"/>

<xsl:variable name="RT_BasSvrAppl_EepPrgVer_C" select="''"/>
<xsl:variable name="RT_BasSvrAppl_EepPartNr_C" select="''"/>

<xsl:variable name="RT_BasSvrAppl_EepODXFileID_C" select="''"/>
<xsl:variable name="RT_BasSvrAppl_EepODXFileVer_C" select="''"/>

<xsl:variable name="RT_ToolConfig" select="''"/>

<xsl:variable name="RT_FlashLayoutModel" select="''"/>
<xsl:variable name="RT_UpdateSGIDB1inUseCase_Data" select="''"/>

<xsl:variable name="RT_ReadMatrixInfo_HESRV_MasterSlave" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_FEOLOC_Select" select="''"/>
<xsl:variable name="RT_PROT_TYPE" select="''"/>
<xsl:variable name="RT_SECURITY_ACCESS" select="''"/>

<xsl:variable name="RT_HexMod_AddressModel" select="''"/>
<xsl:variable name="RT_PP_IBAddressList" select="''"/>

<xsl:variable name="RT_PART_PROG_SY" select="''"/>
<xsl:variable name="RT_Update_ALFID_EraseMemLen" select="''"/>
<xsl:variable name="RT_Update_ALFID_EraseMemAdr" select="''"/> 
<xsl:variable name="RT_Update_ALFID_ReqDownLoadMemLen" select="''"/>
<xsl:variable name="RT_Update_ALFID_ReqDownLoadMemAdr" select="''"/> 
<xsl:variable name="RT_Update_ALFID_CheckMemLen" select="''"/>
<xsl:variable name="RT_Update_ALFID_CheckMemAdr" select="''"/>
<xsl:variable name="RT_Update_ALFID_RoutiContrCheckMemLen" select="''"/>
<xsl:variable name="RT_Update_VW80126Version_Value" select="''"/>
<xsl:variable name="RT_Update_PROGPRECOND_Values" select="''"/>  
<xsl:variable name="RT_Update_DFID" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_DFID_FLAG" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_COMPRESSION" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_ENCRYPTION" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_DFID" select="''"/>
<xsl:variable name="RT_Tools" select="''" />
<xsl:variable name="RT_ReadMatrixInfo_ODX_CREATE_COMPRESSION" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_ODX_CREATE_ENCRYPTION" select="''"/>
<xsl:variable name="RT_HexMod_AES_KEY_Value_Xml" select="''"/>

<xsl:variable name="RT_ReadMatrixInfo_ODX_EXTRN_COMPRESSION" select="''"/>
<xsl:variable name="RT_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION" select="''"/>
<xsl:variable name="RT_FlashLayout_Conf_File" select="''"/>
<xsl:variable name="RT_CMBTYP_SY" select="''"/>
<xsl:variable name="RT_AddressList" select="''"/>
<xsl:variable name="RT_TSAppCompat" select="''" />
<xsl:variable name="RT_SignTool_HashValue" select="''"/>
<xsl:variable name="RT_ClientIP" select="''" />
<xsl:variable name="RT_ClientName" select="''" />
<xsl:variable name="RT_DomainName" select="''" />
<xsl:variable name="RT_StationName" select="''" />
<xsl:variable name="RT_UserName" select="''" />
<xsl:variable name="RT_ReadMatrixInfo_PART_PROG_SY" select="''" />
<xsl:variable name="RT_HexMod_InfoTableLog" select="''"/>
<xsl:variable name="RT_HEXMOD_READ_BLOCKVERSION" select="''"/>

<xsl:variable name="RT_PP_Latest_SWBlock_Versions" select="''"/>
<xsl:variable name="RT_PP_NewEntryinDatabase" select="''"/>
<xsl:variable name="RT_PP_VarList_New_SWBlock_Versions" select="''"/>
<xsl:variable name="RT_PP_VarList_New_SWBlock_Versions_ToNextPD" select="''"/>
<xsl:variable name="RT_Hexmod_Config_PatchLatestBlockVersions" select="''"/>
<xsl:variable name="RT_HexMod_PatchedLatestBlockVersion" select="''"/>
<xsl:variable name="RT_HexMod_Output_LatestBlockVersions" select="''"/>
<xsl:variable name="RT_PP_New_SWBlock_Versions" select="''"/>
<xsl:variable name="RT_Hexmod_Config_PatchNewBlockVersions" select="''"/>
<xsl:variable name="RT_HexMod_UEKO_Checksum_Update_Hexfile_1" select="''"/>
<xsl:variable name="RT_HexMod_PatchedNewBlockVersion" select="''"/>
<xsl:variable name="RT_HexMod_UEKO_Checksum_Update_Hexfile_2" select="''"/>
<xsl:variable name="RT_HexMod_Output_NewBlockVersions" select="''"/>
<xsl:variable name="RT_HexModx_SWTTNR_PartialFlash_PatchedHexfile" select="''"/>
<xsl:variable name="RT_Hexfile_CB_PATCH" select="''"/>
  <xsl:variable name="RT_CB_INFOBLOCKID_302_SGIDB3" select="''" />
  <xsl:variable name="RT_CB_INFOBLOCKID_302_ODXFilieID" select="''" />
  <xsl:variable name="RT_CB_INFOBLOCKID_302_ODXFilieVer" select="''" />
  <xsl:variable name="RT_ReadMatrixInfo_ENDIAN_TYPE" select="''"/>
  
 <xsl:variable name="RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START" select="''"/>
  <xsl:variable name="RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START" select="''"/>
  <xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_START" select="''"/>
  <xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_END" select="''"/>
  <xsl:variable name="RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START" select="''"/>
  <xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1" select="''"/>
  <xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2" select="''"/>
  <xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3" select="''"/>
  <xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4" select="''"/>
  <xsl:variable name="RT_HSM_PIB_ADDRESS" select="''"/>
  <xsl:variable name="RT_HSM_PIB_LENGTH" select="''"/>
  <xsl:variable name="RT_HSM_FDB_START" select="''"/>
  <xsl:variable name="RT_HSM_FDB_OFFSET" select="''"/>
  <xsl:variable name="RT_HexMod_CBLite_HashValue" select="''"/>
<xsl:variable name="RT_CBLite_Signed" select="''"/>
  <xsl:variable name="RT_Flash0_HexFile_GUAM" select="''"/>
   <xsl:variable name="RT_GUAM_FLAG" select="''"/>
 <xsl:variable name="RT_PIB_ENDADDRESS" select="''"/>
<xsl:variable name="RT_FSW_DPTR_CONFIG" select="''" />
  <xsl:variable name="RT_HexMod_CBLite_SignedValues" select="''"/>
  
  
  <xsl:variable name="RT_SB_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_SB_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_EcuSecuSrv0_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_EcuSecuSrv0_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_CTP_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_CTP_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_CB_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_CB_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_ASW0_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_ASW0_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_ASW1_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_ASW1_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_ASW2_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_ASW2_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_ASW3_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_ASW3_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_DS0_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_DS0_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_DS1_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_DS1_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_VDS_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_VDS_ENDADDRESS" select="''"/>
  <xsl:variable name="RT_CUST0_STARTADDRESS" select="''"/>
  <xsl:variable name="RT_CUST0_ENDADDRESS" select="''"/>
  
  
  <xsl:variable name="RT_BLOCKS" select="''"/>
   <xsl:variable name="RT_SW_BLOCKS" select="''"/>
   <xsl:variable name="RT_OUTPUTFILENAME_FLAG" select="''"/>
   <xsl:variable name="RT_DEFAULTFILENAME" select="''"/>
   <xsl:variable name="RT_ToolVersion" select="''"/>
<!-- Reference variables pointing to the proper parts in our data -->
<xsl:variable name="Ref_GUAM_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:GUAM_FLAG"/>
<xsl:variable name="Ref_Flash0_HexFile_GUAM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_HexFile_GUAM']/tctypes:Location"/>
<xsl:variable name="Ref_CBLite_Signed" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CBLite_Signed']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_CBLite_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_CBLite_HashValue']/tctypes:Location"/>
<xsl:variable name="Ref_HSM_PIB_ADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_PIB_ADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_HSM_PIB_LENGTH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_PIB_LENGTH']/tctypes:Value"/>
<xsl:variable name="Ref_HSM_FDB_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_FDB_START']/tctypes:Value"/>
<xsl:variable name="Ref_HSM_FDB_OFFSET" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_FDB_OFFSET']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_CBLITE_COMPILED_ADDRESS_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_CBLITE_COMPILED_ADDRESS_START']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_CBLITE_IN_REPROGCONTAINER_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_CBLITE_IN_REPROGCONTAINER_START']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_SOURCE_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_SOURCE_START']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_SOURCE_END" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_SOURCE_END']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4']/tctypes:Value"/>
<xsl:variable name="Ref_FSW_DPTR_CONFIG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='FSW_DPTR_CONFIG']/tctypes:Location"/>
<xsl:variable name="Ref_PIB_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PIB_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_HexMod_CBLite_SignedValues" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_CBLite_SignedValues']/tctypes:Location"/>
<xsl:variable name="Ref_AES_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='AES_Key_ParaSet_File']/tctypes:Location"/>
<xsl:variable name="Ref_MAC_UC_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='MAC_UC_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
<xsl:variable name="Ref_MAC_UP_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='MAC_UP_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
<xsl:variable name="Ref_RSA_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RSA_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
<xsl:variable name="Ref_ECC_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ECC_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
<xsl:variable name="Ref_Replaced_Infotable_PatchFile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Replaced_Infotable_PatchFile']/tctypes:Location"/>
<xsl:variable name="Ref_CustVariableList" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CustVariableList']/tctypes:Value" />	
<xsl:variable name="Ref_InfotablePatchPath" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='InfotablePatchPath']/tctypes:Value" />	

<xsl:variable name="Ref_BSW_RELEASE_VALUE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BSW_RELEASE_VALUE']/tctypes:Value"/>
<xsl:variable name="Ref_TRIM_ERASE_RANGE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TRIM_HEX_ERASE_RANGE']/tctypes:Value"/>
<xsl:variable name="Ref_E_NR_IB_Value" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='E_NR_IB']/tctypes:Value"/>
<xsl:variable name="Ref_HexMod_PatchedHexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_PatchedHexfile']/tctypes:Location" />
<xsl:variable name="Ref_FEE_EMULATION_TYPE_HSM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FEE_EMULATION_TYPE_HSM']/tctypes:Value"/>
<xsl:variable name="Ref_FEE_EMULATION_TYPE_HOST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FEE_EMULATION_TYPE_HOST']/tctypes:Value"/> 
<xsl:variable name="Ref_EEE_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EEE_TYPE']/tctypes:Value"/>
<xsl:variable name="Ref_ABM_START_ADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ABM_START_ADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ABM_END_ADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ABM_END_ADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CERTIFICATE_SIZE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CERTIFICATE_SIZE']/tctypes:Value"/>

<xsl:variable name="Ref_InjCrv_numInjMaxSys_C" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='InjCrv_numInjMaxSys_C']/tctypes:Value"/>
<xsl:variable name="Ref_CWEVAB" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CWEVAB']/tctypes:Value"/>

 <xsl:variable name="Ref_VariantHexFile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='VariantHex_File']/tctypes:Location"/>
<xsl:variable name="Ref_Hexfile_Variant_Code" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$RT_HexMod_Update_FileclassID]/tctypes:Location"/>
<xsl:variable name="Ref_VC_Hexfile_Variant_Code" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$RT_HexMod_Update_VC_FileclassID]/tctypes:Location"/>

<xsl:variable name="Ref_VDS_FILESLIST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VDS_FILESLIST']/tctypes:Value"/>
  <xsl:variable name="Ref_Update_VDS_StartAddress" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VDS_START_ADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_Ped_Script_HexCompare" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PED_SCRIPT_HEXCODE_COMPARE']/tctypes:Value"/>
<xsl:variable name="Ref_HEX_COMPARE_LOGISTIC_LOG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SCRIPT_HEX_COMPARE_LOGISTIC_LOG']/tctypes:Value"/>


<xsl:variable name="Ref_UpdateCRC32_SB" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CRC32_SB']/tctypes:Variables"/>
<xsl:variable name="Ref_UpdateCRC32_TP" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CRC32_TP']/tctypes:Variables"/>
<xsl:variable name="Ref_UpdateCRC32_HSM0" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CRC32_HSM0']/tctypes:Variables"/>
<xsl:variable name="Ref_UpdateCRC32_HSM1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CRC32_HSM1']/tctypes:Variables"/>

<xsl:variable name="Ref_SB_CRC32_CHECKSUM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SB_CRC32_CHECKSUM']/tctypes:Value"/>
<xsl:variable name="Ref_TPROT_CRC32_CHECKSUM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TPROT_CRC32_CHECKSUM']/tctypes:Value"/>
<xsl:variable name="Ref_HSM0_CRC32_CHECKSUM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM0_CRC32_CHECKSUM']/tctypes:Value"/>	
<xsl:variable name="Ref_HSM1_CRC32_CHECKSUM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM1_CRC32_CHECKSUM']/tctypes:Value"/>

<xsl:variable name="Ref_Update_CBversion_ReplaceValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CBversion_ReplaceValue']/tctypes:Value"/>
<xsl:variable name="Ref_Update_CBversion_ToReplace" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_version_ToReplace']/tctypes:Value"/>

<xsl:variable name="Ref_Update_CBversion_ToWorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='Datalist_CB_Version']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/>
<xsl:variable name="Ref_Update_TPROTversion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TPROT_version']/tctypes:Value"/>
<xsl:variable name="Ref_Update_CBversion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_version']/tctypes:Value"/>
<xsl:variable name="Ref_Update_TPROTversion_ToWorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='Datalist_TPROT_Version']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/>

<xsl:variable name="Ref_HexMod_CBVersion_Value_Xml" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexmodX_CBVersion_xml']/tctypes:Location"/>
<xsl:variable name="Ref_HEXMODX_READ_CBTPROTVERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HEXMODX_READ_CBTPROTVERSION']/tctypes:Value"/>	

  <xsl:variable name="Ref_HWRefValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HW_Reference']/tctypes:Value"/> 
  <xsl:variable name="Ref_UpdateHW_Ref_ToWorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='Datalist_HW_Reference']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/>
  <xsl:variable name="Ref_UpdateHW_Ref_Job_ToWorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='Datalist_Reference_Job']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/>

<xsl:variable name="Ref_ReadMatrixInfo_EEP_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EEP_TYPE']/tctypes:Value"/>
<xsl:variable name="Ref_AddressLayout_Value" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:AddressLayout"/>
<xsl:variable name="Ref_FLASH_CONFIG_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FLASH_CONFIG_SY']/tctypes:Value"/>
<xsl:variable name="Ref_EOL_CB_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EOL_CB_SY']/tctypes:Value"/>
<xsl:variable name="Ref_DIAG_SVRPTCOL_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DIAG_SVRPTCOL_SY']/tctypes:Value"/>
<xsl:variable name="Ref_SIA_GENR_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SIA_GENR_SY']/tctypes:Value"/>

<xsl:variable name="Ref_ReadMatrixInfo_FlashSignedFlag" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FLASH_OTP_FLAG']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_HSMSignedFlag" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_OTP_FLAG']/tctypes:Value"/>

<xsl:variable name="Ref_ReadMatrixInfo_ECU_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ECU_TYPE']/tctypes:Value"/>

<xsl:variable name="Ref_Flash0_AdjustChksum" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_OnlyModASW0_AdjustChksum']/tctypes:Location"/>

<xsl:variable name="Ref_ECU_Mem_Cont" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='FSW_CONT']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_EraseHexFile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_ERASE_HEXFile']/tctypes:Location"/>
 <xsl:variable name="Ref_HexMod_EraseHexFile_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='RELEASEPST']/tctypes:Data"/> 

<xsl:variable name="Ref_FLASH_0_AdrMod" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_AdrMod']/tctypes:Location"/>
<xsl:variable name="Ref_REPROG_DATABLOCKS_TEMPLATE_Flash0" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='REPROG_DATABLOCKS_TEMPLATE_Flash0']/tctypes:Value"/>

<xsl:variable name="Ref_REPROGRAM_SIGNATURE_SIZE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='REPROG_SIGNATURE_SIZE']/tctypes:Value"/>
<xsl:variable name="Ref_REPROGRAM_SIGNATURE_SIZE_Flash0" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='REPROG_SIGNATURE_SIZE_Flash0']/tctypes:Value"/>

 <xsl:variable name="Ref_SignTool_Reprog_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SignTool17_Reprog_HashValue']/tctypes:Location"/>

<xsl:variable name="Ref_LASTRUN_HEXMOD_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_HEXMOD_HASHOUTPUT']/tctypes:Location"/>
<xsl:variable name="Ref_LASTRUN_WITHOUTHSM_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_WITHOUTHSM_HASHOUTPUT']/tctypes:Location"/>
<xsl:variable name="Ref_LASTRUN_FALSH0_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_FALSH0_HASHOUTPUT']/tctypes:Location"/>
<xsl:variable name="Ref_LASTRUN_Reprog_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_Reprog_HASHOUTPUT']/tctypes:Location"/>
<xsl:variable name="Ref_LASTRUN_GUAM_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_GUAM_HASHOUTPUT']/tctypes:Location"/>

<xsl:variable name="Ref_RawFileUpdated" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RawFileUpdated']/tctypes:Location"/>
<xsl:variable name="Ref_RawFileNameUpdated" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='RawFileNameUpdated']/tctypes:Value" />
<xsl:variable name="Ref_NrDatapointers" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='NrDatapointers']/tctypes:Value"/>

<xsl:variable name="Ref_FEE_Report_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='FEE_Report_ParaSet_File']/tctypes:Location"/>
<xsl:variable name="Ref_CHECKSUMME_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CHECKSUMME_FILE']/tctypes:Location"/>

<xsl:variable name="Ref_Hex_Compare_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Hex_Compare_File']/tctypes:Location"/>
<xsl:variable name="Ref_BC_Gen_log" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BC_Gen_Log']/tctypes:Location"/>
<xsl:variable name="Ref_PAT_INF" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='PAT_INF']/tctypes:Location"/>
<xsl:variable name="Ref_BC_Gen_Log_Complete" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='BC_Gen_Log_Complete']/tctypes:Location"/>
<xsl:variable name="Ref_Patch_Info" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Patch_Info']/tctypes:Location"/>
<xsl:variable name="Ref_PAT_INF_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='PAT_INF']/tctypes:Data"/>
<xsl:variable name="Ref_Knownoutput_log" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Knownoutput']/tctypes:Location"/>
<xsl:variable name="Ref_HEX_CMP" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HEX_CMP']/tctypes:Location"/>
<xsl:variable name="Ref_Unknownoutput_log" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Unknownoutput']/tctypes:Location"/>
<xsl:variable name="Ref_HEX_CMP_UN" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HEX_CMP_UN']/tctypes:Location"/>
<xsl:variable name="Ref_Knownoutput_log_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='HEX_CMP']/tctypes:Data"/>
<xsl:variable name="Ref_Unknownoutput_log_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='HEX_CMP_UN']/tctypes:Data"/>
 

<xsl:variable name="Ref_ReadMatrixInfo_RAWMCSVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='RAWMCSVersion']/tctypes:Value" />
<xsl:variable name="Ref_ReadMatrixInfo_VariableListFile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VariableListFile']/tctypes:Value" />

<xsl:variable name="Ref_HexMod_Reprog_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_Reprog_HashValue']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_Reprog_SignedValues" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_Reprog_SignedValues']/tctypes:Location"/>

<xsl:variable name="Ref_Updated_CHECKSUM_VALUE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CHECKSUM_REGEX']/tctypes:Value"/>
<xsl:variable name="Ref_CB_INFOBLOCKID_302" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_INFOBLOCKID_302']/tctypes:Value"/>
<xsl:variable name="Ref_UpdateCheckumsinUseCase_Data" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='UpdateCheckumsinUseCase']/tctypes:Variables"/>

<xsl:variable name="Ref_DATA_POINTERS_FILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ECUMEM_DATA_POINTERS_FILE']/tctypes:Location"/>
<xsl:variable name="Ref_CHECKSUMS_XMLFILE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CHECKSUMS_XMLFILE']/tctypes:Location"/>
<xsl:variable name="Ref_HEXMODX_CHECKSUM_SCRIPT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HEXMODX_CHECKSUM_SCRIPT']/tctypes:Value"/>
<xsl:variable name="Ref_REPROG_DATABLOCKS_TEMPLATE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='REPROG_DATABLOCKS_TEMPLATE']/tctypes:Value"/>

<xsl:variable name="Ref_FSW_AddressModel_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='FSW_AddressModel_XMLFile']/tctypes:Location"/>

<xsl:variable name="Ref_Create_Flash_0" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Script_Create_Flash_0']/tctypes:Value"/>
<xsl:variable name="Ref_Flash0_HexFile_Full" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_HexFile_Full']/tctypes:Location"/>
<xsl:variable name="Ref_Flash0_Signed" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_OnlyModASW0_Signed']/tctypes:Location"/>
<xsl:variable name="Ref_Flash0" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_OnlyModASW0']/tctypes:Location"/>

<xsl:variable name="Ref_HexMod_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_HashValue']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_SignedValues" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_SignedValues']/tctypes:Location"/>

<xsl:variable name="Ref_HexMod_WithoutHSM_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_WithoutHSM_HashValue']/tctypes:Location"/>


<xsl:variable name="Ref_HexMod_Flash0_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_Flash0_HashValue']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_Flash0_SignedValues" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_Flash0_SignedValues']/tctypes:Location"/>

<xsl:variable name="Ref_HexMod_Flash0_GUAM_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_Flash0_GUAM_HashValue']/tctypes:Location"/>

<xsl:variable name="Ref_OTP_Key" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='OTP_Key']/tctypes:Value"/>
<xsl:variable name="Ref_OTP_Overview" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='OTP_Overview']/tctypes:Value"/>
<xsl:variable name="Ref_OTP_Key_Overview_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='OTP_Key_Overview_File']/tctypes:Location"/>
<xsl:variable name="Ref_UpdateOTP_Ref_InUseCase_Data" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='OTP_Reference']/tctypes:Value"/>
<xsl:variable name="Ref_Update_OTP_Ref_Code_To_UseCase" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='OTP_Ref_Code']/tctypes:Value"/>

<xsl:variable name="Ref_UpdateOTP_Ref_ToWorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='OTP_Reference']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/>
<!-- <xsl:variable name="Ref_Update_OTP_Ref_Code_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='OTP_Ref_Code']/tctypes:Data[child::tctypes:DataClassID='Data']/tctypes:DataValue"/> -->
<xsl:variable name="Ref_Update_OTP_Ref_Code_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData/tctypes:Data[child::tctypes:DataClassName='SystemConstants.OTP_Ref_Code']/tctypes:DataValue" />


<xsl:variable name="Ref_ENDIAN_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ENDIAN_TYPE']/tctypes:Value"/>
<xsl:variable name="Ref_ENDIAN_TYPE_CNT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ENDIAN_TYPE_CNT']/tctypes:Value"/>

<xsl:variable name="Ref_HEXMODX_PATCH_MAIN_XML" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HEXMODX_PATCH_MAIN_XML']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_FlashSigned" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FLASH_SIGNED']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_FlashOpt" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FLASH_OPT']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_HSMSigned" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_SIGNED']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_HSMOpt" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_OPT']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_DebugSigned" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DBG_SIGNED']/tctypes:Value"/>

<xsl:variable name="Ref_KONSERVE_PATCHANDCHECK_LABELS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='KONSERVE_PATCHANDCHECK_LABELS']/tctypes:Value"/>
<xsl:variable name="Ref_KDNR_Parameter" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='KDNR_Parameter']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_SY_WFS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SY_WFS']/tctypes:Value"/>	
<xsl:variable name="Ref_Imo_idxLab_C_VW" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Imo_idxLab_C_VW']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_KUNDENMARKE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='KUNDENMARKE']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_FAZITDB1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FAZITDB']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_WFSSELECT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='WFS_SELECT']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_EELayout" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EELayout']/tctypes:Value"/>

<xsl:variable name="Ref_CNT_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CNT_TYPE']/tctypes:Value"/>
 <xsl:variable name="Ref_RAW_CONTAINER" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='RAW_CONTAINER']/tctypes:Value"/>
<xsl:variable name="Ref_E_STATUS_PO" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='E_STATUS_PO']/tctypes:Value"/>
<xsl:variable name="Ref_ContainerType_ID" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:ContainerType_ID"/>

<xsl:variable name="Ref_Imo_idxLab_C_VW_Value" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Imo_idxLab_C_VW_Value']/tctypes:Value"/>

<xsl:variable name="Ref_RELEASEPST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RELEASEPST']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_SignedHexfile_Complete" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_SignedHexfile_Complete']/tctypes:Location"/>

<xsl:variable name="Ref_A2L_FILE_CUST_ToUsecase" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='A2L_FILE_CUST']/tctypes:Location"/>

<xsl:variable name="Ref_HexModx_SignedHexfile_Complete_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='RELEASEPST']/tctypes:Data"/>
<xsl:variable name="Ref_RELEASEPST_CUST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RELEASEPST_CUST']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_SignedHexfile_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='RELEASEPST_CUST']/tctypes:Data"/>
<xsl:variable name="Ref_HexMod_SignedHexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_SignedHexfile']/tctypes:Location"/>
<xsl:variable name="Ref_LabelAddress_Cust_To_WorkFlow" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='A2L_FILE_CUST']/tctypes:Data"/>

<xsl:variable name="Ref_HexModx_SWTTNR_PatchedHexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_SWTTNR_PatchedHexfile']/tctypes:Location"/>

<xsl:variable name="Ref_PatchPath" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PatchPath']/tctypes:Value" />	
<xsl:variable name="Ref_Fee_VariableList" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Fee_VariableList']/tctypes:Value" />	
<xsl:variable name="Ref_DoSerPatchFile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='DoSerPatchFile']/tctypes:Location"/>
<xsl:variable name="Ref_Patch_Script_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Patch_Script_File']/tctypes:Location"/> 
<xsl:variable name="Ref_HexModx_PatchedHexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_PatchedHexfile']/tctypes:Location" />
<xsl:variable name="Ref_Signed_Hexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Signed_Hexfile']/tctypes:Location"/>
	
<xsl:variable name="Ref_HexModX_IntegrationFile_withoutData" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_IntegrationFile_withoutData']/tctypes:Location" />
<xsl:variable name="Ref_HexModX_HSMTrimmed_Hex" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_HSMTrimmed_Hex']/tctypes:Location" />
<xsl:variable name="Ref_HexModX_AppliedFile_withoutProg" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_AppliedFile_withoutProg']/tctypes:Location" />
<xsl:variable name="Ref_HexModX_MergedHexfile_withoutData" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_MergedHexFile']/tctypes:Location" />
<xsl:variable name="Ref_Hexfile_Infotable_Patched" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Hexfile_Infotable_Patched']/tctypes:Location" />

<xsl:variable name="Ref_User_LastName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_LastName']/tctypes:Value"/>
<xsl:variable name="Ref_User_FirstName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_FirstName']/tctypes:Value"/>
<xsl:variable name="Ref_User_Company" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Company']/tctypes:Value"/>
<xsl:variable name="Ref_User_Department" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Department']/tctypes:Value"/>
<xsl:variable name="Ref_User_Role" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Role']/tctypes:Value"/>
<xsl:variable name="Ref_User_ZIP" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_ZIP']/tctypes:Value"/>
<xsl:variable name="Ref_User_City" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_City']/tctypes:Value"/>
<xsl:variable name="Ref_User_Phone" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Phone']/tctypes:Value"/>
<xsl:variable name="Ref_User_Fax" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Fax']/tctypes:Value"/>
<xsl:variable name="Ref_User_EMail" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_EMail']/tctypes:Value"/>
<xsl:variable name="Ref_User_Address" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='User_Address']/tctypes:Value"/>

<xsl:variable name="Ref_Eep_EnvRamClr_CW" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Eep_EnvRamClr_CW']/tctypes:Value"/>
<xsl:variable name="Ref_Eep_EnFirstInit_CW" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Eep_EnFirstInit_CW']/tctypes:Value"/>

<xsl:variable name="Ref_BasSvrAppl_EepPrgVer_C" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BasSvrAppl_EepPrgVer_C']/tctypes:Value"/>
<xsl:variable name="Ref_BasSvrAppl_EepPartNr_C" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BasSvrAppl_EepPartNr_C']/tctypes:Value"/>

<xsl:variable name="Ref_BasSvrAppl_EepODXFileID_C" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BasSvrAppl_EepODXFileID_C']/tctypes:Value"/>
<xsl:variable name="Ref_BasSvrAppl_EepODXFileVer_C" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BasSvrAppl_EepODXFileVer_C']/tctypes:Value"/>
	
<xsl:variable name="Ref_ToolConfig" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ToolConfig']/tctypes:Location"/>

<xsl:variable name="Ref_FlashLayoutModel" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:FlashBlocks"/>
<xsl:variable name="Ref_UpdateSGIDB1inUseCase_Data" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='UpdateSGIDB1inUseCase']/tctypes:Value"/>

<xsl:variable name="Ref_ReadMatrixInfo_HESRV_MasterSlave" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='MasterSlave_Single']/tctypes:Value"/>
<xsl:variable name="Ref_ReadMatrixInfo_FEOLOC_Select" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:FEOLOC_Select"/>
<xsl:variable name="Ref_PROT_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PROT_TYPE']/tctypes:Value"/>
<xsl:variable name="Ref_SECURITY_ACCESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SECURITY_ACCESS']/tctypes:Value"/>
<xsl:variable name="Ref_HexMod_AddressModel" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_AddressModel']/tctypes:Location"/>
<xsl:variable name="Ref_PP_IBAddressList" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_IB_AddressList']/tctypes:Value"/>

<xsl:variable name="Ref_PART_PROG_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PART_PROG_SY']/tctypes:Value"/>	
<xsl:variable name="Ref_Update_ALFID_EraseMemLen" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EraseMemLen']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_EraseMemAdr" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EraseMemAdr']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_ReqDownLoadMemLen" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ReqDownLoadMemLen']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_ReqDownLoadMemAdr" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ReqDownLoadMemAdr']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_CheckMemLen" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CheckMemLen']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_CheckMemAdr" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CheckMemAdr']/tctypes:Value"/>
<xsl:variable name="Ref_Update_ALFID_RoutiContrCheckMemLen" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='RoutiContrCheckMemLen']/tctypes:Value"/>
 
<xsl:variable name="Ref_Update_DFID" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DFID']/tctypes:Value"/>
  <xsl:variable name="Ref_Update_VW80126Version_Value" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VW80126Version_Value']/tctypes:Value"/>
  <xsl:variable name="Ref_Update_PROGPRECOND_Values" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PROGPRECOND_Values']/tctypes:PRECOND"/>

<xsl:variable name="Ref_SECURITY_VARIANT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SECURITY_VARIANT']/tctypes:Value"/>
<xsl:variable name="Ref_SIGNING_METHOD_VALUE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SIGNING_METHOD']/tctypes:Value"/>

  <xsl:variable name="Ref_ReadMatrixInfo_DFID_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DFID_FLAG']/tctypes:Value"/>
 <xsl:variable name="Ref_ReadMatrixInfo_COMPRESSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='COMPRESSION']/tctypes:Value"/>
 <xsl:variable name="Ref_ReadMatrixInfo_ENCRYPTION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ENCRYPTION']/tctypes:Value"/>
 <xsl:variable name="Ref_ReadMatrixInfo_DFID" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Matrix_DFID']/tctypes:Value"/>
<xsl:variable name="Ref_Tools" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools" />
  <xsl:variable name="Ref_ReadMatrixInfo_ODX_CREATE_COMPRESSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ODX_CREATE_COMPRESSION']/tctypes:Value"/>
  <xsl:variable name="Ref_ReadMatrixInfo_ODX_CREATE_ENCRYPTION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ODX_CREATE_ENCRYPTION']/tctypes:Value"/>
  <xsl:variable name="Ref_HexMod_AES_KEY_Value_Xml" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Hexmod17_AESKEY_xml']/tctypes:Location"/>
  
  <xsl:variable name="Ref_ReadMatrixInfo_ODX_EXTRN_COMPRESSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ODX_EXTRN_COMPRESSION']/tctypes:Value"/>
  <xsl:variable name="Ref_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ODX_EXTRN_ENCRYPTION']/tctypes:Value"/>
   <xsl:variable name="Ref_FlashLayout_Conf_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='FlashLayout_Conf']/tctypes:Location"/>
  <xsl:variable name="Ref_CMBTYP_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:CMBTYP_SY"/>
  
<xsl:variable name="Ref_AddressList" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ADDRESSLIST_INT']/tctypes:Location"/>
<xsl:variable name="Ref_TSAppCompat" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TSAppCompat']/tctypes:Value" />
 <xsl:variable name="Ref_SignTool_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SignTool17_HashValue']/tctypes:Location"/>
 <xsl:variable name="Ref_ClientIP" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ClientIP']/tctypes:Value" />
 <xsl:variable name="Ref_ClientName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ClientName']/tctypes:Value" />
 <xsl:variable name="Ref_DomainName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DomainName']/tctypes:Value" />
 <xsl:variable name="Ref_StationName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='StationName']/tctypes:Value" />
<xsl:variable name="Ref_UserName" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='UserName']/tctypes:Value" />
 
 
 <xsl:variable name="Ref_ReadMatrixInfo_PART_PROG_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PART_PROG_SY']/tctypes:Value"/>	
 
 <xsl:variable name="Ref_HexMod_InfoTableLog" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_InfoTableLog']/tctypes:Location"/>
 <xsl:variable name="Ref_HEXMOD_READ_BLOCKVERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HEXMOD_READ_BLOCKVERSION']/tctypes:Value"/>	
 <xsl:variable name="Ref_PP_New_SWBlock_Versions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_New_SWBlock_Versions']/tctypes:Value"/>
<xsl:variable name="Ref_PP_Latest_SWBlock_Versions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_Latest_SWBlock_Versions']/tctypes:Value"/>
 <xsl:variable name="Ref_PP_VarList_New_SWBlock_Versions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_VarList_New_SWBlock_Versions']/tctypes:Variables"/>
<xsl:variable name="Ref_PP_VarList_New_SWBlock_Versions_ToNextPD" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToUseCase/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_VarList_New_SWBlock_Versions']/tctypes:Variables"/>
 <xsl:variable name="Ref_Hexmod_Config_PatchLatestBlockVersions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Hexmod_Config_PatchLatestBlockVersions']/tctypes:Value"/>
 <xsl:variable name="Ref_BOOT_MODE_INDEX" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='BOOT_MODE_INDEX_NODE']/tctypes:Value"/>
<xsl:variable name="Ref_CFGEXP_MACHINE_DEV" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_MACHINE_DEV']/tctypes:Value"/> 
<xsl:variable name="Ref_CFGEXP_MACHINE_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_MACHINE_TYPE']/tctypes:Value"/>
 
 <xsl:variable name="Ref_HexMod_PatchedLatestBlockVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_PatchedLatestBlockVersions']/tctypes:Location"/>
 <xsl:variable name="Ref_HexMod_Output_LatestBlockVersions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_Output_LatestBlockVersions']/tctypes:Location"/>
 <xsl:variable name="Ref_PP_NewEntryinDatabase" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PP_NewEntryinDatabase']/tctypes:Value"/>
 <xsl:variable name="Ref_Hexmod_Config_PatchNewBlockVersions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Hexmod_Config_PatchNewBlockVersions']/tctypes:Value"/>
 <xsl:variable name="Ref_HexMod_UEKO_Checksum_Update_Hexfile_1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_UEKO_CheckSum_Update_1']/tctypes:Location"/>
 <xsl:variable name="Ref_HexMod_PatchedNewBlockVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_PatchedNewBlockVersions']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_UEKO_Checksum_Update_Hexfile_2" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_UEKO_CheckSum_Update_2']/tctypes:Location"/>
 <xsl:variable name="Ref_HexMod_Output_NewBlockVersions" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod17_Output_NewBlockVersions']/tctypes:Location"/>
 <xsl:variable name="Ref_HexModx_SWTTNR_PartialFlash_PatchedHexfile" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_SWTTNR_PartialFlash_PatchedHexfile']/tctypes:Location"/>
 
 <xsl:variable name="Ref_Hexfile_CB_PATCH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Hexfile_CB_PATCH']/tctypes:Location"/>
 
<xsl:variable name="Ref_CB_INFOBLOCKID_302_SGIDB3" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_INFOBLOCKID_302_SGIDB3']/tctypes:Value" />
 <xsl:variable name="Ref_CB_INFOBLOCKID_302_ODXFilieID" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_INFOBLOCKID_302_ODXFilieID']/tctypes:Value" />
<xsl:variable name="Ref_CB_INFOBLOCKID_302_ODXFilieVer" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_INFOBLOCKID_302_ODXFilieVer']/tctypes:Value" />
 
 <xsl:variable name="Ref_ReadMatrixInfo_ENDIAN_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ENDIAN_TYPE']/tctypes:Value"/>
 
 <xsl:variable name="Ref_BLOCKS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SIGN_TOOL_BLOCKS']/tctypes:Value"/>
 <xsl:variable name="Ref_SW_BLOCKS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SW_BLOCKS']/tctypes:Value"/>
  <xsl:variable name="Ref_OUTPUTFILENAME_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='OUTPUTFILENAME_FLAG']/tctypes:Value"/>
 <xsl:variable name="Ref_DEFAULTFILENAME" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DEFAULTFILENAME']/tctypes:Value"/>
 <xsl:variable name="Ref_ToolVersion" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ToolVersion']/tctypes:Value"/>
 
 <xsl:variable name="Ref_SB_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SB_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_SB_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='SB_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_EcuSecuSrv0_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EcuSecuSrv0_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_EcuSecuSrv0_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='EcuSecuSrv0_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CTP_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CTP_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CTP_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CTP_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CB_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CB_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CB_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW0_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW0_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW1_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW1_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW2_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW2_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW3_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW3_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW0_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW0_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW1_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW1_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW2_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW2_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_ASW3_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ASW3_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_DS0_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DS0_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_DS0_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DS0_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_DS1_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DS1_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_DS1_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='DS1_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_VDS_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VDS_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_VDS_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='VDS_ENDADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CUST0_STARTADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CUST0_STARTADDRESS']/tctypes:Value"/>
<xsl:variable name="Ref_CUST0_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CUST0_ENDADDRESS']/tctypes:Value"/>
 <!-- Starting point -->
 <xsl:template match="/"> 
	<xsl:call-template name="WriteBack"/>
 </xsl:template>
 
 <!-- The initial template. Starts processing of the toolcahin's data -->
 <xsl:template name="WriteBack">
    <xsl:apply-templates select="document($UseCaseXML)/*"/>
 </xsl:template>

 <!-- recurcively step throug the toolchain's data -->	
 <xsl:template match="*">
	<xsl:choose>
		<xsl:when test="count(. | $Ref_HexMod_CBLite_SignedValues)=1 and $RT_HexMod_CBLite_SignedValues">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_CBLite_SignedValues/*"/>
        </xsl:element>
      </xsl:when>
	<xsl:when test="count(. | $Ref_PIB_ENDADDRESS)=1 and $RT_PIB_ENDADDRESS">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_PIB_ENDADDRESS"/>
			</xsl:element>
		</xsl:when>
	<xsl:when test="count(. | $Ref_FSW_DPTR_CONFIG)=1 and $RT_FSW_DPTR_CONFIG">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_FSW_DPTR_CONFIG/*"/>
				</xsl:element>
		</xsl:when>
				<xsl:when test="count(. | $Ref_GUAM_FLAG)=1 and $RT_GUAM_FLAG">
				<xsl:element name="GUAM_FLAG">
					<xsl:value-of select="$RT_GUAM_FLAG"/>
				</xsl:element>
			</xsl:when>
	<xsl:when test="count(. | $Ref_Flash0_HexFile_GUAM)=1 and $RT_Flash0_HexFile_GUAM">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_Flash0_HexFile_GUAM/*"/>
        </xsl:element>
      </xsl:when>
	      <xsl:when test="count(. | $Ref_CBLite_Signed)=1 and $RT_CBLite_Signed">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_CBLite_Signed/*"/>
        </xsl:element>
      </xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_CBLite_HashValue)=1 and $RT_HexMod_CBLite_HashValue">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_CBLite_HashValue/*"/>
        </xsl:element>
      </xsl:when>
	<xsl:when test="count(. | $Ref_CFGEXP_CBLITE_COMPILED_ADDRESS_START)=1 and $RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_CBLITE_IN_REPROGCONTAINER_START)=1 and $RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_SOURCE_START)=1 and $RT_CFGEXP_NEW_SECUMGR_SOURCE_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_SOURCE_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_SOURCE_END)=1 and $RT_CFGEXP_NEW_SECUMGR_SOURCE_END">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_SOURCE_END"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START)=1 and $RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4"/>
			</xsl:element>
		</xsl:when>	
	    <xsl:when test="count(. | $Ref_HSM_PIB_ADDRESS)=1 and $RT_HSM_PIB_ADDRESS">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_PIB_ADDRESS"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_FDB_START)=1 and $RT_HSM_FDB_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_FDB_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_FDB_OFFSET)=1 and $RT_HSM_FDB_OFFSET">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_FDB_OFFSET"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_PIB_LENGTH)=1 and $RT_HSM_PIB_LENGTH">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_PIB_LENGTH"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_BSW_RELEASE_VALUE)=1 and $RT_BSW_RELEASE_VALUE">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_BSW_RELEASE_VALUE"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_TRIM_ERASE_RANGE)=1 and $RT_TRIM_ERASE_RANGE">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_TRIM_ERASE_RANGE"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_E_NR_IB_Value)=1 and $RT_E_NR_IB_Value">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_E_NR_IB_Value"/>
				</xsl:element>
		</xsl:when>
	<xsl:when test="count(. | $Ref_InjCrv_numInjMaxSys_C)=1 and $RT_InjCrv_numInjMaxSys_C">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_InjCrv_numInjMaxSys_C"/>
	      </xsl:element>
	   </xsl:when>
		
	<xsl:when test="count(. | $Ref_CWEVAB)=1 and $RT_CWEVAB">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_CWEVAB"/>
	      </xsl:element>
   	 </xsl:when>
	
	 <xsl:when test="count(. | $Ref_VDS_FILESLIST)=1 and $RT_VDS_FILESLIST">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_VDS_FILESLIST"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_VariantHexFile)=1 and $RT_VariantHexFile">
	      <xsl:element name="Location">
	        <xsl:copy-of select="$RT_VariantHexFile/*"/>
	      </xsl:element>
    </xsl:when>
	 <xsl:when test="count(. | $Ref_Hexfile_Variant_Code)=1 and $RT_Hexfile_Variant_Code">
	      <xsl:element name="Location">
	        <xsl:copy-of select="$RT_Hexfile_Variant_Code/*"/>
	      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_VC_Hexfile_Variant_Code)=1 and $RT_VC_Hexfile_Variant_Code">
	      <xsl:element name="Location">
	        <xsl:copy-of select="$RT_VC_Hexfile_Variant_Code/*"/>
	      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_Update_VDS_StartAddress)=1 and $RT_Update_VDS_StartAddress">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_Update_VDS_StartAddress"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Ped_Script_HexCompare)=1 and $RT_Ped_Script_HexCompare">
							<xsl:element name="Value">
							<xsl:value-of select="$RT_Ped_Script_HexCompare"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HEX_COMPARE_LOGISTIC_LOG)=1 and $RT_HEX_COMPARE_LOGISTIC_LOG">
							<xsl:element name="Value">
							<xsl:value-of select="$RT_HEX_COMPARE_LOGISTIC_LOG"/>
						</xsl:element>
	</xsl:when>
	  <xsl:when test="count(. | $Ref_Replaced_Infotable_PatchFile)=1 and $RT_Replaced_Infotable_PatchFile">
            <xsl:element name="Location">
              <xsl:copy-of select="$RT_Replaced_Infotable_PatchFile/*"/>
            </xsl:element>
          </xsl:when>
	 <xsl:when test="count(. | $Ref_CustVariableList)=1 and $RT_CustVariableList">
	                  <xsl:element name="Value">
	                    <xsl:value-of select="$RT_CustVariableList" />
	                  </xsl:element>
            </xsl:when>
			 <xsl:when test="count(. | $Ref_InfotablePatchPath)=1 and $RT_InfotablePatchPath">
	                  <xsl:element name="Value">
	                    <xsl:value-of select="$RT_InfotablePatchPath" />
	                  </xsl:element>
            </xsl:when>
	
	<xsl:when test="count(. | $Ref_UpdateCRC32_SB)=1 and $RT_UpdateCRC32_SB">
			<xsl:element name="Variables">
			<xsl:copy-of select="$RT_UpdateCRC32_SB/*"/>
		</xsl:element>
	</xsl:when>
			
	<xsl:when test="count(. | $Ref_UpdateCRC32_TP)=1 and $RT_UpdateCRC32_TP">
			<xsl:element name="Variables">
			<xsl:copy-of select="$RT_UpdateCRC32_TP/*"/>
		</xsl:element>
	</xsl:when>
			
	<xsl:when test="count(. | $Ref_UpdateCRC32_HSM0)=1 and $RT_UpdateCRC32_HSM0">
			<xsl:element name="Variables">
			<xsl:copy-of select="$RT_UpdateCRC32_HSM0/*"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_UpdateCRC32_HSM1)=1 and $RT_UpdateCRC32_HSM1">
			<xsl:element name="Variables">
			<xsl:copy-of select="$RT_UpdateCRC32_HSM1/*"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_SB_CRC32_CHECKSUM)=1 and $RT_SB_CRC32_CHECKSUM">
						<xsl:element name="Value">
						<xsl:value-of select="$RT_SB_CRC32_CHECKSUM"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_TPROT_CRC32_CHECKSUM)=1 and $RT_TPROT_CRC32_CHECKSUM">
						<xsl:element name="Value">
						<xsl:value-of select="$RT_TPROT_CRC32_CHECKSUM"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HSM0_CRC32_CHECKSUM)=1 and $RT_HSM0_CRC32_CHECKSUM">
						<xsl:element name="Value">
						<xsl:value-of select="$RT_HSM0_CRC32_CHECKSUM"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HSM1_CRC32_CHECKSUM)=1 and $RT_HSM1_CRC32_CHECKSUM">
						<xsl:element name="Value">
						<xsl:value-of select="$RT_HSM1_CRC32_CHECKSUM"/>
					</xsl:element>
	</xsl:when>
	
	
	<xsl:when test="count(. | $Ref_Update_CBversion)=1 and $RT_Update_CBversion">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_CBversion"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Update_TPROTversion)=1 and $RT_Update_TPROTversion">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_TPROTversion"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Update_TPROTversion_ToWorkFlow)=1 and $RT_Update_TPROTversion_ToWorkFlow">
		      <xsl:element name="DataValue">
			        <xsl:value-of select="$RT_Update_TPROTversion_ToWorkFlow"/>
		        <xsl:value-of select="'|TPROT_Version|TPROT Version value'"/>
		      </xsl:element>
	 </xsl:when>	
	
	 <xsl:when test="count(. | $Ref_Update_CBversion_ToWorkFlow)=1 and $RT_Update_CBversion_ToWorkFlow">
		      <xsl:element name="DataValue">
		        <xsl:value-of select="$RT_Update_CBversion_ToWorkFlow"/>
		        <xsl:value-of select="'|CB_Version|CB Version value'"/>
			</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_BOOT_MODE_INDEX)=1 and $RT_BOOT_MODE_INDEX">
				<xsl:element name="Value">
					<xsl:copy-of select="$RT_BOOT_MODE_INDEX/*"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_MACHINE_DEV)=1 and $RT_CFGEXP_MACHINE_DEV">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_CFGEXP_MACHINE_DEV"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_MACHINE_TYPE)=1 and $RT_CFGEXP_MACHINE_TYPE">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_CFGEXP_MACHINE_TYPE"/>
				</xsl:element>
		</xsl:when>
	
	<xsl:when test="count(. | $Ref_Update_CBversion_ToReplace)=1 and $RT_Update_CBversion_ToReplace">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_Update_CBversion_ToReplace"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Update_CBversion_ReplaceValue)=1 and $RT_Update_CBversion_ReplaceValue">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_Update_CBversion_ReplaceValue"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexMod_CBVersion_Value_Xml)=1 and $RT_HexMod_CBVersion_Value_Xml">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_HexMod_CBVersion_Value_Xml/*"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HEXMODX_READ_CBTPROTVERSION)=1 and $RT_HEXMODX_READ_CBTPROTVERSION">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_HEXMODX_READ_CBTPROTVERSION"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HWRefValue)=1 and $RT_HWRefValue">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HWRefValue"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_UpdateHW_Ref_ToWorkFlow)=1 and $RT_UpdateHW_Ref_ToWorkFlow">
			<xsl:element name="DataValue">
				<xsl:value-of select="$RT_UpdateHW_Ref_ToWorkFlow"/>
        <xsl:value-of select="'|HW_Reference|HW Reference value'"/>
			</xsl:element>
	</xsl:when>		
	<xsl:when test="count(. | $Ref_UpdateHW_Ref_Job_ToWorkFlow)=1 and $RT_UpdateHW_Ref_Job_ToWorkFlow">
			<xsl:element name="DataValue">
		<xsl:value-of select="$RT_UpdateHW_Ref_Job_ToWorkFlow"/>
        <xsl:value-of select="'|Reference_Job|Reference Job'"/>
			</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_EEP_TYPE)=1 and $RT_ReadMatrixInfo_EEP_TYPE">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_ReadMatrixInfo_EEP_TYPE"/>
	      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_FlashSignedFlag)=1 and $RT_ReadMatrixInfo_FlashSignedFlag">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_FlashSignedFlag"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_HSMSignedFlag)=1 and $RT_ReadMatrixInfo_HSMSignedFlag">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_HSMSignedFlag"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_ECU_TYPE)=1 and $RT_ReadMatrixInfo_ECU_TYPE">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_ReadMatrixInfo_ECU_TYPE"/>
			</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Flash0_AdjustChksum)=1 and $RT_Flash0_AdjustChksum">
							<xsl:element name="Location">
							<xsl:copy-of select="$RT_Flash0_AdjustChksum/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ECU_Mem_Cont)=1 and $RT_ECU_Mem_Cont">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_ECU_Mem_Cont/*"/>
				</xsl:element>
	</xsl:when>	
	<xsl:when test="count(. | $Ref_HexMod_EraseHexFile)=1 and $RT_HexMod_EraseHexFile">
					<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_EraseHexFile/*" />
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_EraseHexFile_To_WorkFlow)=1 and $RT_HexMod_EraseHexFile_To_WorkFlow">
					<xsl:element name="Data">
					<xsl:copy-of select="$RT_HexMod_EraseHexFile_To_WorkFlow/*"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_FLASH_0_AdrMod)=1 and $RT_FLASH_0_AdrMod">
								<xsl:element name="Location">
								<xsl:copy-of select="$RT_FLASH_0_AdrMod/*"/>
						</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_REPROG_DATABLOCKS_TEMPLATE_Flash0)=1 and $RT_REPROG_DATABLOCKS_TEMPLATE_Flash0">
							<xsl:element name="Value">
								<xsl:value-of select="$RT_REPROG_DATABLOCKS_TEMPLATE_Flash0"/>
							</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_REPROGRAM_SIGNATURE_SIZE_Flash0)=1 and $RT_REPROGRAM_SIGNATURE_SIZE_Flash0">
						<xsl:element name="Value">
					<xsl:value-of select="$RT_REPROGRAM_SIGNATURE_SIZE_Flash0"/>
				</xsl:element>
      	</xsl:when>
	<xsl:when test="count(. | $Ref_REPROGRAM_SIGNATURE_SIZE)=1 and $RT_REPROGRAM_SIGNATURE_SIZE">
					<xsl:element name="Value">
				<xsl:value-of select="$RT_REPROGRAM_SIGNATURE_SIZE"/>
			</xsl:element>
      	</xsl:when>
	
	<xsl:when test="count(. | $Ref_SignTool_Reprog_HashValue)=1 and $RT_SignTool_Reprog_HashValue">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_SignTool_Reprog_HashValue/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_LASTRUN_WITHOUTHSM_HASHOUTPUT)=1 and $RT_LASTRUN_WITHOUTHSM_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_WITHOUTHSM_HASHOUTPUT/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_LASTRUN_HEXMOD_HASHOUTPUT)=1 and $RT_LASTRUN_HEXMOD_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_HEXMOD_HASHOUTPUT/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_LASTRUN_FALSH0_HASHOUTPUT)=1 and $RT_LASTRUN_FALSH0_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_FALSH0_HASHOUTPUT/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_LASTRUN_Reprog_HASHOUTPUT)=1 and $RT_LASTRUN_Reprog_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_Reprog_HASHOUTPUT/*"/>
				</xsl:element>
	</xsl:when>
		<xsl:when test="count(. | $Ref_LASTRUN_GUAM_HASHOUTPUT)=1 and $RT_LASTRUN_GUAM_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_GUAM_HASHOUTPUT/*"/>
				</xsl:element>
	</xsl:when>
		
	<xsl:when test="count(. | $Ref_NrDatapointers)=1 and $RT_NrDatapointers">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_NrDatapointers"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_RawFileUpdated)=1 and $RT_RawFileUpdated">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_RawFileUpdated/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_RawFileNameUpdated)=1 and $RT_RawFileNameUpdated">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_RawFileNameUpdated" />
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_CHECKSUMME_FILE)=1 and $RT_CHECKSUMME_FILE">
					<xsl:element name="Location">
						<xsl:copy-of select="$RT_CHECKSUMME_FILE/*"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_FEE_Report_ParaSet_File)=1 and $RT_FEE_Report_ParaSet_File">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_FEE_Report_ParaSet_File/*"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Unknownoutput_log)=1 and $RT_Unknownoutput_log">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_Unknownoutput_log/*"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Knownoutput_log_To_WorkFlow)=1 and $RT_Knownoutput_log_To_WorkFlow">
				<xsl:element name="Data">
				<xsl:copy-of select="$RT_Knownoutput_log_To_WorkFlow/*"/>
			</xsl:element>
		</xsl:when>
	<xsl:when test="count(. | $Ref_Unknownoutput_log_To_WorkFlow)=1 and $RT_Unknownoutput_log_To_WorkFlow">
				<xsl:element name="Data">
				<xsl:copy-of select="$RT_Unknownoutput_log_To_WorkFlow/*"/>
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Knownoutput_log)=1 and $RT_Knownoutput_log">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_Knownoutput_log/*"/>
			</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HEX_CMP)=1 and $RT_HEX_CMP">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_HEX_CMP/*"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_HEX_CMP_UN)=1 and $RT_HEX_CMP_UN">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_HEX_CMP_UN/*"/>
      </xsl:element>
    </xsl:when>
	
	<xsl:when test="count(. | $Ref_BC_Gen_log)=1 and $RT_BC_Gen_log">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_BC_Gen_log/*"/>
			</xsl:element>
		</xsl:when>

    <xsl:when test="count(. | $Ref_PAT_INF)=1 and $RT_PAT_INF">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_PAT_INF/*"/>
      </xsl:element>
    </xsl:when>
    
		<xsl:when test="count(. | $Ref_BC_Gen_Log_Complete)=1 and $RT_BC_Gen_Log_Complete">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_BC_Gen_Log_Complete/*"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_Patch_Info)=1 and $RT_Patch_Info">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_Patch_Info/*"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PAT_INF_To_WorkFlow)=1 and $RT_PAT_INF_To_WorkFlow">
				<xsl:element name="Data">
				<xsl:copy-of select="$RT_PAT_INF_To_WorkFlow/*"/>
			</xsl:element>
		</xsl:when>		
	<xsl:when test="count(. | $Ref_Hex_Compare_File)=1 and $RT_Hex_Compare_File">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_Hex_Compare_File/*"/>
			</xsl:element>
	</xsl:when>	
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_RAWMCSVersion)=1 and $RT_ReadMatrixInfo_RAWMCSVersion">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_ReadMatrixInfo_RAWMCSVersion" />
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_VariableListFile)=1 and $RT_ReadMatrixInfo_VariableListFile">
				        <xsl:element name="Value">
				          <xsl:value-of select="$RT_ReadMatrixInfo_VariableListFile"/>
				        </xsl:element>
        </xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_Reprog_SignedValues)=1 and $RT_HexMod_Reprog_SignedValues">
							<xsl:element name="Location">
							<xsl:copy-of select="$RT_HexMod_Reprog_SignedValues/*"/>
						</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_Reprog_HashValue)=1 and $RT_HexMod_Reprog_HashValue">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_Reprog_HashValue/*"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_UpdateCheckumsinUseCase_Data)=1 and $RT_UpdateCheckumsinUseCase_Data">
					<xsl:element name="Variables">
					<xsl:copy-of select="$RT_UpdateCheckumsinUseCase_Data/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Updated_CHECKSUM_VALUE)=1 and $RT_Updated_CHECKSUM_VALUE">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_Updated_CHECKSUM_VALUE"/>
	      </xsl:element>
    	</xsl:when>
    	
    	<xsl:when test="count(. | $Ref_CB_INFOBLOCKID_302)=1 and $RT_CB_INFOBLOCKID_302">
		      <xsl:element name="Value">
		        <xsl:value-of select="$RT_CB_INFOBLOCKID_302"/>
		      </xsl:element>
    	</xsl:when>
    	
	<xsl:when test="count(. | $Ref_HEXMODX_CHECKSUM_SCRIPT)=1 and $RT_HEXMODX_CHECKSUM_SCRIPT">
						<xsl:element name="Value">
							<xsl:value-of select="$RT_HEXMODX_CHECKSUM_SCRIPT"/>
						</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_REPROG_DATABLOCKS_TEMPLATE)=1 and $RT_REPROG_DATABLOCKS_TEMPLATE">
						<xsl:element name="Value">
							<xsl:value-of select="$RT_REPROG_DATABLOCKS_TEMPLATE"/>
						</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_CHECKSUMS_XMLFILE)=1 and $RT_CHECKSUMS_XMLFILE">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_CHECKSUMS_XMLFILE/*"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_DATA_POINTERS_FILE)=1 and $RT_DATA_POINTERS_FILE">
							<xsl:element name="Location">
								<xsl:copy-of select="$RT_DATA_POINTERS_FILE/*"/>
							</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_FSW_AddressModel_File)=1 and $RT_FSW_AddressModel_File">
						<xsl:element name="Location">
							<xsl:copy-of select="$RT_FSW_AddressModel_File/*"/>
						</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_SignedHexfile_Complete)=1 and $RT_HexMod_SignedHexfile_Complete">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_HexMod_SignedHexfile_Complete/*"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_A2L_FILE_CUST_ToUsecase)=1 and $RT_A2L_FILE_CUST_ToUsecase">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_A2L_FILE_CUST_ToUsecase/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Flash0_HexFile_Full)=1 and $RT_Flash0_HexFile_Full">
					<xsl:element name="Location">
						<xsl:copy-of select="$RT_Flash0_HexFile_Full/*"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_Flash0_Signed)=1 and $RT_Flash0_Signed">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_Flash0_Signed/*"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Flash0)=1 and $RT_Flash0">
							<xsl:element name="Location">
							<xsl:copy-of select="$RT_Flash0/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Create_Flash_0)=1 and $RT_Create_Flash_0">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_Create_Flash_0"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_Flash0_SignedValues)=1 and $RT_HexMod_Flash0_SignedValues">
							<xsl:element name="Location">
							<xsl:copy-of select="$RT_HexMod_Flash0_SignedValues/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexMod_SignedValues)=1 and $RT_HexMod_SignedValues">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_SignedValues/*"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_Flash0_HashValue)=1 and $RT_HexMod_Flash0_HashValue">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_Flash0_HashValue/*"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_Flash0_GUAM_HashValue)=1 and $RT_HexMod_Flash0_GUAM_HashValue">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_Flash0_GUAM_HashValue/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexMod_HashValue)=1 and $RT_HexMod_HashValue">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_HexMod_HashValue/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_WithoutHSM_HashValue)=1 and $RT_HexMod_WithoutHSM_HashValue">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_HexMod_WithoutHSM_HashValue/*"/>
				</xsl:element>
	</xsl:when>
	
	
	
	<xsl:when test="count(. | $Ref_Update_OTP_Ref_Code_To_WorkFlow)=1 and $RT_Update_OTP_Ref_Code_To_WorkFlow">
				<xsl:element name="DataValue">
					<xsl:value-of select="$RT_Update_OTP_Ref_Code_To_WorkFlow" />
					<xsl:value-of select="'|OTP_RefCode|OTP RefCode value'"/>
				</xsl:element>
	</xsl:when>	
	<xsl:when test="count(. | $Ref_UpdateOTP_Ref_ToWorkFlow)=1 and $RT_UpdateOTP_Ref_ToWorkFlow">
	          <xsl:element name="DataValue">
	            <xsl:value-of select="$RT_UpdateOTP_Ref_ToWorkFlow"/>
	            <xsl:value-of select="'|OTP_Reference|OTP Reference value'"/>
	          </xsl:element>
    	</xsl:when>
	<xsl:when test="count(. | $Ref_Update_OTP_Ref_Code_To_UseCase)=1 and $RT_Update_OTP_Ref_Code_To_UseCase">
	      <xsl:element name="Value">
	      <xsl:value-of select="$RT_Update_OTP_Ref_Code_To_UseCase"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_OTP_Key)=1 and $RT_OTP_Key">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_OTP_Key"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_OTP_Overview)=1 and $RT_OTP_Overview">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_OTP_Overview"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_OTP_Key_Overview_File)=1 and $RT_OTP_Key_Overview_File">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_OTP_Key_Overview_File/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_UpdateOTP_Ref_InUseCase_Data)=1 and $RT_UpdateOTP_Ref_InUseCase_Data">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_UpdateOTP_Ref_InUseCase_Data"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_LabelAddress_Cust_To_WorkFlow)=1 and $RT_LabelAddress_Cust_To_WorkFlow">
					<xsl:element name="Data">
					<xsl:copy-of select="$RT_LabelAddress_Cust_To_WorkFlow/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_SignedHexfile)=1 and $RT_HexMod_SignedHexfile">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_HexMod_SignedHexfile/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_SignedHexfile_To_WorkFlow)=1 and $RT_HexMod_SignedHexfile_To_WorkFlow">
					<xsl:element name="Data">
					<xsl:copy-of select="$RT_HexMod_SignedHexfile_To_WorkFlow/*"/>
				</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ENDIAN_TYPE)=1 and $RT_ENDIAN_TYPE">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_ENDIAN_TYPE"/>
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_ENDIAN_TYPE_CNT)=1 and $RT_ENDIAN_TYPE_CNT">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_ENDIAN_TYPE_CNT"/>
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HEXMODX_PATCH_MAIN_XML)=1 and $RT_HEXMODX_PATCH_MAIN_XML">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_HEXMODX_PATCH_MAIN_XML"/>
	      </xsl:element>
    	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_DebugSigned)=1 and $RT_ReadMatrixInfo_DebugSigned">
		<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_DebugSigned"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_HSMOpt)=1 and $RT_ReadMatrixInfo_HSMOpt">
		<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_HSMOpt"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_HSMSigned)=1 and $RT_ReadMatrixInfo_HSMSigned">
		<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_HSMSigned"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_FlashOpt)=1 and $RT_ReadMatrixInfo_FlashOpt">
		<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_FlashOpt"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_FlashSigned)=1 and $RT_ReadMatrixInfo_FlashSigned">
		<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_FlashSigned"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_CNT_TYPE)=1 and $RT_CNT_TYPE">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_CNT_TYPE"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_E_STATUS_PO)=1 and $RT_E_STATUS_PO">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_E_STATUS_PO"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ContainerType_ID)=1 and $RT_ContainerType_ID">
					<xsl:element name="ContainerType_ID">
					<xsl:value-of select="$RT_ContainerType_ID"/>
				</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_RAW_CONTAINER)=1 and $RT_RAW_CONTAINER">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_RAW_CONTAINER"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_EELayout)=1 and $RT_ReadMatrixInfo_EELayout">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_EELayout"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_WFSSELECT)=1 and $RT_ReadMatrixInfo_WFSSELECT">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_WFSSELECT"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_FAZITDB1)=1 and $RT_ReadMatrixInfo_FAZITDB1">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_FAZITDB1"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_KUNDENMARKE)=1 and $RT_ReadMatrixInfo_KUNDENMARKE">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_KUNDENMARKE"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Imo_idxLab_C_VW_Value)=1 and $RT_Imo_idxLab_C_VW_Value">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_Imo_idxLab_C_VW_Value"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_KONSERVE_PATCHANDCHECK_LABELS)=1 and $RT_KONSERVE_PATCHANDCHECK_LABELS">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_KONSERVE_PATCHANDCHECK_LABELS"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_Imo_idxLab_C_VW)=1 and $RT_Imo_idxLab_C_VW">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_Imo_idxLab_C_VW"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_ReadMatrixInfo_SY_WFS)=1 and $RT_ReadMatrixInfo_SY_WFS">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ReadMatrixInfo_SY_WFS"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_KDNR_Parameter)=1 and $RT_KDNR_Parameter">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_KDNR_Parameter"/>
	      </xsl:element>
    	</xsl:when>
	
	<xsl:when test="count(. | $Ref_RELEASEPST_CUST)=1 and $RT_RELEASEPST_CUST">
	      <xsl:element name="Location">
	        <xsl:copy-of select="$RT_RELEASEPST_CUST/*"/>
	      </xsl:element>
    	</xsl:when>
	
	 <xsl:when test="count(. | $Ref_RELEASEPST)=1 and $RT_RELEASEPST">
			<xsl:element name="Location">
			<xsl:copy-of select="$RT_RELEASEPST/*"/>
		</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexModx_SignedHexfile_Complete_To_WorkFlow)=1 and $RT_HexModx_SignedHexfile_Complete_To_WorkFlow">
					<xsl:element name="Data">
					<xsl:copy-of select="$RT_HexModx_SignedHexfile_Complete_To_WorkFlow/*"/>
				</xsl:element>
		</xsl:when>
	
	<xsl:when test="count(. | $Ref_Signed_Hexfile)=1 and $RT_Signed_Hexfile">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_Signed_Hexfile/*"/>
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexModx_SWTTNR_PatchedHexfile)=1 and $RT_HexModx_SWTTNR_PatchedHexfile">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_HexModx_SWTTNR_PatchedHexfile/*"/>
			</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_HexModx_PatchedHexfile)=1 and $RT_HexModx_PatchedHexfile">
		<xsl:element name="Location">
			<xsl:copy-of select="$RT_HexModx_PatchedHexfile/*" />
		</xsl:element>
	</xsl:when>	
	
	 <xsl:when test="count(. | $Ref_Patch_Script_File)=1 and $RT_Patch_Script_File">
	      	<xsl:element name="Location">
	      		<xsl:copy-of select="$RT_Patch_Script_File/*"/>
	      	</xsl:element>
       </xsl:when>
	
	 <xsl:when test="count(. | $Ref_DoSerPatchFile)=1 and $RT_DoSerPatchFile">
	      				<xsl:element name="Location">
	      				<xsl:copy-of select="$RT_DoSerPatchFile/*"/>
	      			</xsl:element>
	 </xsl:when>
	 
	 <xsl:when test="count(. | $Ref_PatchPath)=1 and $RT_PatchPath">
	                  <xsl:element name="Value">
	                    <xsl:value-of select="$RT_PatchPath" />
	                  </xsl:element>
            </xsl:when>
	 <xsl:when test="count(. | $Ref_Fee_VariableList)=1 and $RT_Fee_VariableList">
	                  <xsl:element name="Value">
	                    <xsl:value-of select="$RT_Fee_VariableList" />
	                  </xsl:element>
            </xsl:when>
	
	<xsl:when test="count(. | $Ref_HexModX_IntegrationFile_withoutData)=1 and $RT_HexModX_IntegrationFile_withoutData">
					<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexModX_IntegrationFile_withoutData/*" />
					</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexModX_AppliedFile_withoutProg)=1 and $RT_HexModX_AppliedFile_withoutProg">
			<xsl:element name="Location">
			 <xsl:copy-of select="$RT_HexModX_AppliedFile_withoutProg/*" />
			</xsl:element>
	</xsl:when>
			<xsl:when test="count(. | $Ref_HexModX_MergedHexfile_withoutData)=1 and $RT_HexModX_MergedHexfile_withoutData">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_HexModX_MergedHexfile_withoutData/*" />
			</xsl:element>
	</xsl:when>
		<xsl:when test="count(. | $Ref_Hexfile_Infotable_Patched)=1 and $RT_Hexfile_Infotable_Patched">
			<xsl:element name="Location">
				<xsl:copy-of select="$RT_Hexfile_Infotable_Patched/*" />
			</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_User_LastName)=1 and $RT_User_LastName">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_LastName"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_FirstName)=1 and $RT_User_FirstName">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_FirstName"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_User_Company)=1 and $RT_User_Company">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_Company"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_Department)=1 and $RT_User_Department">
				<xsl:element name="Value">
			<xsl:value-of select="$RT_User_Department"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_Role)=1 and $RT_User_Role">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_User_Role"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_ZIP)=1 and $RT_User_ZIP">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_ZIP"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_City)=1 and $RT_User_City">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_City"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_Phone)=1 and $RT_User_Phone">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_Phone"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_Fax)=1 and $RT_User_Fax">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_User_Fax"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_User_EMail)=1 and $RT_User_EMail">
					<xsl:element name="Value">
					<xsl:value-of select="$RT_User_EMail"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_User_Address)=1 and $RT_User_Address">
							<xsl:element name="Value">
							<xsl:value-of select="$RT_User_Address"/>
						</xsl:element>
		</xsl:when>
	
	<xsl:when test="count(. | $Ref_Eep_EnvRamClr_CW)=1 and $RT_Eep_EnvRamClr_CW">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_Eep_EnvRamClr_CW"/>
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_Eep_EnFirstInit_CW)=1 and $RT_Eep_EnFirstInit_CW">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_Eep_EnFirstInit_CW"/>
					</xsl:element>
		</xsl:when>
	
	
	<xsl:when test="count(. | $Ref_BasSvrAppl_EepPrgVer_C)=1 and $RT_BasSvrAppl_EepPrgVer_C">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_BasSvrAppl_EepPrgVer_C"/>
				</xsl:element>
			</xsl:when>
			<xsl:when test="count(. | $Ref_BasSvrAppl_EepPartNr_C)=1 and $RT_BasSvrAppl_EepPartNr_C">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_BasSvrAppl_EepPartNr_C"/>
				</xsl:element>
		</xsl:when>
		
		
		<xsl:when test="count(. | $Ref_BasSvrAppl_EepODXFileID_C)=1 and $RT_BasSvrAppl_EepODXFileID_C">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_BasSvrAppl_EepODXFileID_C"/>
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_BasSvrAppl_EepODXFileVer_C)=1 and $RT_BasSvrAppl_EepODXFileVer_C">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_BasSvrAppl_EepODXFileVer_C"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_SECURITY_VARIANT)=1 and $RT_SECURITY_VARIANT">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_SECURITY_VARIANT"/>
		</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_SIGNING_METHOD_VALUE)=1 and $RT_SIGNING_METHOD_VALUE">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SIGNING_METHOD_VALUE"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PP_IBAddressList)=1 and $RT_PP_IBAddressList">
				<xsl:element name="Value">
				<xsl:copy-of select="$RT_PP_IBAddressList"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_HexMod_AddressModel)=1 and $RT_HexMod_AddressModel">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_HexMod_AddressModel/*"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_ToolConfig)=1 and $RT_ToolConfig">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_ToolConfig/*"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_AddressLayout_Value)=1 and $RT_AddressLayout_Value">
				<xsl:element name="AddressLayout">
				<xsl:value-of select="$RT_AddressLayout_Value"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_FLASH_CONFIG_SY)=1 and $RT_FLASH_CONFIG_SY">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_FLASH_CONFIG_SY"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_EOL_CB_SY)=1 and $RT_EOL_CB_SY">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_EOL_CB_SY"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_DIAG_SVRPTCOL_SY)=1 and $RT_DIAG_SVRPTCOL_SY">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_DIAG_SVRPTCOL_SY"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_SIA_GENR_SY)=1 and $RT_SIA_GENR_SY">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_SIA_GENR_SY"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_FlashLayoutModel)=1 and $RT_FlashLayoutModel">
				<xsl:element name="FlashBlocks">
				<xsl:copy-of select="$RT_FlashLayoutModel"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_UpdateSGIDB1inUseCase_Data)=1 and $RT_UpdateSGIDB1inUseCase_Data">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_UpdateSGIDB1inUseCase_Data"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_HESRV_MasterSlave)=1 and $RT_ReadMatrixInfo_HESRV_MasterSlave">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_HESRV_MasterSlave"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PROT_TYPE)=1 and $RT_PROT_TYPE">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_PROT_TYPE"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_SECURITY_ACCESS)=1 and $RT_SECURITY_ACCESS">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_SECURITY_ACCESS"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_FEOLOC_Select)=1 and $RT_ReadMatrixInfo_FEOLOC_Select">
				<xsl:element name="FEOLOC_Select">
				<xsl:value-of select="$RT_ReadMatrixInfo_FEOLOC_Select"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PART_PROG_SY)=1 and $RT_PART_PROG_SY">
				<xsl:element name="Value">
				<xsl:value-of select="$RT_PART_PROG_SY"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_Update_ALFID_EraseMemLen)=1 and $RT_Update_ALFID_EraseMemLen">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_EraseMemLen"/>
			</xsl:element>
		</xsl:when>
    <xsl:when test="count(. | $Ref_Update_VW80126Version_Value)=1 and $RT_Update_VW80126Version_Value">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_Update_VW80126Version_Value"/>
      </xsl:element>
    </xsl:when>
      
		<xsl:when test="count(. | $Ref_Update_ALFID_EraseMemAdr)=1 and $RT_Update_ALFID_EraseMemAdr">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_EraseMemAdr"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_Update_ALFID_ReqDownLoadMemLen)=1 and $RT_Update_ALFID_ReqDownLoadMemLen">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_ReqDownLoadMemLen"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_Update_ALFID_ReqDownLoadMemAdr)=1 and $RT_Update_ALFID_ReqDownLoadMemAdr">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_ReqDownLoadMemAdr"/>
			</xsl:element>
		</xsl:when>		
		<xsl:when test="count(. | $Ref_Update_ALFID_CheckMemLen)=1 and $RT_Update_ALFID_CheckMemLen">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_CheckMemLen"/>
			</xsl:element>
		</xsl:when>		

		<xsl:when test="count(. | $Ref_Update_ALFID_RoutiContrCheckMemLen)=1 and $RT_Update_ALFID_RoutiContrCheckMemLen">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_RoutiContrCheckMemLen"/>
			</xsl:element>
		</xsl:when>				

		<xsl:when test="count(. | $Ref_Update_ALFID_CheckMemAdr)=1 and $RT_Update_ALFID_CheckMemAdr">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_ALFID_CheckMemAdr"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_Update_DFID)=1 and $RT_Update_DFID">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_Update_DFID"/>
			</xsl:element>
		</xsl:when>
    
    <xsl:when test="count(. | $Ref_HexMod_AES_KEY_Value_Xml)=1 and $RT_HexMod_AES_KEY_Value_Xml">
      <xsl:element name="Location">
        <xsl:copy-of select="$RT_HexMod_AES_KEY_Value_Xml/*"/>
      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_MAC_UC_ParaSet_File)=1 and $RT_MAC_UC_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_MAC_UC_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_MAC_UP_ParaSet_File)=1 and $RT_MAC_UP_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_MAC_UP_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_RSA_Key_ParaSet_File)=1 and $RT_RSA_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_RSA_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_ECC_Key_ParaSet_File)=1 and $RT_ECC_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_ECC_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>
    
    


		<xsl:when test="count(. | $Ref_ReadMatrixInfo_DFID_FLAG)=1 and $RT_ReadMatrixInfo_DFID_FLAG">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_DFID_FLAG"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_COMPRESSION)=1 and $RT_ReadMatrixInfo_COMPRESSION">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_COMPRESSION"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_ENCRYPTION)=1 and $RT_ReadMatrixInfo_ENCRYPTION">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_ENCRYPTION"/>
			</xsl:element>
		</xsl:when>

    <xsl:when test="count(. | $Ref_ReadMatrixInfo_ODX_CREATE_COMPRESSION)=1 and $RT_ReadMatrixInfo_ODX_CREATE_COMPRESSION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_ReadMatrixInfo_ODX_CREATE_COMPRESSION"/>
      </xsl:element>
    </xsl:when>

    <xsl:when test="count(. | $Ref_ReadMatrixInfo_ODX_CREATE_ENCRYPTION)=1 and $RT_ReadMatrixInfo_ODX_CREATE_ENCRYPTION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_ReadMatrixInfo_ODX_CREATE_ENCRYPTION"/>
      </xsl:element>
    </xsl:when>

   

    <xsl:when test="count(. | $Ref_ReadMatrixInfo_ODX_EXTRN_COMPRESSION)=1 and $RT_ReadMatrixInfo_ODX_EXTRN_COMPRESSION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_ReadMatrixInfo_ODX_EXTRN_COMPRESSION"/>
      </xsl:element>
    </xsl:when>

    <xsl:when test="count(. | $Ref_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION)=1 and $RT_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION">
      <xsl:element name="Value">
        <xsl:value-of select="$RT_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION"/>
      </xsl:element>
    </xsl:when>
       
		
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_DFID)=1 and $RT_ReadMatrixInfo_DFID">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_ReadMatrixInfo_DFID"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_Tools)=1 and $RT_Tools">
			<xsl:element name="Tools">
				<xsl:copy-of select="$RT_Tools/*" />
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_Update_PROGPRECOND_Values)=1 and $RT_Update_PROGPRECOND_Values">
			<xsl:element name="PRECOND">
				<xsl:copy-of select="$RT_Update_PROGPRECOND_Values/*" />
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_FlashLayout_Conf_File)=1 and $RT_FlashLayout_Conf_File">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_FlashLayout_Conf_File/*"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_CMBTYP_SY)=1 and $RT_CMBTYP_SY">
		      	<xsl:element name="CMBTYP_SY">
		        		<xsl:value-of select="$RT_CMBTYP_SY"/>
		      	</xsl:element>
    		</xsl:when>
    		
<xsl:when test="count(. | $Ref_AddressList)=1 and $RT_AddressList">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_AddressList/*"/>
			</xsl:element>
		</xsl:when>   
		
		<xsl:when test="count(. | $Ref_TSAppCompat)=1 and $RT_TSAppCompat">
						<xsl:element name="Value">
							<xsl:value-of select="$RT_TSAppCompat" />
						</xsl:element>
			</xsl:when>			
	<xsl:when test="count(. | $Ref_SignTool_HashValue)=1 and $RT_SignTool_HashValue">
							<xsl:element name="Location">
							<xsl:copy-of select="$RT_SignTool_HashValue/*"/>
						</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_ClientIP)=1 and $RT_ClientIP">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_ClientIP" />
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_ClientName)=1 and $RT_ClientName">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_ClientName" />
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_DomainName)=1 and $RT_DomainName">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_DomainName" />
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_StationName)=1 and $RT_StationName">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_StationName" />
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_UserName)=1 and $RT_UserName">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_UserName" />
					</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_PART_PROG_SY)=1 and $RT_ReadMatrixInfo_PART_PROG_SY">
						<xsl:element name="Value">
						<xsl:value-of select="$RT_ReadMatrixInfo_PART_PROG_SY"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_HexMod_InfoTableLog)=1 and $RT_HexMod_InfoTableLog">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_InfoTableLog/*"/>
					</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_HEXMOD_READ_BLOCKVERSION)=1 and $RT_HEXMOD_READ_BLOCKVERSION">
								<xsl:element name="Value">
								<xsl:value-of select="$RT_HEXMOD_READ_BLOCKVERSION"/>
							</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_PP_New_SWBlock_Versions)=1 and $RT_PP_New_SWBlock_Versions">
						<xsl:element name="Value">
						<xsl:copy-of select="$RT_PP_New_SWBlock_Versions"/>
					</xsl:element>
				</xsl:when>
				<xsl:when test="count(. | $Ref_PP_Latest_SWBlock_Versions)=1 and $RT_PP_Latest_SWBlock_Versions">
						<xsl:element name="Value">
						<xsl:copy-of select="$RT_PP_Latest_SWBlock_Versions"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_PP_VarList_New_SWBlock_Versions)=1 and $RT_PP_VarList_New_SWBlock_Versions">
						<xsl:element name="Variables">
						<xsl:copy-of select="$RT_PP_VarList_New_SWBlock_Versions/*"/>
					</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PP_VarList_New_SWBlock_Versions_ToNextPD)=1 and $RT_PP_VarList_New_SWBlock_Versions_ToNextPD">
								<xsl:element name="Variables">
								<xsl:copy-of select="$RT_PP_VarList_New_SWBlock_Versions_ToNextPD/*"/>
							</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_Hexmod_Config_PatchLatestBlockVersions)=1 and $RT_Hexmod_Config_PatchLatestBlockVersions">
						<xsl:element name="Value">
						<xsl:copy-of select="$RT_Hexmod_Config_PatchLatestBlockVersions"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_HexMod_PatchedLatestBlockVersion)=1 and $RT_HexMod_PatchedLatestBlockVersion">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_PatchedLatestBlockVersion/*"/>
					</xsl:element>
		</xsl:when>
		
			<xsl:when test="count(. | $Ref_HexMod_Output_LatestBlockVersions)=1 and $RT_HexMod_Output_LatestBlockVersions">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_Output_LatestBlockVersions/*"/>
					</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_PP_NewEntryinDatabase)=1 and $RT_PP_NewEntryinDatabase">
						<xsl:element name="Value">
						<xsl:copy-of select="$RT_PP_NewEntryinDatabase"/>
					</xsl:element>
		</xsl:when>
			<xsl:when test="count(. | $Ref_Hexmod_Config_PatchNewBlockVersions)=1 and $RT_Hexmod_Config_PatchNewBlockVersions">
						<xsl:element name="Value">
						<xsl:copy-of select="$RT_Hexmod_Config_PatchNewBlockVersions"/>
					</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_HexMod_UEKO_Checksum_Update_Hexfile_1)=1 and $RT_HexMod_UEKO_Checksum_Update_Hexfile_1">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_UEKO_Checksum_Update_Hexfile_1/*"/>
					</xsl:element>
		</xsl:when>
			<xsl:when test="count(. | $Ref_HexMod_PatchedNewBlockVersion)=1 and $RT_HexMod_PatchedNewBlockVersion">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_PatchedNewBlockVersion/*"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_HexMod_UEKO_Checksum_Update_Hexfile_2)=1 and $RT_HexMod_UEKO_Checksum_Update_Hexfile_2">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_UEKO_Checksum_Update_Hexfile_2/*"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_HexMod_Output_NewBlockVersions)=1 and $RT_HexMod_Output_NewBlockVersions">
						<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexMod_Output_NewBlockVersions/*"/>
					</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_HexModx_SWTTNR_PartialFlash_PatchedHexfile)=1 and $RT_HexModx_SWTTNR_PartialFlash_PatchedHexfile">
			<xsl:element name="Location">
			<xsl:copy-of select="$RT_HexModx_SWTTNR_PartialFlash_PatchedHexfile/*"/>
			</xsl:element>
		</xsl:when>
		
		<xsl:when test="count(. | $Ref_Hexfile_CB_PATCH)=1 and $RT_Hexfile_CB_PATCH">
					<xsl:element name="Location">
					<xsl:copy-of select="$RT_Hexfile_CB_PATCH/*"/>
					</xsl:element>
				</xsl:when>
				
				<xsl:when test="count(. | $Ref_CB_INFOBLOCKID_302_SGIDB3)=1 and $RT_CB_INFOBLOCKID_302_SGIDB3">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_CB_INFOBLOCKID_302_SGIDB3" />
					</xsl:element>
				</xsl:when>
				
				<xsl:when test="count(. | $Ref_CB_INFOBLOCKID_302_ODXFilieID)=1 and $RT_CB_INFOBLOCKID_302_ODXFilieID">
					<xsl:element name="Value">
						<xsl:value-of select="$RT_CB_INFOBLOCKID_302_ODXFilieID" />
					</xsl:element>
				</xsl:when>
				
				<xsl:when test="count(. | $Ref_CB_INFOBLOCKID_302_ODXFilieVer)=1 and $RT_CB_INFOBLOCKID_302_ODXFilieVer">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_CB_INFOBLOCKID_302_ODXFilieVer" />
				</xsl:element>
				</xsl:when>
		
		<xsl:when test="count(. | $Ref_ReadMatrixInfo_ENDIAN_TYPE)=1 and $RT_ReadMatrixInfo_ENDIAN_TYPE">
	      <xsl:element name="Value">
	        <xsl:value-of select="$RT_ReadMatrixInfo_ENDIAN_TYPE"/>
	      </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_FEE_EMULATION_TYPE_HSM)=1 and $RT_FEE_EMULATION_TYPE_HSM">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_FEE_EMULATION_TYPE_HSM"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_FEE_EMULATION_TYPE_HOST)=1 and $RT_FEE_EMULATION_TYPE_HOST">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_FEE_EMULATION_TYPE_HOST"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_EEE_TYPE)=1 and $RT_EEE_TYPE">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_EEE_TYPE"/>
			</xsl:element>
		</xsl:when>	
	<xsl:when test="count(. | $Ref_ABM_START_ADDRESS)=1 and $RT_ABM_START_ADDRESS">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_ABM_START_ADDRESS"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_ABM_END_ADDRESS)=1 and $RT_ABM_END_ADDRESS">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_ABM_END_ADDRESS"/>
        </xsl:element>
    </xsl:when>	
	
	<xsl:when test="count(. | $Ref_AES_Key_ParaSet_File)=1 and $RT_AES_Key_ParaSet_File">
				<xsl:element name="Location">
				<xsl:copy-of select="$RT_AES_Key_ParaSet_File/*"/>
			</xsl:element>
		</xsl:when>
		
	<xsl:when test="count(. | $Ref_CERTIFICATE_SIZE)=1 and $RT_CERTIFICATE_SIZE">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_CERTIFICATE_SIZE"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_PatchedHexfile)=1 and $RT_HexMod_PatchedHexfile">
								<xsl:element name="Location">
								<xsl:copy-of select="$RT_HexMod_PatchedHexfile/*"/>
							</xsl:element>
		</xsl:when>		
		
		<xsl:when test="count(. | $Ref_HexModX_HSMTrimmed_Hex)=1 and $RT_HexModX_HSMTrimmed_Hex">
					<xsl:element name="Location">
						<xsl:copy-of select="$RT_HexModX_HSMTrimmed_Hex/*" />
					</xsl:element>
	</xsl:when>
	
	<xsl:when test="count(. | $Ref_BLOCKS)=1 and $RT_BLOCKS">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_BLOCKS"/>
        </xsl:element>
    </xsl:when>
		<xsl:when test="count(. | $Ref_SW_BLOCKS)=1 and $RT_SW_BLOCKS">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_SW_BLOCKS"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_OUTPUTFILENAME_FLAG)=1 and $RT_OUTPUTFILENAME_FLAG">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_OUTPUTFILENAME_FLAG"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_DEFAULTFILENAME)=1 and $RT_DEFAULTFILENAME">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_DEFAULTFILENAME"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_ToolVersion)=1 and $RT_ToolVersion">
        <xsl:element name="Value">
          <xsl:value-of select="$RT_ToolVersion"/>
        </xsl:element>
    </xsl:when>
	<xsl:when test="count(. | $Ref_SB_STARTADDRESS)=1 and $RT_SB_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_SB_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_SB_ENDADDRESS)=1 and $RT_SB_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_SB_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_EcuSecuSrv0_STARTADDRESS)=1 and $RT_EcuSecuSrv0_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_EcuSecuSrv0_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_EcuSecuSrv0_ENDADDRESS)=1 and $RT_EcuSecuSrv0_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_EcuSecuSrv0_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CTP_STARTADDRESS)=1 and $RT_CTP_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CTP_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CTP_ENDADDRESS)=1 and $RT_CTP_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CTP_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CB_STARTADDRESS)=1 and $RT_CB_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CB_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CB_ENDADDRESS)=1 and $RT_CB_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CB_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW0_STARTADDRESS)=1 and $RT_ASW0_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW0_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW0_ENDADDRESS)=1 and $RT_ASW0_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW0_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW1_STARTADDRESS)=1 and $RT_ASW1_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW1_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW1_ENDADDRESS)=1 and $RT_ASW1_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW1_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW2_STARTADDRESS)=1 and $RT_ASW2_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW2_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW2_ENDADDRESS)=1 and $RT_ASW2_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW2_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW3_STARTADDRESS)=1 and $RT_ASW3_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW3_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW3_ENDADDRESS)=1 and $RT_ASW3_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW3_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW3_STARTADDRESS)=1 and $RT_ASW3_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW3_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_ASW3_ENDADDRESS)=1 and $RT_ASW3_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_ASW3_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_DS0_STARTADDRESS)=1 and $RT_DS0_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_DS0_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_DS0_ENDADDRESS)=1 and $RT_DS0_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_DS0_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_DS1_STARTADDRESS)=1 and $RT_DS1_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_DS1_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_DS1_ENDADDRESS)=1 and $RT_DS1_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_DS1_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_VDS_STARTADDRESS)=1 and $RT_VDS_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_VDS_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_VDS_ENDADDRESS)=1 and $RT_VDS_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_VDS_ENDADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CUST0_STARTADDRESS)=1 and $RT_CUST0_STARTADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CUST0_STARTADDRESS" />
	</xsl:element>
</xsl:when>
<xsl:when test="count(. | $Ref_CUST0_ENDADDRESS)=1 and $RT_CUST0_ENDADDRESS">
	<xsl:element name="Value">
		<xsl:value-of select="$RT_CUST0_ENDADDRESS" />
	</xsl:element>
</xsl:when>
		<xsl:otherwise>		
			<xsl:element name="{name()}">
				<xsl:apply-templates select="@*"/>
				<xsl:apply-templates/>
			</xsl:element>
		</xsl:otherwise>
	</xsl:choose>
 </xsl:template>	
 
 <xsl:template match="@*">
	<xsl:choose>
	<xsl:when test="false">
	</xsl:when>	
		<xsl:otherwise>
			<xsl:attribute name="{name()}">
				<xsl:value-of select="."/>
			</xsl:attribute> 
		</xsl:otherwise>
	</xsl:choose>
 </xsl:template>
 
</xsl:stylesheet>
