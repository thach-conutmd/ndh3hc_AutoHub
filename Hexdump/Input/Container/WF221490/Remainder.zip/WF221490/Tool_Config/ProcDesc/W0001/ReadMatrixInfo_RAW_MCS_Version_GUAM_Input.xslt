 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Derive value from decision matrix for RAW and MCS version</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Derive value from decision matrix for RAW and MCS version</DefaultValueMessage>
		<ConfigFile>
			<Directory><xsl:call-template name="GetMatrixPath"></xsl:call-template></Directory>
			<Name><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'RAW_MCS_VERSION_FOR_GUAM_MATRIX_NAME'"/></xsl:call-template></Name>
		</ConfigFile>
		<Variables>
			<Variable>
				<Name>Sign_Flag</Name>
				<Value>  <xsl:call-template name="GetSignFlagValue"></xsl:call-template></Value>
			</Variable>
			<Variable>
				<Name>ECU_Designation</Name>
				<Value>
                <xsl:call-template name="GetECUDesignation"></xsl:call-template>
         			</Value>
			</Variable>
			<Variable>
				<Name>Brand</Name>
				<Value>
                <xsl:call-template name="GetBrand"></xsl:call-template>
         			</Value>
			</Variable>	
			<Variable>
				<Name>CustomerGroup</Name>
				<Value>  <xsl:call-template name="GetCustomerGroup"></xsl:call-template></Value>
			</Variable>			
			<Variable>
				<Name>ReleaseScope</Name>
				<Value>  <xsl:call-template name="GetReleaseScope"></xsl:call-template></Value>
			</Variable>			
			<Variable>
				<Name>Flash0_Required</Name>
				<Value><xsl:call-template name="GetFlash0_Required"></xsl:call-template></Value>
			</Variable>
			<Variable>
				<Name>GUAM_FLAG</Name>
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'GUAM_FLAG'"/></xsl:call-template></Value>
			</Variable>
			<Variable>
				<Name>TB_HANDLING_FLAG</Name>
				<Value><xsl:call-template name="GetTBHandlingFlag"></xsl:call-template></Value>
			</Variable>
			<Variable>
				<Name>SECUMGR_HSM_FLAG</Name>
				<Value><xsl:call-template name="GetSecumgrHSMFlag"></xsl:call-template></Value>
			</Variable>
		</Variables>  
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
