 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" /> 
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
	<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
	<xsl:variable name="AddressModelFile" select="concat($WorkingDir, '\AddressModel.xml')" />
	<xsl:template match="/">

		<ToolInput>
			<Mode>Script Generator Started</Mode>

			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"/>
				</WorkingDirectory>
				<Scripts>
					<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>SCRIPT_INCLUDE_SECTIONS_IN_RAW_FILE</Key>
						<Comment>Script for including sections in raw file</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_INCLUDE_SECTIONS_IN_RAW_FILE'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>
								<RawFilePath>
									  <xsl:call-template name="GetRawMcsVersionPath"></xsl:call-template>
									<xsl:value-of select="'\'" />
									<xsl:call-template name="RunTime_Data_Value">
										<xsl:with-param name="DataClassID" select="'RAWMCSVersion'" />
									</xsl:call-template>
									<xsl:value-of select="'.raw'" />
								</RawFilePath>
								<RawFileUpdatedPath>
									<xsl:call-template name="GetWorkingDirectory"/>
									<xsl:value-of select="'\'" />
									<xsl:call-template name="RunTime_Data_Value">	
										<xsl:with-param name="DataClassID" select="'RAWMCSVersion'" />								
									</xsl:call-template>
									<xsl:value-of select="'.raw'" />									
								</RawFileUpdatedPath>
								<FSW_FEE_Block>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'FEE_Report_ParaSet_File'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'FEE_Report_ParaSet_File'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</FSW_FEE_Block>
								<FSW_DPTR_Block>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'ECUMEM_DATA_POINTERS_FILE'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'ECUMEM_DATA_POINTERS_FILE'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</FSW_DPTR_Block>
								<CHECKSUM_Block>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'CHECKSUMS_XMLFILE'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'CHECKSUMS_XMLFILE'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</CHECKSUM_Block>
								<FSW_Parameters_Config>
									<xsl:call-template name="FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'FSW_Parameters_Config'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'FSW_Parameters_Config'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</FSW_Parameters_Config>
								
								<AES_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'AES_Key_ParaSet_File'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'AES_Key_ParaSet_File'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</AES_Key_ParaSet_File>
								<SHE_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'SHE_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'SHE_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</SHE_Key_ParaSet_File>
								<ECC_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'ECC_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'ECC_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</ECC_Key_ParaSet_File>
								<RSA_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'RSA_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'RSA_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</RSA_Key_ParaSet_File>
								<MAC_UP_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'MAC_UP_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'MAC_UP_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</MAC_UP_Key_ParaSet_File>
								<MAC_UC_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'MAC_UC_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'MAC_UC_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</MAC_UC_Key_ParaSet_File>
								<SECUREDATA_Key_ParaSet_File>
									<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'SECURDATA_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'SECURDATA_Key_ParaSet_File_SecuMgr'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</SECUREDATA_Key_ParaSet_File>
								<TBREFTABDATA_DPTR_Block>
									<xsl:call-template name="GetWorkingDirectory"/>
									<xsl:value-of select="'\'" />		
									<xsl:value-of select="'TrustedBootTbl_Dptr.xml'" />									
								</TBREFTABDATA_DPTR_Block>								
							</Datas>				
						</DataBase>
					</Script>   
					<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>BSW_RELEASE_VALUE</Key>
						<Comment>Script for Checking BuildingSoftware in Webflow if So BSW else Hardware Part Number</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_CHECK_BSW_RELEASE'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
						<Datas>
							<HardwarePartNumber>
								<xsl:call-template name="GetHardwarePartNumber"></xsl:call-template>                                                                                                 
							</HardwarePartNumber>
							<ReleaseScope>
								<xsl:call-template name="GetReleaseScope"></xsl:call-template>                                                                                                           
							</ReleaseScope>
						</Datas>
						</DataBase>
					</Script>	
							
						
				</Scripts>		
			</Input>  
			<CallInformation>
				<ToolName/>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>

