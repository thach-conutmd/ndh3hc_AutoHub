<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 
 <xsl:variable name="RT_SB_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='SB_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_SB_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='SB_ENDADDRESS']/tctypes:Value"/>
 
  <xsl:variable name="RT_EcuSecuSrv0_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='EcuSecuSrv0_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_EcuSecuSrv0_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='EcuSecuSrv0_ENDADDRESS']/tctypes:Value"/>
 
<xsl:variable name="RT_CTP_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CTP_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_CTP_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CTP_ENDADDRESS']/tctypes:Value"/>
 
 <xsl:variable name="RT_CB_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CB_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_CB_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CB_ENDADDRESS']/tctypes:Value"/>
 
 <xsl:variable name="RT_ASW0_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW0_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_ASW0_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW0_ENDADDRESS']/tctypes:Value"/>
 
 <xsl:variable name="RT_ASW1_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW1_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_ASW1_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW1_ENDADDRESS']/tctypes:Value"/>
 
  <xsl:variable name="RT_ASW2_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW2_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_ASW2_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW2_ENDADDRESS']/tctypes:Value"/>
 
  <xsl:variable name="RT_ASW3_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW3_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_ASW3_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ASW3_ENDADDRESS']/tctypes:Value"/>
 
  <xsl:variable name="RT_DS0_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CUST0_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_DS0_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='DS0_ENDADDRESS']/tctypes:Value"/>
 
<xsl:variable name="RT_DS1_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='DS1_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_DS1_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='DS1_ENDADDRESS']/tctypes:Value"/>
 
 <xsl:variable name="RT_VDS_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='VDS_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_VDS_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='VDS_ENDADDRESS']/tctypes:Value"/>
 
 <xsl:variable name="RT_CUST0_STARTADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CUST0_STARTADDRESS']/tctypes:Value"/>
 <xsl:variable name="RT_CUST0_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CUST0_ENDADDRESS']/tctypes:Value"/>
			


</xsl:stylesheet>