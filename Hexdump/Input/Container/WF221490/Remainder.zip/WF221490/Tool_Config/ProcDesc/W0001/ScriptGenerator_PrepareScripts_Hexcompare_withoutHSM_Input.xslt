<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
	<xsl:variable name="AddressModelFile"  select="concat($WorkingDir, '\AddressModel.xml')" />
	<xsl:variable name="AddressModelInfoFile"  select="concat($WorkingDir, '\AddressModelInfo.xml')" />
		
	<xsl:template match="/">
		<ToolInput>
			<Mode>Generate Scripts for Hex Compare</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				<Scripts>
					
					<Script>
				  				<Write2PSTLib>False</Write2PSTLib>
				  				<Key>PED_SCRIPT_HEX_COMPARE</Key>
				  				<Comment>Ped Script for Hex Compare</Comment>
				  				<ScriptTemplate><xsl:call-template name="GetEnvironmentValue">
				  				<xsl:with-param name="LookUpItem" select="'PED_SCRIPT_HEX_COMPARE_TEMPLATE'"/></xsl:call-template></ScriptTemplate>
				  				<DataBase>
											<Datas>
											<Flash0_Required><xsl:call-template name="GetFlash0_Required"></xsl:call-template></Flash0_Required>
											<Ignore_Blocks><xsl:call-template name="GetIgnore_Blocks"></xsl:call-template></Ignore_Blocks>
											</Datas>
				            				<ADDRESSLAYOUTMODEL>
											<ADDRESSMODEL>
												<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
												<xsl:value-of select="'\'"/>
												<xsl:value-of select="'AddressModel_ReleaseHex.xml'"/>
											</ADDRESSMODEL>
									</ADDRESSLAYOUTMODEL>
				          			</DataBase>
					</Script>
					<Script>
						<Write2PSTLib>False</Write2PSTLib>
						<Key>HEX_COMPARE_LOGISTIC_LOG</Key>
						<Comment>Script for generating Hex Compare Logistic data</Comment>
						<ScriptTemplate><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_HEX_COMPARE_LOGISTIC_LOG_TEMPLATE'"/></xsl:call-template></ScriptTemplate>
						<DataBase>
						<Datas>
							<SBStartAddress>
								<xsl:call-template name="GetSBBLOCK_STARTADDRESS">
								<xsl:with-param  name="File"  select="$AddressModelInfoFile" />
								</xsl:call-template>
							</SBStartAddress>
							<Flash0_Required>
								<xsl:call-template name="GetFlash0_Required"></xsl:call-template>
							</Flash0_Required>
						</Datas>
						<ADDRESSLAYOUTMODEL>
							 <ADDRESSMODEL>
							 		<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							 		<xsl:value-of select="'\'"/>
							 		<xsl:value-of select="'AddressModel_ReleaseHex.xml'"/>
							</ADDRESSMODEL>
						</ADDRESSLAYOUTMODEL>
						</DataBase>
					</Script>				
				</Scripts>
			</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
