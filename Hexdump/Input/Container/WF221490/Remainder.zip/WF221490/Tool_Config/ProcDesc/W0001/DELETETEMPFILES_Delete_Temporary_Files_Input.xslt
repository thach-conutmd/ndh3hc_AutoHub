 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile --> 
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 

    <xsl:template match="/">
    <Input>
		<Mode>Delete temporary files</Mode>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
   		<Files>   
			<!--Hexmod-Config-Files-->
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'chksum.txt'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_Falsh0_'"/>
			
			<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/>
			</File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_OUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_CleanUp_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_CleanUp_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>					
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_CLEANUP_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>																
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_CLEANUP_OUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>					
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_CLEANUP_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_InfoBlock_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_InfoBlock_HSM0_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_InfoBlock_HSM1_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexMod_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_MAIN_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_Flash0_TPROT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_For_HSM0_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_For_HSM1_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_WITH_FSWID_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_InfoBlock_WITH_SWTTNR_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_Konserve_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_Konserve_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_Konserve_PATCHCHECK_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_Reprog_TPROT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_TPROT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_INFOBLOCK_HSM0_'"/>
											<xsl:call-template name="GetWorkFlowID">
											</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_INFOBLOCK_HSM1_'"/>
											<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
								
			<!--Hexmod-Logfiles-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_CLEANUP_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_CHKFTER_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMOD_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_CHKFTER_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">								
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_IBAFTER_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'hexmodx.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'OTP_info.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Scriptlogfile.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Sign_Hexmodx.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HexmodX_Flash0.log'"/></File>					
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'MergedConfig.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'OTP_Info.txt'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'OTP_Ref.txt'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_Konserve_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">								
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">								
								</xsl:call-template><xsl:value-of select="'.txt'"/></File>						
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Patch_G_'"/>
								<xsl:call-template name="GetWorkFlowID">								
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>	
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'ibafter_case1.xml'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'ibafter_case1_HSM0.xml'"/></File>	
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'ibafter_case1_HSM1.xml'"/></File>		
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Konserve_labels_Value.xml'"/></File>		
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Output_FEE_Paraset.xml'"/></File>	
			
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'DataPtr.xml'"/></File>		
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Detailelog_FLASH0_FullHex.xml'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'FLASH_0_AdrMod.xml'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'FSW_DPTR_Block.xml'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'FSW_FEE_Block.xml'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Hexmodx_Checksum.xml'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'HSMBlocks.xml'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'chksumscript.bsh'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'CreateFlash0.bsh'"/></File>
			
			<!--SignTool-Output-->
			<!-- <File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_'"/> -->
								<!-- <xsl:call-template name="GetWorkFlowID"> -->
								<!-- </xsl:call-template><xsl:value-of select="'.TXT'"/></File> -->
			<!-- Patched Hexfile -->
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexModX_SWTTNR_PatchedHexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexModX_SWTTNR_PatchedHexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexModX_PatchedHexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexModX_PatchedHexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexModX_IntegrationFile_withoutData'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexModX_IntegrationFile_withoutData'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexModX_AppliedFile_withoutProg'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexModX_AppliedFile_withoutProg'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>

			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
									<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
									<xsl:with-param name="GetValue" select="'yes'"/> 
									<xsl:with-param name="GetExtension" select="'no'"/>
									</xsl:call-template><xsl:value-of select="'_chksum.hex'" /></File>	
									
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Flash0_HexFile_Full'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Flash0_HexFile_Full'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>

			

			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			
								

			<!-- Create Reprog-Signature as Intel-Hex At the Moment 10 Bin files will be deleted since this number is dyanamic-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_1.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_2.BIN'"/></File>								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_3.BIN'"/></File>					
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_4.BIN'"/></File>					
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_5.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_6.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_7.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_8.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_9.BIN'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'_10.BIN'"/></File>																																																
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SignTool_HashValue_Reprog_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.hex'"/></File>
									
				<!-- <File><xsl:call-template name="RunTime_FileList_GetFileDirectory"> -->
								<!-- <xsl:with-param name="FileClassID" select="'SignTool17_Reprog_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName"> -->
								<!-- <xsl:with-param name="FileClassID" select="'SignTool17_Reprog_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template></File> -->

			<!-- <File><xsl:call-template name="RunTime_FileList_GetFileDirectory"> -->
								<!-- <xsl:with-param name="FileClassID" select="'HexMod17_Reprog_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName"> -->
								<!-- <xsl:with-param name="FileClassID" select="'HexMod17_Reprog_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template></File> -->

			<!-- <File><xsl:call-template name="RunTime_FileList_GetFileDirectory"> -->
								<!-- <xsl:with-param name="FileClassID" select="'SignTool17_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName"> -->
								<!-- <xsl:with-param name="FileClassID" select="'SignTool17_HashValue'"/> -->
								<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
								<!-- </xsl:call-template></File> -->
												
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_HashValue'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_HashValue'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'LASTRUN_HEXMOD_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'LASTRUN_HEXMOD_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'LASTRUN_WITHOUTHSM_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'LASTRUN_WITHOUTHSM_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'LASTRUN_FALSH0_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'LASTRUN_FALSH0_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>

			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'LASTRUN_Reprog_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'LASTRUN_Reprog_HASHOUTPUT'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>								
			

			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'odxconfig.conf'"/></File-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'ODXIdent.LOG'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'logFile.log'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'WinBSL.bsl'"/></File>
			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'PED_ODXIdent.ped'"/></File-->

			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Session.log'"/></File>
	
					
			<!--RAW file, MCS file, temp SGM file, SGM header txt file, SGO log file-->
			<!--<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="GetSGIDB1WithUnderScore"></xsl:call-template><xsl:value-of select="'_'"/><xsl:call-template name="GetSGIDB3"></xsl:call-template><xsl:value-of select="'.RAW'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="GetSGIDB1WithUnderScore"></xsl:call-template><xsl:value-of select="'_'"/><xsl:call-template name="GetSGIDB3"></xsl:call-template><xsl:value-of select="'.MCS'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="GetSGIDB1WithUnderScore"></xsl:call-template><xsl:value-of select="'_'"/><xsl:call-template name="GetSGIDB3"></xsl:call-template><xsl:value-of select="'_Complete.MCS'"/></File>	-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName" ><xsl:with-param name="FileClassID" select="'SGM_File_Complete'"/><xsl:with-param name="GetValue" select="'yes'"/></xsl:call-template></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\SGMHeader.txt'"/></File>						
			
					
			<!--  Run Perl Application -->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\update_Series_All.log'"/></File>
				
			<!--  Run Damos Write Data --> 			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\WriteData.DCM'"/></File>
					
			<!--  Run Ped Merge Prog and Data   --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\PedMergeProgData.log'"/></File>
			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\MergeProgData.dcm'"/></File-->

			<!--  Run PED Perform Patches --> 
						
			<!--File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Patch_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Patch_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File-->
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Ped_Patch_File'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Ped_Patch_File'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!--  Run PED SW Sharing --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\SW_Sharing.log'"/></File>
			
			
			<!--  Run Ped Calculate UEKO-Checksums --> 
			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\UEKO.dcm'"/></File-->
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Patch latest BlockVersions -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'pp_patchlatestblockversions.xml'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_PatchedLatestBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_PatchedLatestBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Run UEKO-Checksum Update E01_1 -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<!-- Calculate UEKO-Checksums E01_1 -->
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Run UEKO-Checksum Update E01_1 -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update_1'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Read latest BlockVersions -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'pp_latest_blockversions.xml'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_Output_LatestBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_Output_LatestBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Patch New BlockVersions -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'pp_patchnewblockversions.xml'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_PatchedNewBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_PatchedNewBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>			
			
			<!-- HexMod17 - Run UEKO-Checksum Update E01_2 -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<!-- Calculate UEKO-Checksums E01_2 -->
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Run UEKO-Checksum Update E01_2 -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update_2'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Read New BlockVersions -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'pp_New_blockversions.xml'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_Output_NewBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_Output_NewBlockVersions'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Run UEKO-Checksum Update -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<!-- Calculate UEKO-Checksums -->
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Ueko_Check_Log'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'MO_CheckSum'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
			
			<!-- HexMod17 - Run UEKO-Checksum Update -->
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
						
			<File><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_UEKO_CheckSum_Update'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>	
			
			<!--  Run HexMod17 Create Signed Hexfile --> 			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_Sign_Hexfile_LOG_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_Sign_Hexfile_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			
			<!--  Copy - HexCompare Config file  --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Config.csv'"/></File>
			
			<!--  Run PED Hex Compare --> 
			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Hex_Compare.pcm'"/></File-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Hex_Compare.log'"/></File>
			
			<!--  Run PED Create Reprog-Signature as Intelhex --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\PED.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.PED'"/></File>
			
			<!--  Run PED Calculate Checksums --> 
			<!--File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Checksums.dcm'"/></File-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Checksums.log'"/></File>
			
			<!--  Run SSD check Tool  --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
								<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
						<xsl:value-of select="'.log'"/>
			</File>
					
			<!--  Run BC_gen Tool --> 
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\CHECK.LOG'"/></File>
			
			<!-- This file generated by serget and is not required now -->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Calc_carb_chk.Ped'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\D175032I_S06E6.DCM'"/></File>
			
			<!-- Checksum.dcm -->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Checksums.dcm'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\GetCustomerData.dcm'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Hex_Compare.pcm'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\ibafter_case1.xml'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched.hex'"/></File>			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/>
				<xsl:call-template name="GetSoftwareName"></xsl:call-template>
				<xsl:value-of select="'_Check_BC_Gen.log'"/>
			</File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/>
				<xsl:call-template name="GetSoftwareName"></xsl:call-template>
				<xsl:value-of select="'_Check_Complete.log'"/>
			</File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/>
				<xsl:call-template name="FileList_GetFileName" >
					<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
					<xsl:with-param name="GetExtension" select="'no'"/> 
				</xsl:call-template>
				<xsl:value-of select="'_SW_Sharing.hex'"/>
			</File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\SW_Sharing.pcm'"/></File>
		<!-- <File> -->
          <!-- <xsl:call-template name="GetWorkingDirectory"></xsl:call-template> -->
		  <!-- <xsl:value-of select="'\'"/> -->
			<!-- <xsl:value-of select="'SSD_'"/> -->
			<!-- <xsl:call-template name="FileList_GetFileName" > -->
			<!-- <xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/> -->
			<!-- <xsl:with-param name="GetValue" select="'yes'"/>  -->
			<!-- </xsl:call-template> -->
			<!-- </File> -->
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CREATEADDRESSMODEL_MAIN_'"/><xsl:call-template name="GetWorkFlowID">
				</xsl:call-template><xsl:value-of select="'.XML'"/></File>			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CREATEADDRESSMODEL_MAIN_'"/><xsl:call-template name="GetWorkFlowID">
				</xsl:call-template><xsl:value-of select="'.LOG'"/></File>				
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CREATEADDRESSMODEL_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CREATEADDRESSMODEL_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CREATEADDRESSMODEL_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>					
								
			<!-- <File><xsl:call-template name="GetWorkingDirectory">
				<xsl:value-of select="'\SSD_'"/>
				<xsl:call-template name="FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
				<xsl:with-param name="GetExtension" select="'no'"/>							
				</xsl:call-template>
				<xsl:value-of select="'.err'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory">
				<xsl:value-of select="'\SSD_'"/>
				<xsl:call-template name="FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
				<xsl:with-param name="GetExtension" select="'no'"/>							
				</xsl:call-template>
				<xsl:value-of select="'.log'"/></File>	-->
				
			<!-- <File><xsl:call-template name="GetWorkingDirectory"/> -->
				<!-- <xsl:value-of select="'\SSD_'"/> -->
				<!-- <xsl:call-template name="FileList_GetFileName" > -->
				<!-- <xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/> -->
				<!-- <xsl:with-param name="GetValue" select="'yes'"/> -->
				<!-- <xsl:with-param name="GetExtension" select="'no'"/>							 -->
				<!-- </xsl:call-template> -->
				<!-- <xsl:value-of select="'.wrn'"/></File>	 -->
			
			<!-- <File><xsl:call-template name="GetWorkingDirectory"/> -->
				<!-- <xsl:value-of select="'\SSD_'"/> -->
				<!-- <xsl:call-template name="FileList_GetFileName" > -->
				<!-- <xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/> -->
				<!-- <xsl:with-param name="GetValue" select="'yes'"/> -->
				<!-- <xsl:with-param name="GetExtension" select="'no'"/>							 -->
				<!-- </xsl:call-template> -->
				<!-- <xsl:value-of select="'_npl.lab'"/></File>				 -->
			
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>	
						<xsl:value-of select="'\CTPROT_RSA_Patch.log'"/></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									<xsl:value-of select="'\CTPROT_RSA_Patch.pcm'"/></File>
									
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'CTPROT_RSA_KEYS_PATCH_FILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'CTPROT_RSA_KEYS_PATCH_FILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:value-of select="'HexMod_PatchAndCheck_Main_'" />
				<xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.XML'" /></File>
				
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HexMod_PatchAndCheck_Main_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HexMod_PatchAndCheck_Input_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HexMod_PatchAndCheck_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HexMod_PatchAndCheck_Output_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod_CB_PRE_PatchedHexFile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod_CB_PRE_PatchedHexFile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_CB_PatchedHexFile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_CB_PatchedHexFile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_ERASEHEX_MAIN_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_ERASEHEX_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_ERASEHEX_INPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_ERASEHEX_OUTPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_CRC32_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_Vector_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMODX_Flash0_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_VectorTable_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" /></File>
			
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\CB_Block_PrePatchAndCheckInfo'" />								
								<xsl:value-of select="'.XML'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\CB_Block_PatchAndCheckInfo'" />								
								<xsl:value-of select="'.XML'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CTPROT_PATCH_MAIN_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CTPROT_PATCH_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CTPROT_PATCH_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CTPROT_PATCH_PATCHCHECK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\CTPROT_RSAKeys_Address'" />								
								<xsl:value-of select="'.XML'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CHECKSUM_CTP_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CHECKSUM_TP_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CHECKSUM_SB_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CHECKSUM_HSM0_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CHECKSUM_HSM1_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_HSM0_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_HSM1_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HWRefXMLTemplate'" />								
								<xsl:value-of select="'.XML'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_TP_Checksum'" />								
								<xsl:value-of select="'.txt'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_SB_Checksum'" />								
								<xsl:value-of select="'.txt'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_CTP_Checksum'" />								
								<xsl:value-of select="'.txt'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_HSM0_Checksum'" />								
								<xsl:value-of select="'.txt'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_HSM1_Checksum'" />								
								<xsl:value-of select="'.txt'" /></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\CB_Block_Logistic_Info'" />								
								<xsl:value-of select="'.xml'" /></File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"/>
				<xsl:value-of select="'HexMod_PATCH_ODX_IDENTS_Main_'"/>
				<xsl:call-template name="GetWorkFlowID"/>
				<xsl:value-of select="'.xml'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HexMod_PATCH_ODX_IDENTS_Main_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.LOG'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_PATCH_ODX_IDENTS_INPUT_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HexMod_ODX_Patch_Output_'" />
				<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
				<xsl:value-of select="'.XML'" />
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_ABM_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_GET_CBTPROT_VERSION_LOG_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.LOG'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_GET_CBTPROT_VERSION_INPUT_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_GET_CBTPROT_VERSION_PATCHCHECK_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\CBVERSION_Value.xml'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\'" />
				<xsl:call-template name="GetSoftwareName"></xsl:call-template>
				<xsl:value-of select="'_ODX_Patched.hex'" />
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\'" />
				<xsl:value-of select="'HexMod_Read_Monitor_Main_'"/>
				<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
				<xsl:value-of select="'.xml'" />
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HexMod_Read_Monitor_Main_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.LOG'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_Read_Monitor_INPUT_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_Read_Monitor_PATCHCHECK_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.XML'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\checksum_value.xml'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\Cust_checksum_value.xml'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\SSDFInal_PST.dcm'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HexMod_CBTPROT_Version_Main_'"/>
				<xsl:call-template name="GetWorkFlowID">
				</xsl:call-template>
				<xsl:value-of select="'.xml'"/>
			</File>
			<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				<xsl:value-of select="'\HEXMOD_Sign_Hexfile_INFOBLOCK_LOG_ForAnalysis.LOG'"/>
			</File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_CONTAINERDLL_'" />
          <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
          <xsl:value-of select="'.XML'" />
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\MWB_Cheksum.txt'" />
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory">
          </xsl:call-template><xsl:value-of select="'\HexMod_Check_Tprot_CleanUp_Main_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'" />
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_CHECK_TPROT_CLEANUP_LOG_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.LOG'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_CHECK_TPROT_CLEANUP_INPUT_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_CHECK_TPROT_CLEANUP_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory">
          </xsl:call-template>
          <xsl:value-of select="'\HEXMOD_CHECK_TPROT_CLEANUP_LOG_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.LOG'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory">
          </xsl:call-template>
          <xsl:value-of select="'\HexMod_TPROT_MERGE_Main_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_TPROT_MERGE_LOG_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.LOG'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_TPROT_MERGE_INPUT_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_TPROT_MERGE_OUTPUT_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HEXMOD_TPROT_MERGE_CLEANUP_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          <xsl:value-of select="'\HexMod_InfoBlock_'"/>
          <xsl:call-template name="GetWorkFlowID">
          </xsl:call-template>
          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
        <xsl:call-template name="GetWorkingDirectory"/>
        <xsl:value-of select="'\HEXMOD_Merged_File.Hex'"/>
        </File>
         <File>
	          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
	          <xsl:value-of select="'\HEXMOD_Imo_idxLab_C_VW_INPUT_'"/>
	          <xsl:call-template name="GetWorkFlowID">
	          </xsl:call-template>
	          <xsl:value-of select="'.XML'"/>
        </File>
        <File>
		          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
		          <xsl:value-of select="'\HexMod_Imo_idxLab_C_VW_Main_'"/>
		          <xsl:call-template name="GetWorkFlowID">
		          </xsl:call-template>
		          <xsl:value-of select="'.XML'"/>
        </File>
        
         <File>
			          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
			          <xsl:value-of select="'\HEXMOD_Imo_idxLab_C_VW_LOG_'"/>
			          <xsl:call-template name="GetWorkFlowID">
			          </xsl:call-template>
			          <xsl:value-of select="'.log'"/>
        </File>
        <File>
				          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				          <xsl:value-of select="'\HEXMOD_Imo_idxLab_C_VW_PATCHCHECK_'"/>
				          <xsl:call-template name="GetWorkFlowID">
				          </xsl:call-template>
				          <xsl:value-of select="'.log'"/>
        </File>
        
         <File>
					          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					         <xsl:value-of select="'Imo_idxLab_C_VW_Value.xml'"/>
        </File>
        
        <!-- ODX LZSS-->
        
        
        <!-- TC_ODX -->
				<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
				
				<xsl:call-template name="RunTime_FileList_GetFileName">
				<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
				<xsl:with-param name="GetValue" select="'yes'"/> 
				 <xsl:with-param name="GetExtension" select="'no'"/>
				 </xsl:call-template>
				
				<xsl:value-of select="'.wbc'"/></File>
	
				
						
				<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
				<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_1.bpb'"/></File>
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_2.bpb'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
				<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_3.bpb'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_4.bpb'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_5.bpb'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_6.bpb'"/></File>
						
						<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_7.bpb'"/></File>
					
						<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_8.bpb'"/></File>
				
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_9.bpb'"/></File>
						
						
						
				
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_1.lzss'"/></File>
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_2.lzss'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
				<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_3.lzss'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_4.lzss'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_5.lzss'"/></File>
						
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_6.lzss'"/></File>
						
						<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_7.lzss'"/></File>
					
						<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_8.lzss'"/></File>
				
					<File><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
						<xsl:with-param name="GetExtension" select="'no'"/> 
						</xsl:call-template><xsl:value-of select="'_9.lzss'"/></File>
						
			
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_Konserve_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></File>
								
				<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_Konserve_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				
				<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_Konserve_PATCHCHECK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG.LOG'"/>
				
				</File>
							
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Hex_Bin.dcm'"/></File>
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Hex_Bin.log'"/></File>
        
        
        			<File>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexMod_Konserve_Main_'"/><xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
     				<File>
     					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexMod_PatchCheck_'"/><xsl:call-template name="GetWorkFlowID">
     									</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
				     					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_ABM_'"/><xsl:call-template name="GetWorkFlowID">
				     									</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
							</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
									<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
											</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_MAIN_'"/><xsl:call-template name="GetWorkFlowID">
							</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				<File>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
							</xsl:call-template><xsl:value-of select="'.XML'"/>
				</File>
				
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched1.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched2.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched3.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched4.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched5.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched6.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched7.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched8.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched9.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched10.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched11.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched12.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched13.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched14.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched15.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_1.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_2.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_3.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_4.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_5.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_5.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_6.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_7.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_8.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_9.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_10.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_11.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_12.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_13.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_14.hex'"/></File>
				<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\Patched_15.hex'"/></File>
        
      </Files>
      <CallInformation>
        <ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>
     </Input>     	
   </xsl:template>
</xsl:stylesheet>
