<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
	<!-- Check node FEE_EMULATION_TYPE_HSM exists or not-->
	 <xsl:variable name="FEE_EMULATION_TYPE_HSM">
		 <xsl:call-template name="CheckNodeExistsorNot">
			 <xsl:with-param name="FEE_NODE">
				 <xsl:call-template name="RunTime_Data_Value">
                    <xsl:with-param name="DataClassID" select="'FEE_EMULATION_TYPE_HSM'"/>
                 </xsl:call-template>
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	 
	 	 <!-- Check node FEE_EMULATION_TYPE_HOST exists or not-->
	 <xsl:variable name="FEE_EMULATION_TYPE_HOST">
		 <xsl:call-template name="CheckNodeExistsorNot">
			 <xsl:with-param name="FEE_NODE">
				 <xsl:call-template name="RunTime_Data_Value">
                    <xsl:with-param name="DataClassID" select="'FEE_EMULATION_TYPE_HOST'"/>
                 </xsl:call-template>
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Update PST Lib items</Mode>
			<Input>
			<PST_Library>
			
			<Item>
					<ID>INPUT_CONFIGURATION_INIT_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>HEXMODX_DELETE_HSMIB_MAIN_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_HSMIB_MAIN_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>CUSTOMER_PROCESSDESCRIPTION_INFORMATION_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'CUSTOMER_PROCESSDESCRIPTION_INFORMATION_WEICHAI'"/>
						</xsl:call-template>
					</Value>
				</Item>
			<Item>
					<ID>SCRIPT_INFOBLOCK_DELETE_SW_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_SW_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_DELETE_BLOCK_MAIN_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_BLOCK_MAIN_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>HEXMODX_DELETE_BLOCK_INFOBLOCK_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_BLOCK_INFOBLOCK_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_DELETE_BLOCK_INPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_BLOCK_INPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_DELETE_BLOCK_OUTPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_BLOCK_OUTPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_INPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>SCRIPT_INFOBLOCK_DELETE_OEMHEXFFILE_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_OEMHEXFFILE_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>SCRIPT_INFOBLOCK_DELETE_DATA_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_DATA_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_MERGE_DATA_MAIN_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_DATA_MAIN_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_MERGE_PROG_DATA_INPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_PROG_DATA_INPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>HEXMODX_MERGE_PROG_DATA_OUTPUT_XML_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_PROG_DATA_OUTPUT_XML_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>
			<Item>
					<ID>SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			<Item>
					<ID>SW_BLOCKS_WEICHAI</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SW_BLOCKS_WEICHAI'"/>
						</xsl:call-template>
					</Value>
			</Item>	
			
			<!--NBN1HC, Updating 23/06/2022 -->
			
			<Item>
				<ID>SCRIPT_REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL_GUAM</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'SCRIPT_REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL_GUAM'"/>
					</xsl:call-template>
				</Value>
			</Item>
			<Item>
			<ID>SCRIPT_UPDATE_HSMGUAM_ADDRESS_IN_FSWDATAPOINTER_FOR_GUAM</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'SCRIPT_UPDATE_HSMGUAM_ADDRESS_IN_FSWDATAPOINTER_FOR_GUAM'"/>
					</xsl:call-template>
				</Value>
			</Item>			
			<Item>
			<ID>SCRIPT_RENAME_HASH_FILES_FOR_LADE_HANDLING</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'SCRIPT_RENAME_HASH_FILES_FOR_LADE_HANDLING'"/>
					</xsl:call-template>
				</Value>
			</Item>
			<Item>
		<ID>HEXMODX_CREATE_GUAM_SIGNED_HEXFILE_TPROTCONF_XML</ID>
		<Value>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_GUAM_SIGNED_HEXFILE_TPROTCONF_XML'"/>
			</xsl:call-template>
		</Value>
	</Item>

	<Item>
		<ID>HEXMODX_CREATE_GUAM_SIGNATURE_HASH_TPROTCONF_XML</ID>
		<Value>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_GUAM_SIGNATURE_HASH_TPROTCONF_XML'"/>
			</xsl:call-template>
		</Value>
	</Item>

	<Item>
		<ID>HEXMODX_READ_SIGNINFO_GUAM_TPROTCONF_XML</ID>
		<Value>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_SIGNINFO_GUAM_TPROTCONF_XML'"/>
			</xsl:call-template>
		</Value>
	</Item>	
				<Item>
					<ID>GUAM_FLAG</ID>
					<Value>
					<xsl:call-template name="GetGUAM_FLAG"/>
					</Value>
				</Item>
				<Item>
					<ID>SCRIPT_CHECK_BSW_RELEASE</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_CHECK_BSW_RELEASE'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
				<ID>SECURITY_VARIANT</ID>
				<Value>
					<xsl:call-template name="GetSECURITY_VARIANT">
					<xsl:with-param name="SECURITY_VARIANT_Value">
						<xsl:call-template name="RunTime_Data_Value">	
							<xsl:with-param name="DataClassID" select="'SECURITY_VARIANT'" />								
						</xsl:call-template>
					</xsl:with-param>
				</xsl:call-template>
				</Value>
				</Item>
			<Item>         
            <ID>DERIVE_SIGNINGMETHOD_MATRIX_NAME</ID>
		    <Value>
				<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'DERIVE_SIGNINGMETHOD_MATRIX_NAME'"/>
				</xsl:call-template>
			</Value>
			</Item>
				<Item>
					<ID>HEXMODX_CREATE_TRIM_HEX_OUTPUT_XML</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_TRIM_HEX_OUTPUT_XML'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>ENDIAN_TYPE_MATRIX_NAME</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'ENDIAN_TYPE_MATRIX_NAME'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>FEE_VARIABLE_LIST_MATRIX_NAME</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'FEE_VARIABLE_LIST_MATRIX_NAME'"/>
						</xsl:call-template>
					</Value>
				</Item>
					<Item>
					<ID>FEE_VARIABLE_LIST_MATRIX_PATH</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'FEE_VARIABLE_LIST_MATRIX_PATH'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>HEXMODX_CREATE_TRIM_HEX_INPUT_XML</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_TRIM_HEX_INPUT_XML'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>HEXMODX_CREATE_TRIM_HEX_MAIN_XML</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_TRIM_HEX_MAIN_XML'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_CONDITIONCHECK_FILE</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_CONDITIONCHECK_FILE'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_KEY_REF_FILEPATH</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_KEY_REF_FILEPATH'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_KEY_LOG_FILEPATH</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_KEY_LOG_FILEPATH'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_ENV_TYPE_NUMBER</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_ENV_TYPE_NUMBER'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_CUSTOMERIDENTITY_INDEX_DEC</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_CUSTOMERIDENTITY_INDEX_DEC'"/>
						</xsl:call-template>
					</Value>
				</Item>
				<Item>
					<ID>OTP_CUSTOMERIDENTITY_INDEX_HEX</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'OTP_CUSTOMERIDENTITY_INDEX_HEX'"/>
						</xsl:call-template>
					</Value>
				</Item>	
				<Item>
					<ID>SCRIPT_DERIVE_VBF_TRIM_HEX_ERASE_RANGE</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_VBF_TRIM_HEX_ERASE_RANGE'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>SCRIPT_DERIVE_VBF_TRIM_HEX_BLOCKS</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_VBF_TRIM_HEX_BLOCKS'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>SCRIPT_DERIVE_NON_BOOT_BLOCKS</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_NON_BOOT_BLOCKS'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>BOOT_BLOCKS</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BOOT_BLOCKS'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>PATCHINFO_FILE_PATH</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'PATCHINFO_FILE_PATH'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>TOOL_LIST</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'TOOL_LIST'"/></xsl:call-template></Value>
				</Item>
			
				<Item>
					<ID>HEXMOD_FILETYPE</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Item>				
				
				<Item>
					<ID>HEXMODX_PATCH_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_PATCH_WITHOUTHSMBLOCKS_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_WITHOUTHSMBLOCKS_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>HEXMODX_PATCH_INFOBLOCK_SWTTNR_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_SWTTNR_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_PATCH_INPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INPUT_XML'"/></xsl:call-template></Value>
				</Item>				
				<Item>
					<ID>HEXMODX_PATCH_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>
 				<Item>
					<ID>READ_StartAddress_Blocks</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'READ_StartAddress_Blocks'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>READ_AES_KEY_FROM_FILE</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'READ_AES_KEY_FROM_FILE'"/></xsl:call-template></Value>
				</Item>
		
				<Item>
					<ID>ODX_OCNFFILE_EXTERN</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPTGENERATOR_ODXCREATE_OCNF_FILE_EXTERN'"/></xsl:call-template></Value>
				</Item>
  <Item>
    <ID>HEXMOD_GET_AES_KEY_MAIN_XML</ID>
    <Value>
      <xsl:call-template name="GetEnvironmentValue">
        <xsl:with-param name="LookUpItem" select="'HEXMOD_GET_AES_KEY_MAIN_XML'"/>
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>HEXMOD_GET_AES_KEY_INPUT_XML</ID>
    <Value>
      <xsl:call-template name="GetEnvironmentValue">
        <xsl:with-param name="LookUpItem" select="'HEXMOD_GET_AES_KEY_INPUT_XML'"/>
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>HEXMOD_GET_AES_KEY_PATCHCHECK_XML</ID>
    <Value>
      <xsl:call-template name="GetEnvironmentValue">
        <xsl:with-param name="LookUpItem" select="'HEXMOD_GET_AES_KEY_PATCHCHECK_XML'"/>
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
	<ID>ABM_START_ADDRESS</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'ABM_START_ADDRESS'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>ABM_END_ADDRESS</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'ABM_END_ADDRESS'"/>
		</xsl:call-template>
            </Value>
</Item>
  
				<Item>
					<ID>SIGNCHECK_REFERENZUSER</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SIGNCHECK_REFERENZUSER'"/></xsl:call-template></Value>
				</Item>			

				<Item>
					<ID>CUSTOMER_PROCESSDESCRIPTION_INFORMATION</ID>
					<Value>
					
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'CUSTOMER_PROCESSDESCRIPTION_INFORMATION'"/>
						</xsl:call-template>
						
					<!-- <xsl:call-template name="ReplaceString"> -->
						<!-- <xsl:with-param name="text"> -->
						<!-- <xsl:call-template name="GetEnvironmentValue"> -->
						<!-- <xsl:with-param name="LookUpItem" select="'CUSTOMER_PROCESSDESCRIPTION_INFORMATION'"/> -->
						<!-- </xsl:call-template> -->
						<!-- </xsl:with-param> -->
						<!-- <xsl:with-param name="replace" select="'ToolVersion'" /> -->
						<!-- <xsl:with-param name="by"> -->
							<!-- <xsl:call-template name="RunTime_Data_Value"> -->
								<!-- <xsl:with-param name="DataClassID" select="'ToolVersion'" /> -->
							<!-- </xsl:call-template> -->
						<!-- </xsl:with-param> -->
					<!-- </xsl:call-template> -->
					</Value>
				</Item>		
					<Item>
					<ID>WINBSL_OPTIONSKEY</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'WINBSL_OPTIONSKEY'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>ODX_TEMPLATE</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ODX_TEMPLATE'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>INPUT_CONFIGURATION_ODX_CHECK_IDENTS</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_ODX_CHECK_IDENTS'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>INPUT_CONFIGURATION_INIT_INTERN</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_INTERN'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>INPUT_CONFIGURATION_INIT</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>INPUT_CONFIGURATION_INIT_FOR_OUTPUTFILENAME_FLAG</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_FOR_OUTPUTFILENAME_FLAG'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>INPUT_ODX_CREATE_DATA</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INPUT_ODX_CREATE_DATA'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>HEXMOD_VARIANT_CODING_INPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_INPUT_XML'"/></xsl:call-template></Value>
				</Item>	
				<Item>
					<ID>HEXMOD_VARIANT_CODING_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>					
				<Item>
					<ID>HEXMOD_VARIANT_CODING_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_MAIN_XML'"/></xsl:call-template></Value>
				</Item>					
  <Item>
    <ID>SCRIPTGENERATOR_ODXCREATE_PROGPRECOND_VALUES_TEMPLATE</ID>
    <Value>
      <xsl:call-template name="GetEnvironmentValue">
        <xsl:with-param name="LookUpItem" select="'SCRIPTGENERATOR_ODXCREATE_PROGPRECOND_VALUES_TEMPLATE'"/>
      </xsl:call-template>
    </Value>
  </Item> 
				<Item>
					<ID>HEXMOD_VC_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VC_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMOD_VC_INFOBLOCK_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VC_INFOBLOCK_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMOD_VC_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_VC_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>
			<Item>
				<ID>PRESELECTION_SGIDB1</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'UpdateSGIDB1inUseCase'"/>
				</xsl:call-template></Value>
			</Item>					
			<Item>
				<ID>FLASH_BLOCK_COUNT</ID>				
				<Value><xsl:call-template name="GetFlashBlockCount"></xsl:call-template></Value>
			</Item>
			<Item>
				<ID>MASTER_SLAVE_ODX_EVVARIANTS</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MASTER_SLAVE_ODX_EVVARIANTS_TEMPLATE'"/></xsl:call-template></Value>
			</Item>
			<Item>
				<ID>MASTER_SLAVE_ODX_EVVARIANTS_EXTERN</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MASTER_SLAVE_ODX_EVVARIANTS_EXTERN_TEMPLATE'"/></xsl:call-template></Value>
			</Item>
			<Item>
				<ID>MasterSlave_Single</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'MasterSlave_Single'"/>
				</xsl:call-template></Value>
			</Item>			
			<Item>
				<ID>HEXMOD_CREATEADDRESSMODEL_MAIN_XML</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATEADDRESSMODEL_MAIN_XML'"/></xsl:call-template></Value>
			</Item>
			<Item>
				<ID>HEXMOD_CREATEADDRESSMODEL_INPUT_XML</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATEADDRESSMODEL_INPUT_XML'"/></xsl:call-template></Value>
			</Item>
			<Item>
				<ID>HEXMOD_CREATEADDRESSMODEL_INFOBLOCK_XML</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATEADDRESSMODEL_INFOBLOCK_XML'"/></xsl:call-template></Value>
			</Item>						
			
	         <Item>
				<ID>INPUT_CONFIGURATION_INIT_INTERN_WITH_MASTER_REQUEST</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_INTERN_WITH_MASTER_REQUEST'"/></xsl:call-template></Value>
			</Item>
			
			<Item>
				<ID>HEADER_FOR_SGIDB_DATA</ID>
				<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEADER_FOR_SGIDB_DATA'"/></xsl:call-template></Value>
			</Item>

			<Item>
				<ID>ERASEMEMORY</ID>				
				<Value>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'EraseMemLen'" />
					</xsl:call-template>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'EraseMemAdr'" />
					</xsl:call-template>
				</Value>
			</Item>
  <Item>
    <ID>RContEraseMLenMS</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'EraseMemLen'" />
      </xsl:call-template>
    </Value>
  </Item>
	
  <Item>
    <ID>AddressLayoutModel</ID>
    <Value>
      <xsl:call-template name="GetAddressLayoutModel">	   
	</xsl:call-template>
    </Value>
  </Item>

  <Item>
    <ID>RContEraseMLenMA</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'EraseMemAdr'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>REQDownloadLenMS</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ReqDownLoadMemLen'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>REQDownloadLenMA</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ReqDownLoadMemAdr'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>RContCheckMLenMS</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'CheckMemLen'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>RContCheckMLenMA</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'CheckMemAdr'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>RContRoutiContrCheckMemLen</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'RoutiContrCheckMemLen'" />
      </xsl:call-template>
    </Value>
  </Item>
	
			<Item>
				<ID>REQUESTDOWNLOAD</ID>				
				<Value>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'ReqDownLoadMemLen'" />
					</xsl:call-template>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'ReqDownLoadMemAdr'" />
					</xsl:call-template>
				</Value>
			</Item>
			<Item>
				<ID>CHECKMEMORY</ID>				
				<Value>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CheckMemLen'" />
					</xsl:call-template>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CheckMemAdr'" />
					</xsl:call-template>
				</Value>
			</Item>
  <Item>
    <ID>VW80126Version</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'VW80126Version_Value'" />
      </xsl:call-template>     
    </Value>
  </Item>
  <Item>
    <ID>PROGPRECOND_LIST</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_PreCondNode">
        <xsl:with-param name="DataClassID" select="'PROGPRECOND_Values'" />
      </xsl:call-template>
    </Value>
  </Item>
			<Item>
				<ID>PART_PROG_SY</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'PART_PROG_SY'" />
						</xsl:call-template>
				</Value>
			</Item>
			<Item>
				<ID>DFID_FLAG</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'DFID_FLAG'" />
						</xsl:call-template>
				</Value>
			</Item>
				<Item>
				<ID>COMPRESSION</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'COMPRESSION'" />
						</xsl:call-template>
				</Value>
			</Item>
			<Item>
				<ID>ENCRYPTION</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'ENCRYPTION'" />
						</xsl:call-template>
				</Value>
			</Item>
  <Item>
    <ID>ODX_CREATE_COMPRESSION</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ODX_CREATE_COMPRESSION'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>ODX_CREATE_ENCRYPTION</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ODX_CREATE_ENCRYPTION'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>ODX_EXTRN_COMPRESSION</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ODX_EXTRN_COMPRESSION'" />
      </xsl:call-template>
    </Value>
  </Item>
  <Item>
    <ID>ODX_EXTRN_ENCRYPTION</ID>
    <Value>
      <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'ODX_EXTRN_ENCRYPTION'" />
      </xsl:call-template>
    </Value>
  </Item>
			
			<Item>
				<ID>Matrix_DFID</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'Matrix_DFID'" />
						</xsl:call-template>
				</Value>
			</Item>
		
          <Item>
            <ID>SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION</ID>
            <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION'"/>
              </xsl:call-template>
            </Value>
          </Item>
          
          <Item>
	              <ID>SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION</ID>
	              <Value>
	                <xsl:call-template name="GetEnvironmentValue">
	                  <xsl:with-param name="LookUpItem" select="'SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION'"/>
	                </xsl:call-template>
	              </Value>
          </Item>
          
           <Item>
	  	              <ID>HEADER_FOR_SGIDB_DATA</ID>
	  	              <Value>
	  	                <xsl:call-template name="GetEnvironmentValue">
	  	                  <xsl:with-param name="LookUpItem" select="'HEADER_FOR_SGIDB_DATA'"/>
	  	                </xsl:call-template>
	  	              </Value>
          </Item>
          
          <Item>
	  	  	              <ID>PD_SUB_VARIANT_SELECTION_MATRIX_NAME</ID>
	  	  	              <Value>
	  	  	                <xsl:call-template name="GetEnvironmentValue">
	  	  	                  <xsl:with-param name="LookUpItem" select="'PD_SUB_VARIANT_SELECTION_MATRIX_NAME'"/>
	  	  	                </xsl:call-template>
	  	  	              </Value>
          </Item>
          
		
		<Item>
	  	  	  	              <ID>CHECKSUM_LENGTH_SPECIFIC_REGEX</ID>
	  	  	  	              <Value>
	  	  	  	                <xsl:call-template name="GetEnvironmentValue">
	  	  	  	                  <xsl:with-param name="LookUpItem" select="'CHECKSUM_LENGTH_SPECIFIC_REGEX_TEMPLATE'"/>
	  	  	  	                </xsl:call-template>
	  	  	  	              </Value>
          </Item>
		<Item>
            <ID>SCRIPT_TOCONVERT_AESKEY_BIGENDIAN</ID>
            <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_TOCONVERT_AESKEY_BIGENDIAN_TEMPLATE'"/>
              </xsl:call-template>
            </Value>
          </Item>
	    <Item>
            <ID>SCRIPT_TOCONVERT_AES_INITIALKEY_BIGENDIAN</ID>
            <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_TOCONVERT_AES_INITIALKEY_BIGENDIAN_TEMPLATE'"/>
              </xsl:call-template>
            </Value>
          </Item>	
<Item>
	  	  	  	              <ID>NumberOfInfoBlocks</ID>
	  	  	  	              <Value>
	  	  	  	                <xsl:call-template name="GetInfoblockCount">
						<xsl:with-param name="File">
						  <xsl:call-template name="RunTime_FileList_GetFileDirectory">
		 		                    <xsl:with-param name="FileClassID" select="'HexMod17_AddressModel'"/>
	                			    <xsl:with-param name="GetValue" select="'yes'"/>
				                  </xsl:call-template>
	                			  <xsl:value-of select="'\'"/>
				                  <xsl:call-template name="RunTime_FileList_GetFileName">
	                			    <xsl:with-param name="FileClassID" select="'HexMod17_AddressModel'"/>
	                			   <xsl:with-param name="GetValue" select="'yes'"/>
				                  </xsl:call-template>
						</xsl:with-param>
							</xsl:call-template>
	  	  	  	              </Value>
          </Item>
          
        
          
          <Item>
	  	              <ID>INPUT_CONFIGURATION_INIT_WITHOUT_SIGN</ID>
	  	              <Value>
	  	                <xsl:call-template name="GetEnvironmentValue">
	  	                  <xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_WITHOUT_SIGN'"/>
	  	                </xsl:call-template>
	  	              </Value>
          </Item>
          
           <Item>
	  	  	              <ID>INPUT_CONFIGURATION_INIT_WITH_SIGN</ID>
	  	  	              <Value>
	  	  	                <xsl:call-template name="GetEnvironmentValue">
	  	  	                  <xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_WITH_SIGN'"/>
	  	  	                </xsl:call-template>
	  	  	              </Value>
	            </Item>
	            
	            
	              <Item>
		    	  	  	              <ID>INPUT_SIGN_FLAG_DATA</ID>
		    	  	  	              <Value>
		    	  	  	                <xsl:call-template name="GetEnvironmentValue">
		    	  	  	                  <xsl:with-param name="LookUpItem" select="'INPUT_SIGN_FLAG_DATA'"/>
		    	  	  	                </xsl:call-template>
		    	  	  	              </Value>
		    	            </Item>
		    	            
		    	              <Item>
					      <ID>SCRIPTGENERATOR_ODXCREATE_OCNF_FILE_TEMPLATE</ID>
					      <Value>
						<xsl:call-template name="GetEnvironmentValue">
						  <xsl:with-param name="LookUpItem" select="'SCRIPTGENERATOR_ODXCREATE_OCNF_FILE_TEMPLATE'"/>
						</xsl:call-template>
					      </Value>
				     </Item>

			<Item>
				<ID>START_ADDRESS_SGIDB3</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'BasSvrAppl_EepPrgVer_C'"/>
				</xsl:call-template></Value>
			</Item>
			<Item>
				<ID>BasSvrAppl_EepPartNr_C</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'BasSvrAppl_EepPartNr_C'"/>
				</xsl:call-template></Value>
			</Item>
			<Item>
				<ID>BasSvrAppl_EepODXFileID_C</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'BasSvrAppl_EepODXFileID_C'"/>
				</xsl:call-template></Value>
			</Item>
			<Item>
				<ID>BasSvrAppl_EepODXFileVer_C</ID>
				<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'BasSvrAppl_EepODXFileVer_C'"/>
				</xsl:call-template></Value>
			</Item>
<Item>
					<ID>HEXMODX_PATCH_SGIDB3_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_PATCH_SGIDB3_INPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_INPUT_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_PATCH_SGIDB3_PATCHANDCHECK_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_PATCHANDCHECK_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_PATCH_SGIDB3_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
						<ID>HEXMODX_CREATE_HEX_TOBIN_MAIN_XML</ID>
						<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_HEX_TOBIN_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_READ_ODXIDENT_AND_VERSION_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_SGIDB1_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMOD_READ_ODXIDENT_AND_VERSION_INPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_SGIDB1_PATCHANDCHECK_INPUT_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMOD_READ_ODXIDENT_AND_VERSION_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_SGIDB1_PATCHANDCHECK_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_READ_ODXIDENT_AND_VERSION_PATCHANDCHECK_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_ODXIDENT_AND_VERSION_PATCHANDCHECK_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
					<ID>HEXMODX_CALCULATE_CHECKSUM_MAIN_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CALCULATE_CHECKSUM_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>HEXMODX_PATCH_SGIDB3_FORMX17_PATCHANDCHECK_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_FORMX17_PATCHANDCHECK_XML'"/></xsl:call-template></Value>
				</Item>
				
				
				<!--<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_ABM_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
						<ID>HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML</ID>
						<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML'"/></xsl:call-template></Value>
				</Item>
				<Item>
							<ID>HEXMODX_CHECKSUM_ADJUST_INPUT_XML</ID>
							<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
						<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_XML</ID>
						<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_XML'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML'"/></xsl:call-template></Value>
				</Item>--> 
				<Item>
					<ID>Eep_EnvRamClr_CW</ID>
					<Value><xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'Eep_EnvRamClr_CW'"/>
					</xsl:call-template></Value>
				</Item>
				<Item>
					<ID>Eep_EnFirstInit_CW</ID>
					<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'Eep_EnFirstInit_CW'"/>
					</xsl:call-template></Value>
				</Item>
				<Item>
					<ID>READ_ODXFILEID_VERSION_FROM_XMLFILE</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'READ_ODXFILEID_VERSION_FROM_XMLFILE'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>AES_KEY</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'AES_KEY'"/></xsl:call-template></Value>
				</Item>
				
				<Item>
					<ID>AESInitial_KEY</ID>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'AESInitial_KEY'"/></xsl:call-template></Value>
				</Item>

	<Item>
		<ID>HEXMOD_SCRIPT_SIGNATURE_TEMPLATE</ID>
		<Value>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_SCRIPT_SIGNATURE_TEMPLATE'"/>
			</xsl:call-template>
		</Value>
	</Item>	
	<Item>
			<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML</ID>
			<Value>
				<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML'"/>
				</xsl:call-template>
			</Value>
	</Item>
	<Item>
			<ID>HEXMODX_CLEANUP_HEXFILE_WITHOUT_HSM_MAIN_XML</ID>
			<Value>
				<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_WITHOUT_HSM_MAIN_XML'"/>
				</xsl:call-template>
			</Value>
	</Item>

	<Item>
		<ID>HEXMODX_HEX_TOBIN_INPUT_TEMPLATE</ID>
		<Value>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_HEX_TOBIN_INPUT_TEMPLATE'"/>
			</xsl:call-template>
		</Value>
	</Item>
	<Item>
	            <ID>Imo_idxLab_C_VW</ID>
	            <Value>
	              <xsl:call-template name="RunTime_Data_Value">
	                <xsl:with-param name="DataClassID" select="'Imo_idxLab_C_VW'" />
	              </xsl:call-template>
	            </Value>
          </Item>
           <Item>
	              <ID>SY_WFS</ID>
	              <Value>
	                <xsl:call-template name="RunTime_Data_Value">
	                  <xsl:with-param name="DataClassID" select="'SY_WFS'"/>
	                </xsl:call-template>
	              </Value>
          </Item>
          
          <Item>
	  		<ID>VARIABLELIST_DOSERPATCH_PATCHES_FILE</ID>
	  		<Value>
	  			<xsl:call-template name="GetEnvironmentValue">
	  				<xsl:with-param name="LookUpItem" select="'VARIABLELIST_DOSERPATCH_PATCHES_FILE'"/>
	  			</xsl:call-template>
	  		</Value>
	</Item>
	 <Item>
		  		<ID>PATCHKEYID_VALIDATION_MATRIX_NAME</ID>
		  		<Value>
		  			<xsl:call-template name="GetEnvironmentValue">
		  				<xsl:with-param name="LookUpItem" select="'PATCHKEYID_VALIDATION_MATRIX_NAME'"/>
		  			</xsl:call-template>
		  		</Value>
	</Item>
	
	<Item>
				  		<ID>PATCHKEYID_MATRIX_NAME</ID>
				  		<Value>
				  			<xsl:call-template name="GetEnvironmentValue">
				  				<xsl:with-param name="LookUpItem" select="'PATCHKEYID_MATRIX_NAME'"/>
				  			</xsl:call-template>
				  		</Value>
	</Item>
	
	<Item>
						  		<ID>DERIVE_KDNR_PARAMETER_MATRIX_NAME</ID>
						  		<Value>
						  			<xsl:call-template name="GetEnvironmentValue">
						  				<xsl:with-param name="LookUpItem" select="'DERIVE_KDNR_PARAMETER_MATRIX_NAME'"/>
						  			</xsl:call-template>
						  		</Value>
	</Item>
	
	
	<Item>
			<ID>FAZITDB_MATRIX_NAME</ID>
			<Value>
				<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'FAZITDB_MATRIX_NAME'"/>
				</xsl:call-template>
			</Value>
	</Item>
	
	<Item>
					<ID>KUNDENMARKE_MATRIX_NAME</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'KUNDENMARKE_MATRIX_NAME'"/>
						</xsl:call-template>
					</Value>
	</Item>
	<Item>
						<ID>MATRIX_PATH</ID>
						<Value>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'MATRIX_PATH'"/>
							</xsl:call-template>
						</Value>
	</Item>
	<Item>
							<ID>WFS_SELECT_MATRIX_NAME</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'WFS_SELECT_MATRIX_NAME'"/>
					</xsl:call-template>
				</Value>
	</Item>
	<Item>
									<ID>EE_LAYOUT_MATRIX_NAME</ID>
						<Value>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'EE_LAYOUT_MATRIX_NAME'"/>
							</xsl:call-template>
						</Value>
	</Item>
	<Item>
				<ID>DEBUG_LEVEL_MATRIX_NAME</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'DEBUG_LEVEL_MATRIX_NAME'"/>
					</xsl:call-template>
				</Value>
	</Item>
	<Item>
						<ID>FLASH_OTP_MATRIX_NAME</ID>
						<Value>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'FLASH_OTP_MATRIX_NAME'"/>
							</xsl:call-template>
						</Value>
	</Item>
<Item>
				<ID>HSM_OTP_MATRIX_NAME</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HSM_OTP_MATRIX_NAME'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>OTP_REFERENCE_DERIVATION_MATRIX_NAME</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'OTP_REFERENCE_DERIVATION_MATRIX_NAME'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_PATCH_INFOBLOCK_WITH_SWTTNR_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_SWTTNR_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_PATCH_INFOBLOCK_WITH_FSWID_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_FSWID_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_PATCH_INFOBLOCK_WITH_HSM1_AND_SWTTNR_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_HSM1_AND_SWTTNR_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_PATCH_INFOBLOCK_WITH_HSM2_AND_SWTTNR_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_HSM2_AND_SWTTNR_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNATURE_HASH_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNTXT_TPROTCONF_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNTXT_TPROTCONF_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNATURE_HASH_WITHOUTHSMBLOCKS_TPROTCONF_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_WITHOUTHSMBLOCKS_TPROTCONF_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNED_HEXFILE_TPROTCONF_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNED_HEXFILE_TPROTCONF_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATE_SIGNED_HEXFILE_WITHOUTHSMBLOCKS_TPROTCONF_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNED_HEXFILE_WITHOUTHSMBLOCKS_TPROTCONF_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATEADDRESSMODEL_WITH_HSM_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATEADDRESSMODEL_WITH_HSM_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATEADDRESSMODEL_WITHOUT_HSMBLOCKS_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATEADDRESSMODEL_WITHOUT_HSMBLOCKS_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATEADDRESSMODEL_INFOBLOCK_FORHSM0_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATEADDRESSMODEL_INFOBLOCK_FORHSM0_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CREATEADDRESSMODEL_INFOBLOCK_FORHSM1_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATEADDRESSMODEL_INFOBLOCK_FORHSM1_XML'"/>
					</xsl:call-template>
				</Value>
</Item>

<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_ABM_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_WITHOUTHSMBLOCKS_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_WITHOUTHSMBLOCKS_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML'"/>
					</xsl:call-template>
				</Value>
</Item>

<Item>
				<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUTHSMBLOCKS_WITHOUT_ABM_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUTHSMBLOCKS_WITHOUT_ABM_XML'"/>
					</xsl:call-template>
				</Value>
</Item>


<Item>
				<ID>HEXMODX_EXECUTE_PATCHSCRIPT_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMOD_PATCHCHECK_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMOD_PATCHCHECK_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMOD_PATCHCHECK_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECK_TPROT_CLEANUP_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECK_TPROT_CLEANUP_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECK_TPROT_CLEANUP_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECK_TPROT_CLEANUP_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECK_TPROT_CLEANUP_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECK_TPROT_CLEANUP_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_CHECK_TPROT_CLEANUP_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECK_TPROT_CLEANUP_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_TPROT_MERGE_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_TPROT_MERGE_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_TPROT_MERGE_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_TPROT_MERGE_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_TPROT_MERGE_CLEANUP_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_TPROT_MERGE_CLEANUP_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_TPROT_MERGE_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_TPROT_MERGE_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_INFOBLOCK_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_INFOBLOCK_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_IB_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_IB_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_IB_INFOBLOCK_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_INFOBLOCK_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_IB_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_MERGE_PROG_DATA_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_PROG_DATA_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_MERGE_PROG_DATA_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_PROG_DATA_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_MERGE_PROG_DATA_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_MERGE_PROG_DATA_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_DATAPART_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_DATAPART_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_DATAPART_INPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_DATAPART_INPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
				<ID>HEXMODX_DELETE_DATAPART_OUTPUT_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_DATAPART_OUTPUT_XML'"/>
					</xsl:call-template>
				</Value>
</Item>




<Item>
				<ID>HEXMODX_GET_KONSERVE_LABELS_MAIN_XML</ID>
				<Value>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_GET_KONSERVE_LABELS_MAIN_XML'"/>
					</xsl:call-template>
				</Value>
</Item>
<Item>
	<ID>HEXMODX_GET_KONSERVE_LABELS_INPUT_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_GET_KONSERVE_LABELS_INPUT_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_GET_KONSERVE_LABELS_PATCHCHECK_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_GET_KONSERVE_LABELS_PATCHCHECK_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CLEANUP_HEXFILE_MAIN_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_MAIN_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CLEANUP_HEXFILE_INPUT_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_INPUT_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CLEANUP_HEXFILE_OUTPUT_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_OUTPUT_XML'"/>
		</xsl:call-template>
	</Value>
</Item>

<Item>
	<ID>HEXMODX_HEXFILE_CLEANUP_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_HEXFILE_CLEANUP_XML'"/>
		</xsl:call-template>
	</Value>
</Item>

<Item>
	<ID>SCRIPT_HEXMODX_CREATE_FLASH_0_HEXFILE</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'SCRIPT_HEXMODX_CREATE_FLASH_0_HEXFILE'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>OTP_CONDITIONCHECK_FILE</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_CONDITIONCHECK_FILE'"/>
		</xsl:call-template>
	</Value>
</Item>







<Item>
	<ID>OTP_KEY_REF_FILEPATH</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_KEY_REF_FILEPATH'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>OTP_KEY_LOG_FILEPATH</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_KEY_LOG_FILEPATH'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>OTP_ENV_TYPE_NUMBER</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_ENV_TYPE_NUMBER'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>OTP_CUSTOMERIDENTITY_INDEX_DEC</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_CUSTOMERIDENTITY_INDEX_DEC'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>OTP_CUSTOMERIDENTITY_INDEX_HEX</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'OTP_CUSTOMERIDENTITY_INDEX_HEX'"/>
		</xsl:call-template>
	</Value>
</Item>	

<Item>
	<ID>RAW_MCS_VERSION_MATRIX_NAME</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'RAW_MCS_VERSION_MATRIX_NAME'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>RAW_MCS_VERSION_FOR_GUAM_MATRIX_NAME</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'RAW_MCS_VERSION_FOR_GUAM_MATRIX_NAME'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_REPROG_SIGNATURE_HASH_TPROTCONF_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_REPROG_SIGNATURE_HASH_TPROTCONF_XML'"/>
		</xsl:call-template>
	</Value>
</Item>	
<Item>
	<ID>HEXMODX_CREATE_FLASH0_SIGNATURE_HASH_TPROTCONF_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_FLASH0_SIGNATURE_HASH_TPROTCONF_XML'"/>
		</xsl:call-template>
	</Value>
</Item>	
<Item>
	<ID>ENDIAN_TYPE_CNT</ID>
             <Value>
               <xsl:call-template name="RunTime_Data_Value">
                 <xsl:with-param name="DataClassID" select="'ENDIAN_TYPE_CNT'"/>
                </xsl:call-template>
            </Value>
</Item>	

<Item>
	<ID>CMBTYP_SY</ID>
             <Value>
              <xsl:call-template name="GetCMBTYP_SY"></xsl:call-template>
            </Value>
</Item>
	
<Item>
	<ID>SCRIPT_KONSERVE_PATCHANDCHECK_LABELS_TEMPLATE</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'SCRIPT_KONSERVE_PATCHANDCHECK_LABELS_TEMPLATE'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>READ_Imo_idxLab_C_VW_FROM_FILE</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'READ_Imo_idxLab_C_VW_FROM_FILE'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>SCRIPT_GENERATOR_CREATE_ODX_SOFTWARELIST</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'SCRIPT_GENERATOR_CREATE_ODX_SOFTWARELIST'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_HEX_TO_COMPRESSED_BIN_MAIN_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_HEX_TO_COMPRESSED_BIN_MAIN_XML'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>FLASH0_OFFSET</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>FLASH0_OFFSET_1</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET_1'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>FLASH0_OFFSET_FACTORY</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET_1'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_FLASH0_SIGNED_HEXFILE_TPROTCONF_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_FLASH0_SIGNED_HEXFILE_TPROTCONF_XML'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>HSM_ADDFEATURE_MATRIX_NAME</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HSM_ADDFEATURE_MATRIX_NAME'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>SCRIPT_INCLUDE_SECTIONS_IN_RAW_FILE</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'SCRIPT_INCLUDE_SECTIONS_IN_RAW_FILE'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>TP_MASK_VALUE</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'TP_MASK_VALUE'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>BYTE_BLOCK_LENGTH</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'BYTE_BLOCK_LENGTH'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>PATTERN_CREATE_BINFILE_FROM_HASHFILE</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'PATTERN_CREATE_BINFILE_FROM_HASHFILE'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>SCRIPT_REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'SCRIPT_REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>HEXMODX_CREATE_SIGNATURE_SIGN_MAIN_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_SIGN_MAIN_XML'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM0_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM0_XML'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM1_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM1_XML'"/>
		</xsl:call-template>
            </Value>
</Item>

<Item>
	<ID>HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_MAIN_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_MAIN_XML'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_INFOBLOCK_XML</ID>
             <Value>
             <xsl:call-template name="GetEnvironmentValue">
	     			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_INFOBLOCK_XML'"/>
		</xsl:call-template>
            </Value>
</Item>
<Item>
            <ID>HEXMODX_ERASE_NON_BOOTBLOCKS_INCLUDING_HSM_INPUT_XML</ID>
 	  <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'HEXMODX_ERASE_NON_BOOTBLOCKS_INCLUDING_HSM_INPUT_XML'"/>
              </xsl:call-template>
            </Value>
   </Item>
<Item>
            <ID>HEXMODX_ERASE_NON_BOOTBLOCKS_MAIN_XML</ID>
 	  <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'HEXMODX_ERASE_NON_BOOTBLOCKS_MAIN_XML'"/>
              </xsl:call-template>
            </Value>
   </Item>
   <Item>
            <ID>HEXMODX_ERASE_NON_BOOTBLOCKS_INPUT_XML</ID>
            <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'HEXMODX_ERASE_NON_BOOTBLOCKS_INPUT_XML'"/>
              </xsl:call-template>
            </Value>
   </Item>
  <Item>
            <ID>HEXMODX_ERASE_NON_BOOTBLOCKS_OUTPUT_XML</ID>
            <Value>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'HEXMODX_ERASE_NON_BOOTBLOCKS_OUTPUT_XML'"/>
              </xsl:call-template>
            </Value>
  </Item>
 
  <Item>
                <ID>HEXMODX_CHECKSUM_ADJUST_FLASH0_INFOBLOCK_XML</ID>
                <Value>
              		<xsl:call-template name="GetEnvironmentValue">
		                <xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_INFOBLOCK_XML'"/>
              		</xsl:call-template>
                </Value>
  </Item>
<Item>
                <ID>HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_WITHOUT_ABM_XML</ID>
                <Value>
              		<xsl:call-template name="GetEnvironmentValue">
		                <xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_WITHOUT_ABM_XML'"/>
              		</xsl:call-template>
                </Value>
  </Item>
  <Item>
                  <ID>HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_XML</ID>
                  <Value>
                		<xsl:call-template name="GetEnvironmentValue">
  		                <xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_XML'"/>
                		</xsl:call-template>
                  </Value>
  </Item>

 <Item>
                  <ID>PP_XMLDB_PATHNAME</ID>
                  <Value>
                		<xsl:call-template name="GetEnvironmentValue">
  		                <xsl:with-param name="LookUpItem" select="'PP_XMLDB_PATHNAME'"/>
                		</xsl:call-template>
                  </Value>
  </Item>
  
  <Item>
                    <ID>PP_XMLDB_BACKUP_PATHNAME</ID>
                    <Value>
                  		<xsl:call-template name="GetEnvironmentValue">
    		                <xsl:with-param name="LookUpItem" select="'PP_XMLDB_BACKUP_PATHNAME'"/>
                  		</xsl:call-template>
                    </Value>
  </Item>
  
    <Item>
                      <ID>FLASHCONFIGURATION_STANDARD_CONFIGFILE</ID>
                      <Value>
                    		<xsl:call-template name="GetEnvironmentValue">
      		                <xsl:with-param name="LookUpItem" select="'FLASHCONFIGURATION_STANDARD_CONFIGFILE'"/>
                    		</xsl:call-template>
                      </Value>
    </Item>
     <Item>
                          <ID>PP_IB_AddressList</ID>
                          <Value>
                        	<xsl:call-template name="RunTime_Data_ValueNode">
						<xsl:with-param name="DataClassID" select="'PP_IB_AddressList'" />
						</xsl:call-template>	
                          </Value>
        </Item>

		<Item>
                <ID>SCRIPT_HEXMOD_READ_BLOCKVERSION</ID>
                <Value>
              		<xsl:call-template name="GetEnvironmentValue">
                  <xsl:with-param name="LookUpItem" select="'SCRIPT_HEXMOD_READ_BLOCKVERSION'"/>
              		</xsl:call-template>
                </Value>
        </Item>
        
        <Item>
	              <ID>HEXMOD_PATCHBLOCKVERSION_MAIN_XML</ID>
	              <Value>
	            		<xsl:call-template name="GetEnvironmentValue">
	          	     <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHBLOCKVERSION_MAIN_XML'"/>
	            		</xsl:call-template>
	              </Value>
        </Item>
          <Item>
		                          <ID>HEXMOD_PATCHBLOCKVERSION_INPUT_XML</ID>
		                          <Value>
		                        		<xsl:call-template name="GetEnvironmentValue">
		          		                <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHBLOCKVERSION_INPUT_XML'"/>
		                        		</xsl:call-template>
		                          </Value>
        </Item>
          <Item>
			          <ID>HEXMOD_PATCHBLOCKVERSION_PATCHCHECK_XML</ID>
			          <Value>
			        		<xsl:call-template name="GetEnvironmentValue">
			            <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHBLOCKVERSION_PATCHCHECK_XML'"/>
			        		</xsl:call-template>
			          </Value>
        </Item>
          <Item>
				      <ID>HEXMOD_PATCHBLOCKVERSION_OUTPUT_XML</ID>
				      <Value>
				    		<xsl:call-template name="GetEnvironmentValue">
				        <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHBLOCKVERSION_OUTPUT_XML'"/>
				    		</xsl:call-template>
				      </Value>
        </Item>
        
          <Item>
			        <ID>HEXMOD_READBLOCKVERSION_MAIN_XML</ID>
					  <Value>
							<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_READBLOCKVERSION_MAIN_XML'"/>
							</xsl:call-template>
					  </Value>
	        </Item>
	        
	          <Item>
					        <ID>HEXMOD_READBLOCKVERSION_INPUT_XML</ID>
							  <Value>
									<xsl:call-template name="GetEnvironmentValue">
									<xsl:with-param name="LookUpItem" select="'HEXMOD_READBLOCKVERSION_INPUT_XML'"/>
									</xsl:call-template>
							  </Value>
			        </Item>
			          <Item>
						 <ID>HEXMOD_READBLOCKVERSION_PATCHCHECK_XML</ID>
							  <Value>
									<xsl:call-template name="GetEnvironmentValue">
									<xsl:with-param name="LookUpItem" select="'HEXMOD_READBLOCKVERSION_PATCHCHECK_XML'"/>
									</xsl:call-template>
							  </Value>
				</Item>
				  <Item>
						<ID>SCRIPT_HEXMOD_PATCH_BLOCKVERSION</ID>
						  <Value>
								<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_HEXMOD_PATCH_BLOCKVERSION'"/>
								</xsl:call-template>
						  </Value>
				</Item>
				
				  <Item>
						<ID>HEXMOD_CREATE_INFOTABLE_MAIN_XML</ID>
						<Value>
							<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATE_INFOTABLE_MAIN_XML'"/>
							</xsl:call-template>
						</Value>
				</Item>
				  <Item>
						 <ID>HEXMOD_CREATE_INFOTABLE_INFOBLOCK_XML</ID>
					  <Value>
							<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATE_INFOTABLE_INFOBLOCK_XML'"/>
							</xsl:call-template>
					  </Value>
				</Item>
				<Item>
						 <ID>HEXMOD_CREATE_INFOTABLE_INPUT_XML</ID>
					  <Value>
							<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_CREATE_INFOTABLE_INPUT_XML'"/>
							</xsl:call-template>
					  </Value>
				</Item>
				<Item>
					<ID>ECU_TYPE_MATRIX_NAME</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'ECU_TYPE_MATRIX_NAME'"/>
						</xsl:call-template>
					</Value>
				</Item>	
			<Item>
     <ID>HWRef_XMLDB_PATHNAME</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HWRef_XMLDB_PATHNAME'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
     <ID>HWRef_XMLDB_BACKUP_PATHNAME</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HWRef_XMLDB_BACKUP_PATHNAME'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
        <ID>HWRef_XMLDB_LOCK_PATHNAME</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'HWRef_XMLDB_LOCK_PATHNAME'"/>
          </xsl:call-template>
        </Value>
   </Item>
   <Item>
     <ID>HWRef_ENV_TYPE_NUMBER</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HWRef_ENV_TYPE_NUMBER'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
     <ID>HWRef_CUSTOMERIDENTITY_INDEX_DEC</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HWRef_CUSTOMERIDENTITY_INDEX_DEC'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
     <ID>HWRef_CUSTOMERIDENTITY_INDEX_HEX</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HWRef_CUSTOMERIDENTITY_INDEX_HEX'"/>
       </xsl:call-template>
     </Value>
   </Item> 
	<Item>
      <ID>FLASH_CONFIG_SY</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'FLASH_CONFIG_SY'" />
        </xsl:call-template>
      </Value>
    </Item>
    
    <Item>
      <ID>EOL_CB_SY</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'EOL_CB_SY'" />
        </xsl:call-template>
      </Value>
    </Item>
    <Item>
      <ID>DIAG_SVRPTCOL_SY</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'DIAG_SVRPTCOL_SY'" />
        </xsl:call-template>
      </Value>
    </Item>
    <Item>
      <ID>SIA_GENR_SY</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'SIA_GENR_SY'" />
        </xsl:call-template>
      </Value>
    </Item>
	<Item>
     <ID>DERIVE_CB_TPROT_BLOCK_VERSIONS</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'DERIVE_CB_TPROT_BLOCK_VERSIONS'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
     <ID>INFOTABLE_ID_LIST</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'INFOTABLE_ID_LIST'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
     <ID>SCRIPT_HEXMODX_READ_CB_TPROT_VERSION</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'SCRIPT_HEXMODX_READ_CB_TPROT_VERSION'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
        <ID>HEXMODX_READ_CB_TPROT_VERSION_PATCHANDCHECK_XML</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'HEXMODX_READ_CB_TPROT_VERSION_PATCHANDCHECK_XML'"/>
          </xsl:call-template>
        </Value>
   </Item>
	<Item>
        <ID>SCRIPT_CRC32_CHECKSUM</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'SCRIPT_CRC32_CHECKSUM'"/>
          </xsl:call-template>
        </Value>
   </Item>
	<Item>
     <ID>HEXMODX_CALC_CRC32_CHKSUM_MAIN_XML</ID>
     <Value>
       <xsl:call-template name="GetEnvironmentValue">
         <xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_MAIN_XML'"/>
       </xsl:call-template>
     </Value>
   </Item>
   <Item>
        <ID>HEXMODX_CALC_CRC32_CHKSUM_INPUT_XML</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_INPUT_XML'"/>
          </xsl:call-template>
        </Value>
   </Item>
<Item>
        <ID>HEXMODX_CALC_CRC32_CHKSUM_CHECKSUM_XML</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_CHECKSUM_XML'"/>
          </xsl:call-template>
        </Value>
   </Item>
<Item>
        <ID>READ_CBTPROT_VERSION_FROM_FILE</ID>
        <Value>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'READ_CBTPROT_VERSION_FROM_FILE'"/>
          </xsl:call-template>
        </Value>
   </Item>
   
   <Item>
           <ID>PED_SCRIPT_HEX_COMPARE_TEMPLATE</ID>
           <Value>
             <xsl:call-template name="GetEnvironmentValue">
               <xsl:with-param name="LookUpItem" select="'PED_SCRIPT_HEX_COMPARE_TEMPLATE'"/>
             </xsl:call-template>
           </Value>
   </Item>
   <Item>
           <ID>SCRIPT_HEX_COMPARE_LOGISTIC_LOG_TEMPLATE</ID>
           <Value>
             <xsl:call-template name="GetEnvironmentValue">
               <xsl:with-param name="LookUpItem" select="'SCRIPT_HEX_COMPARE_LOGISTIC_LOG_TEMPLATE'"/>
             </xsl:call-template>
           </Value>
   </Item>
   
   <Item>
                 <ID>SCRIPT_DERIVE_ADDRESS_MODEL_INFO</ID>
                 <Value>
                   <xsl:call-template name="GetEnvironmentValue">
                     <xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_ADDRESS_MODEL_INFO'"/>
                   </xsl:call-template>
                 </Value>
   </Item>
   
    <Item>
                    <ID>SCRIPT_READ_CB_INFOBLOCKID_302</ID>
                    <Value>
                      <xsl:call-template name="GetEnvironmentValue">
                        <xsl:with-param name="LookUpItem" select="'SCRIPT_READ_CB_INFOBLOCKID_302'"/>
                      </xsl:call-template>
                    </Value>
   </Item>
   
     <Item>
                       <ID>SCRIPT_DERIVE_VARIANT_CODING_INPUTS</ID>
                       <Value>
                         <xsl:call-template name="GetEnvironmentValue">
                           <xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_VARIANT_CODING_INPUTS'"/>
                         </xsl:call-template>
                       </Value>
   </Item>
   
     <Item>
                          <ID>HEXMODX_EXECUTE_PATCHSCRIPT_PATCHCHECK_XML</ID>
                          <Value>
                            <xsl:call-template name="GetEnvironmentValue">
                              <xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_PATCHCHECK_XML'"/>
                            </xsl:call-template>
                          </Value>
               </Item>
                 <Item>         
                            <ID>CALCULATE_OFFSET_ADDRESS_FOR_CB_INFOBLOCKID</ID>
			                            <Value>
			                              <xsl:call-template name="GetEnvironmentValue">
			                                <xsl:with-param name="LookUpItem" select="'CALCULATE_OFFSET_ADDRESS_FOR_CB_INFOBLOCKID'"/>
			                              </xsl:call-template>
                          </Value>
				</Item>
				  <Item>
					<ID>InjCrv_numInjMaxSys_C_Start_Address</ID>
					<Value>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'InjCrv_numInjMaxSys_C'" />
					</xsl:call-template>
					</Value>
				</Item>

		  <Item>
            <ID>CWEVAB_Start_Address</ID>
            <Value>
              <xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'CWEVAB'"/>
              </xsl:call-template>
            </Value>
          </Item>
	<Item>
                    <ID>HEXMODX_PATCH_SGIDB3_DRIVABLENO_EDC17_PATCHANDCHECK_XML</ID>
                    <Value>
                      <xsl:call-template name="GetEnvironmentValue">
                        <xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_DRIVABLENO_EDC17_PATCHANDCHECK_XML'"/>
                      </xsl:call-template>
                    </Value>
   </Item>
   <Item>
                    <ID>HEXMODX_PATCH_SGIDB3_FORMX17_DRIVABLENO_PATCHANDCHECK_XML</ID>
                    <Value>
                      <xsl:call-template name="GetEnvironmentValue">
                        <xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_SGIDB3_FORMX17_DRIVABLENO_PATCHANDCHECK_XML'"/>
                      </xsl:call-template>
                    </Value>
   </Item>
   <Item>
                    <ID>HSM0_STARTADDRESS_FOR_TCODX</ID>
                    <Value>
                      <xsl:call-template name="GetEnvironmentValue">
                        <xsl:with-param name="LookUpItem" select="'HSM0_STARTADDRESS_FOR_TCODX'"/>
                      </xsl:call-template>
                    </Value>
   </Item>
   <Item>
                    <ID>HSM1_STARTADDRESS_FOR_TCODX</ID>
                    <Value>
                      <xsl:call-template name="GetEnvironmentValue">
                        <xsl:with-param name="LookUpItem" select="'HSM1_STARTADDRESS_FOR_TCODX'"/>
                      </xsl:call-template>
                    </Value>
   </Item>
   <Item>         
           <ID>BuildMode</ID>
	       <Value>
	              <xsl:call-template name="GetBuildMode"></xsl:call-template>
         	</Value>
   </Item>
    <Item>         
              <ID>INPUT_SIGN_TXT_FILE</ID>
   	       <Value>
   	              <xsl:call-template name="GetEnvironmentValue">
		                      <xsl:with-param name="LookUpItem" select="'INPUT_SIGN_TXT_FILE'"/>
                      </xsl:call-template>
            	</Value>
   </Item>
      <Item>
              <ID>CONTAINER_PARAMETER_MATRIX_NAME</ID>
              <Value>
                <xsl:call-template name="GetEnvironmentValue">
                  <xsl:with-param name="LookUpItem" select="'CONTAINER_PARAMETER_MATRIX_NAME'"/>
                </xsl:call-template>
              </Value>
   </Item>
   <Item>
      <ID>ENDIAN_TYPE</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'ENDIAN_TYPE'" />
        </xsl:call-template>
      </Value>
    </Item>
	<Item>
    <ID>FEE_EMULATION_TYPE_HSM</ID>
    <Value>
	     <xsl:if test="$FEE_EMULATION_TYPE_HSM='1'">
		   <xsl:call-template name="RunTime_Data_Value">
            <xsl:with-param name="DataClassID" select="'FEE_EMULATION_TYPE_HSM'"/>
            </xsl:call-template>
	       </xsl:if>
		 <xsl:if test="$FEE_EMULATION_TYPE_HSM='0'">
             <xsl:value-of select="'NOVALUEFOUND'"/>
		 </xsl:if>
    </Value>
  </Item>
  <Item>
    <ID>FEE_EMULATION_TYPE_HOST</ID>
    <Value>
	<xsl:if test="$FEE_EMULATION_TYPE_HOST='1'">
		   <xsl:call-template name="RunTime_Data_Value">
        <xsl:with-param name="DataClassID" select="'FEE_EMULATION_TYPE_HOST'"/>
      </xsl:call-template>
	       </xsl:if>
		 <xsl:if test="$FEE_EMULATION_TYPE_HOST='0'">
             <xsl:value-of select="'NOVALUEFOUND'"/>
		 </xsl:if>
    </Value>
  </Item>
  <Item>         
                 <ID>EEE_TYPE_MATRIX_NAME</ID>
      	       <Value>
      	              <xsl:call-template name="GetEnvironmentValue">
   		                      <xsl:with-param name="LookUpItem" select="'EEE_TYPE_MATRIX_NAME'"/>
                         </xsl:call-template>
               	</Value>
   </Item>
   <Item>
	<ID>RAW_MCS_VERSION_PATH</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'RAW_MCS_VERSION_PATH'"/>
		</xsl:call-template>
	</Value>
</Item>
   <Item>
	<ID>DELETE_HSM0_BLOCK</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'DELETE_HSM0_BLOCK'"/>
		</xsl:call-template>
	</Value>
</Item>
   <Item>
	<ID>DELETE_HSM1_BLOCK</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'DELETE_HSM1_BLOCK'"/>
		</xsl:call-template>
	</Value>
</Item>
   <Item>
	<ID>HEXMODX_DELETE_HSMIB_MAIN_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_HSMIB_MAIN_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
 <Item>
	<ID>INPUT_CONFIGURATION_INIT</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>INPUT_CONFIGURATION_INIT_FOR_OUTPUTFILENAME_FLAG</ID>
     <Value>
		<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'INPUT_CONFIGURATION_INIT_FOR_OUTPUTFILENAME_FLAG'"/>
		</xsl:call-template>
	 </Value>
</Item> 
<Item>
	<ID>HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_EXTERN_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_EXTERN_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_EXTERN_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_TPROTCONF_EXTERN_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
  <Item>
            <ID>SW_BLOCKS</ID>
            <Value>
              <xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'SW_BLOCKS'"/>
              </xsl:call-template>
            </Value>
          </Item>
		   <Item>
            <ID>OUTPUTFILENAME_FLAG</ID>
            <Value>
              <xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'OUTPUTFILENAME_FLAG'"/>
              </xsl:call-template>
            </Value>
          </Item>
		  <Item>
            <ID>DEFAULTFILENAME</ID>
		     <Value>
              <xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'DEFAULTFILENAME'"/>
              </xsl:call-template>
            </Value>
          </Item>
		  <Item>
            <ID>ToolVersion</ID>
		     <Value>
              <xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'ToolVersion'"/>
              </xsl:call-template>
            </Value>
          </Item>
		  <Item>
      <ID>SIGN_TOOL_BLOCKS</ID>
      <Value>
        <xsl:call-template name="RunTime_Data_Value">
          <xsl:with-param name="DataClassID" select="'SIGN_TOOL_BLOCKS'" />
        </xsl:call-template>
      </Value>
    </Item>
		  <Item>
	<ID>SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'SCRIPT_COMPARE_SOFTWARE_BLOCK_INFORMATION'"/>
		</xsl:call-template>
	</Value>
</Item>

  <Item>
	<ID>SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_SIGNTXT_TPROTCONF_EXTERNAL_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNTXT_TPROTCONF_EXTERNAL_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CREATE_SIGNED_HEXFILE_TPROTCONF_EXTERNAL_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNED_HEXFILE_TPROTCONF_EXTERNAL_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_EXTERNAL_XML</ID>
	<Value>
		<xsl:call-template name="GetEnvironmentValue">
			<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_EXTERNAL_XML'"/>
		</xsl:call-template>
	</Value>
</Item>
<Item>
	<ID>PD_SUB_VARIANT_SELECTION_MATRIX_NAME</ID>
		<Value>
		<xsl:call-template name="GetEnvironmentValue">
		 <xsl:with-param name="LookUpItem" select="'PD_SUB_VARIANT_SELECTION_MATRIX_NAME'"/>
		</xsl:call-template>
		</Value>
</Item>
<Item>
		<ID>HEADER_FOR_INPUT_HEX_FILE</ID>
		<Value>
		<xsl:call-template name="GetEnvironmentValue">
		<xsl:with-param name="LookUpItem" select="'HEADER_FOR_INPUT_HEX_FILE'"/>
		</xsl:call-template>
		</Value>
</Item>
<Item>
		<ID>CUSTOM_INFOTABLE_PATCHES_MATRIX_NAME</ID>
		<Value>
		<xsl:call-template name="GetEnvironmentValue">
		<xsl:with-param name="LookUpItem" select="'CUSTOM_INFOTABLE_PATCHES_MATRIX_NAME'"/>
		</xsl:call-template>
		</Value>
</Item>

   </PST_Library>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>