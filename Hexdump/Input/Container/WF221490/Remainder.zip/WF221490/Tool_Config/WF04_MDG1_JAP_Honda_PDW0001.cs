using System;
using System.Linq;
using System.Xml.Linq;
using System.Windows.Forms;
namespace PDT_LT
{
    public class USER_DEFINED_FUNC
    {
        public XElement Main(XDocument Param)
        {
            XElement Result = null;
            try
            {
                Result = new XElement("Fields", new XAttribute("Group", "User_Defined_Functions"), new XAttribute("Disclaimer", "Data under this section is not validated"));
			
				string Bootcontainer = GetElementValue(Param, "ReleaseScope");
				string BootContainerFlag = String.Empty;
				if (Bootcontainer == "Boot software")
				{
					BootContainerFlag = "1";
				}	
				else
				{
					BootContainerFlag = "0";
				}	
				//Only if ReleaseScope='Boot software' Bootcontainer will be generated. Elase BootContainerFlag set to 0.
				Result.Add(ConstructElement("String", "BootContainerFlag", "BootContainerFlag derived based on ReleaseScope", BootContainerFlag));
            }
            catch (Exception ex)
            {
                Result.Add(new XElement("Error", new XElement("Exception",ex)));
            }
            return Result;
        }
        private string GetElementValue(XDocument Param,string Name)
        {
            return Param.Root.Descendants("Field").FirstOrDefault(n => n.Attribute("Name").Value == Name).Value;
        }
        private XElement ConstructElement(string Type, string Name, string Description, string Value)
        {
            return new XElement("Field", new XAttribute("Type", Type), new XAttribute("Name", Name), new XAttribute("Description", Description), Value);
        }
    }
}