START /WAIT "TC_SRL" "C:\toolbase\pdt_toolchain\1v68\ToolChain.exe"  -S "|C:\temp\PDT\JAP\MDG1\MDG1_JAP_Honda_PDW0002\D2P\Honda\MG1CS022\WF218078\P_Run_TC_Exec_FSW.xml|"

