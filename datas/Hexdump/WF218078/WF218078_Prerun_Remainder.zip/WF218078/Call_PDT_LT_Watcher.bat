echo off
cls
rem Start-Batch for PDT_LT_Watcher tool
rem all Parameter are required

set WorkingDirectory=C:\temp\PDT\JAP\MDG1\Prerun_Toolchain\PreRun\MG1CS022\WF218078
set WatcherToolPath=C:\temp\PDT\JAP\MDG1\Prerun_Toolchain\PreRun\MG1CS022\WF218078\Tool_Config\Tools\PDT_LT_Watcher
set Jobnumber=WF218078

rem don't change the parameters here !
set driveLetter=%WorkingDirectory:~0,2%
%driveLetter%

cd %WatcherToolPath%

echo Running PDT_LT_Watcher to check for any errors or success

START "" PDT_LT_Watcher.exe %Jobnumber% %WorkingDirectory%
