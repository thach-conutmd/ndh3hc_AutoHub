 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>
  
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" />

    <xsl:template match="/">
    <ToolInput>
    <Mode>Derive Machine Type and HSM flag for SecuMgr</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Default HSM Flag Value</DefaultValueMessage>
     	<ConfigFile>
			<Name><xsl:call-template name="file_from_pathfile">
				<xsl:with-param name="pathfile">
				<xsl:call-template name="GetSecuMgr_HSM_Matrix_Path"></xsl:call-template>
				</xsl:with-param>					
			</xsl:call-template>	</Name>
				
			<Directory><xsl:call-template name="path_from_pathfile">
				<xsl:with-param name="pathfile">
				<xsl:call-template name="GetSecuMgr_HSM_Matrix_Path"></xsl:call-template>
			</xsl:with-param>					
			</xsl:call-template></Directory>			
			
		</ConfigFile>	
		<Variables>			
			<Variable>
					<Name>Machine_Type</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'CFGEXP_MACHINE_TYPE'"/>
						</xsl:call-template>
					</Value>
			</Variable>		
		</Variables> 
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
