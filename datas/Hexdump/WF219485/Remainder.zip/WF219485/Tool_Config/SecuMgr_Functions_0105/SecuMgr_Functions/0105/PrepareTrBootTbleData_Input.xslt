 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolInput>
		<Mode>Preparing Trusted Boot Table Data for Container</Mode>
		<Files>
			<IsRequiredTrBootTableData>true</IsRequiredTrBootTableData>
			<ConfigFile>
				<Directory>
						<xsl:call-template name="FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:call-template name="FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Name>
			</ConfigFile>
			<BootTablefile>
				<Directory><xsl:call-template name="path_from_pathfile">
				<xsl:with-param name="pathfile">
				<xsl:call-template name="GetTrustedBoot_ConfigPath"></xsl:call-template>
			</xsl:with-param>					
			</xsl:call-template>
			</Directory>
				<Name><xsl:call-template name="file_from_pathfile">
				<xsl:with-param name="pathfile">
				<xsl:call-template name="GetTrustedBoot_ConfigPath"></xsl:call-template>
				</xsl:with-param>					
			</xsl:call-template></Name>
			</BootTablefile>
			<LogFile>
				<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
				<Name><xsl:value-of select="'PrepareBootData.log'"/></Name>
			</LogFile>
		</Files>
		<ModeType><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></ModeType>
		<DataLength><![CDATA[16]]></DataLength>
		<Address_Offset><![CDATA[0000]]></Address_Offset>
		<FileEndFormat><![CDATA[:00000001FF]]></FileEndFormat>
		<FileStartFormat><![CDATA[:020000040000FA]]></FileStartFormat>
		<HexModFilePath> <xsl:call-template name="GetTool_DirectoryPath">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="GetTool_Name">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
		</HexModFilePath>
		 <CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation></ToolLocation>
			<InputVerification></InputVerification>
		 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
