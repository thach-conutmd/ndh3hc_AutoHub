 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" />                                               
<xsl:variable name="HSMADDRESSFILE"  select="concat($PCurrentXSLTDir,'/','FLASH0_HSM_Address_SecuMgr.xml')" />  

   <xsl:template match="/">
    <ToolInput>
    <Mode>Hexmodx Create Flash0 Hex file </Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>	
			<Module>OutputXML</Module>
		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script>					
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_MAIN_XML'"/>
					</xsl:call-template>
					
				</Script>
     		<Variables>
  				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_CreateFlash0_LOG_'"/>
					<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>		  
			</Variables>
     	</MainXML>
     	
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_FLASH0_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod_FDB_CRC_Patched_Hex'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod_FDB_CRC_Patched_Hex'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
      			<Variable>
					<Name>FILETYPE</Name>
					<Type>Simple</Type>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template>					
					</Value>
				</Variable>
				<Variable>
					<Name>FLASH0_COPY_RANGE_SECUMGR</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'FLASH0_COPY_RANGE_SECUMGR'"/>
						</xsl:call-template>
					</Value>
				</Variable>
    		</Variables>
		</InputXML>
		
     <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_FLASH0_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:value-of select="'SECUMGR_Flash0.hex'"/>
					</Value>
				</Variable> 
				
				<Variable>
					<Name>START_ADDRESS</Name>
					<Value>
						<xsl:call-template name="GetFLASH0_STARTADDRESS">						
							<xsl:with-param name="File">						 
								<xsl:value-of select="$HSMADDRESSFILE"/>						
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>FLASH0_LENGTH</Name>
					<Value>
						<xsl:call-template name="GetFLASH0_LENGTH">						
							<xsl:with-param name="File">						 
								<xsl:value-of select="$HSMADDRESSFILE"/>						
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
     		</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'\HEXMODX_CreateFlash0_LOG_'"/>
					<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Name>
			</File>
		</Files>
	</LogFileAnalyser>
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType/>
		<ToolVersion/>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
		</ToolLocation>
		<InputVerification/>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
