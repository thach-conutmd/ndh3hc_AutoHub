<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 
 <xsl:variable name="RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_CBLITE_COMPILED_ADDRESS_START']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_CBLITE_IN_REPROGCONTAINER_START']/tctypes:Value"/>

<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_START" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_NEW_SECUMGR_SOURCE_START']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_END" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_NEW_SECUMGR_SOURCE_END']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START']/tctypes:Value"/>

<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4']/tctypes:Value"/>

<xsl:variable name="RT_HSM_PIB_ADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_PIB_ADDRESS']/tctypes:Value"/>
<xsl:variable name="RT_HSM_PIB_LENGTH" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_PIB_LENGTH']/tctypes:Value"/>

<xsl:variable name="RT_HSM_FDB_START" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_FDB_START']/tctypes:Value"/>
<xsl:variable name="RT_HSM_FDB_OFFSET" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_FDB_OFFSET']/tctypes:Value"/> 

<xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_MACHINE_TYPE']/tctypes:Value"/> 

<xsl:variable name="RT_TB_HANDLING_DATA" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='TB_HANDLING_DATA']/tctypes:Value"/> 


<xsl:variable name="RT_HSM_BLOCK_LEN_TO_HASH" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_BLOCK_LEN_TO_HASH']/tctypes:Value"/> 
<xsl:variable name="RT_HSM_BLOCK_CERTIFICATE_ADR" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_BLOCK_CERTIFICATE_ADR']/tctypes:Value"/> 
<xsl:variable name="RT_HSM_BLOCK_SIGNATURE_ADR" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='HSM_BLOCK_SIGNATURE_ADR']/tctypes:Value"/> 



</xsl:stylesheet>