 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" indent="yes"
	cdata-section-elements="Key SearchExpression"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
	<xsl:template match="/">
		<ToolInput>
			<Mode>Create she Paraset File</Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime>	<!-- 10 Minutes-->
				<DateTimeInterval>1</DateTimeInterval>	<!-- 1 = Minutes  / 0 = Seconds-->	
				
				<DATA_TYPE>
					<xsl:value-of select="'SHE'"/>
				</DATA_TYPE>
				
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				
				<Files>				

					<Merged_Corecfg_File>
						<Directory>
							<xsl:call-template name="FileList_GetFileDirectory"> 
									<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
									<xsl:with-param name="GetValue" select="'yes'" /> 
							</xsl:call-template>
						</Directory>	
						<Name>
							<xsl:call-template name="FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
								<xsl:with-param name="GetValue" select="'yes'" />
							</xsl:call-template> 						
						</Name>								
					</Merged_Corecfg_File>	
					
					<Valid_Template_File>		
						<Directory>
							<xsl:call-template name="path_from_pathfile">
								<xsl:with-param name="pathfile">
								<xsl:call-template name="GetFSWKeys_Config_Template"></xsl:call-template>
							</xsl:with-param>					
							</xsl:call-template></Directory>
						<Name>
							<xsl:call-template name="file_from_pathfile">
								<xsl:with-param name="pathfile">
								<xsl:call-template name="GetFSWKeys_Config_Template"></xsl:call-template>
									</xsl:with-param>					
							</xsl:call-template>					
						</Name>
					</Valid_Template_File>
					
					<Paraset_ConfigFile>
						<Directory>
							<xsl:call-template name="FileList_GetFileDirectory" >
								 <xsl:with-param name="FileClassID" select="'FSW_SHEKEY_CONFIG'"/>
								 <xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template> 
						</Directory>	
						<Name>
							<xsl:call-template name="FileList_GetFileName" >
									<xsl:with-param name="FileClassID" select="'FSW_SHEKEY_CONFIG'"/>
									<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>
						</Name>									
					</Paraset_ConfigFile>

					<Log_File>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name>
							<xsl:value-of select="'Paraset.log'"/>
						</Name>
					</Log_File>

				</Files>
				
				<ReadVaraibeList>
					<Variables>
						<Variable>
						<ID></ID> 
						<Xpath></Xpath> 
						</Variable>
					 </Variables>
				</ReadVaraibeList>		

				<LogFileAnalyser>
					<Files>
					</Files>
				</LogFileAnalyser>	
				
			</Input>      
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>
