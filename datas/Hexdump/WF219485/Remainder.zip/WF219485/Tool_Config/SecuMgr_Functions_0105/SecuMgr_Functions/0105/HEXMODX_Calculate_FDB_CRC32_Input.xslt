<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" /> 
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>HexModX - Calculate FDB CRC32 Checksums</Mode>
			<HexModeInput>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				<Modules>
					<Module>MainXML</Module>
					<Module>InputXML</Module>
					<Module>ChecksumXML</Module>				
					<Module>OutputXML</Module>						
				</Modules>
				<!-- Main - Config -->
				<MainXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'HexMod_Main_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.XML'" /></Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_MAIN_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>HEXMOD_MAIN_LOGFILE</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_CRC32_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMOD_INPUT_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_INPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMOD_CHECKSUM_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_CHECKSUM_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMOD_OUTPUT_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HexMod_Output_FDBCRC_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" />
							</Value>
						</Variable>
					</Variables>
				</MainXML>
				<!-- Input Config-->
				<InputXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'HEXMOD_INPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.XML'" /></Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_INPUT_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>HEXFILE</Name>
							<Value>
								<xsl:call-template name="RunTime_FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'HexMod_HSM_CRC_Patched_Hex'" />
										<xsl:with-param name="GetValue" select="'yes'" />
									</xsl:call-template>
									<xsl:value-of select="'\'" />
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'HexMod_HSM_CRC_Patched_Hex'" />
										<xsl:with-param name="GetValue" select="'yes'" />
									</xsl:call-template>								
							</Value>
						</Variable>
						<Variable>
							<Name>FILETYPE</Name>
							<Type>Simple</Type>
							<Value>
								<xsl:call-template name="GetEnvironmentValue">
									<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'" />
								</xsl:call-template>
							</Value>
						</Variable>
						<Variable>
							<Name>MODETYPE</Name>						
							<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
						</Variable>
					</Variables>
				</InputXML>
				
				<!-- ChecksumXML Config-->
				<ChecksumXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'HEXMOD_CHECKSUM_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.XML'" /></Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_CALC_CRC32_CHKSUM_CHECKSUM_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>OUTPUT_FILE</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Calc_FDB_Checksum.txt'" />
							</Value>
						</Variable>
						<Variable>
							<Name>STARTADDR</Name>
							<Value>
								<xsl:call-template name="Get_GUAM_HSM_START_FDBCRC">
									<xsl:with-param name="HSMInfoFile">
										<xsl:call-template name="GetWorkingDirectory">
										</xsl:call-template>
										<xsl:value-of select="'/HSM_INFO_File.XML'"/>
									</xsl:with-param>
								</xsl:call-template>								
							</Value>
						</Variable>
						<Variable>
							<Name>LENGTH</Name>
							<Value>
								<xsl:call-template name="Get_GUAM_HSM_LENGTH_FDBCRC">
									<xsl:with-param name="HSMInfoFile">
										<xsl:call-template name="GetWorkingDirectory">
										</xsl:call-template>
										<xsl:value-of select="'/HSM_INFO_File.XML'"/>
									</xsl:with-param>
								</xsl:call-template>							
							</Value>
						</Variable>					
						<Variable>
							<Name>PATCH_ADDRESS</Name>
							<Value>
								<xsl:call-template name="Get_GUAM_FDB_CRC_PATCH_ADDRESS">
									<xsl:with-param name="HSMInfoFile">
										<xsl:call-template name="GetWorkingDirectory">
										</xsl:call-template>
										<xsl:value-of select="'/HSM_INFO_File.XML'"/>
									</xsl:with-param>
								</xsl:call-template>							
							</Value>
						</Variable>
					</Variables>
				</ChecksumXML>
				<!-- Output Config-->
     	<OutputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Output_FDBCRC_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_PATCH_CRC_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="GetSoftwareName">
								</xsl:call-template><xsl:value-of select="'_FDBCRC_Patched.hex'"/></Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
 			</Variables>     		   	
		</OutputXML>
				<LogFileAnalyser>
					<Files>
						<File>
							<Classification>Hexmod17-Main-Logfile</Classification>
							<Key>HEXMOD17_MAIN</Key>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							</Directory>
							<Name>
								<xsl:value-of select="'HEXMOD_CRC32_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.LOG'" />
							</Name>
						</File>
					</Files>
				</LogFileAnalyser>
				<PST_Library></PST_Library>
			</HexModeInput>
			<CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
