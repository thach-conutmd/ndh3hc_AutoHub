<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:variable name="CALID_Template_Flag" select="/tctypes:UseCase/tctypes:Data/tctypes:CALID_Template_Flag" />
	
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
					<TB_HANDLING_Flag>
								
							<xsl:call-template name="DeriveTBHanlingFlag" >										
										<xsl:with-param name="input_text">
											<xsl:call-template name="RunTime_Data_Value">
												<xsl:with-param name="DataClassID" select="'TB_HANDLING_DATA'" />
											</xsl:call-template>
										</xsl:with-param>
							</xsl:call-template>
						
					</TB_HANDLING_Flag>

					<HSM_SIGNING_Flag>
								
							<xsl:call-template name="Derive_HSMFSigningFlag" >										
										<xsl:with-param name="input_text1">
											<xsl:call-template name="RunTime_Data_Value">
												<xsl:with-param name="DataClassID" select="'HSM_BLOCK_LEN_TO_HASH'" />
											</xsl:call-template>
										</xsl:with-param>
										<xsl:with-param name="input_text2">
											<xsl:call-template name="RunTime_Data_Value">
												<xsl:with-param name="DataClassID" select="'HSM_BLOCK_CERTIFICATE_ADR'" />
											</xsl:call-template>
										</xsl:with-param>
										<xsl:with-param name="input_text3">
											<xsl:call-template name="RunTime_Data_Value">
												<xsl:with-param name="DataClassID" select="'HSM_BLOCK_SIGNATURE_ADR'" />
											</xsl:call-template>
										</xsl:with-param>
							</xsl:call-template>
						
					</HSM_SIGNING_Flag>
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
