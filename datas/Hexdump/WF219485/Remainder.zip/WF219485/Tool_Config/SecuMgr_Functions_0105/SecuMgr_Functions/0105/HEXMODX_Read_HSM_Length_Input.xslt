 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="GUAMINFO_FILE"  select="concat($WorkingDir, '\GUAMINFO.xml')" />
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" /> 
<xsl:template match="/">

    <ToolInput>
    <Mode>HexModX - Read Version for FDB </Mode>
    <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>PatchCheckXML</Module>					
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Read_Version_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_VERSION_MAIN_XML'"/></xsl:call-template></Script>
     		<Variables>
 				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_VERSION_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_VERSION_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>			   
			    <Variable>
					<Name>HEXMODX_PATCHCHECK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_HSM_LENGTH_PATCHCHECK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>							
			</Variables>
       	</MainXML>
     		
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_READ_VERSION_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_VERSION_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CompleteHex_HSM_Signed'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>
							<xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CompleteHex_HSM_Signed'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template></Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>				
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
 			</Variables>     		   	
		</InputXML>
		
		<!-- PatchCheck - Config -->
     	<PatchCheckXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_READ_HSM_LENGTH_PATCHCHECK_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_HSM_LENGTH_PATCHANDCHECK_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>HSM_LENGTH_ADDR</Name>
					<Value>
						<xsl:call-template name="Get_GUAM_HSM_LENGTH_ADDR">
							<xsl:with-param name="HSMInfoFile">
								<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template>
								<xsl:value-of select="'/HSM_INFO_File.XML'"/>
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>FILETYPE</Name>				
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>			
				<Variable>
					<Name>RESULTXMLFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\HSM_LENGTH_ADDR_Value.xml'"/></Value>
				</Variable>
			</Variables>      			
		</PatchCheckXML>     	
 	<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_READ_VERSION_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
				<File>
					<Classification>Hexmod17-Patch-Logfile</Classification>
					<Key>HEXMOD17_PATCHCHECK_LOGFILE</Key>
					<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
					<Name><xsl:value-of select="'HSM_LENGTH_ADDR_Value.xml'"/></Name>
				</File>
			</Files>
		</LogFileAnalyser>	
		<PST_Library>
		</PST_Library>	
    </HexModeInput>  
  <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
