 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>
<xsl:param name="PInputFileClassID_InputHex_File"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="InputFileClassID_InputHex_File" select="$PInputFileClassID_InputHex_File"/>
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" />  

    <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Create New GUAM Signature Hex file </Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>Tprot</Module>
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main.xml'"/></Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG.LOG'"/></Value>
				</Variable>
  	    <Variable>
					<Name>HEXMODX_TPROT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_Flash0_TPROT.XML'"/></Value>
				</Variable>
          <Variable>
            <Name>TPROT_JAR_FILE_PATH</Name>
            <Value>
              <xsl:value-of select="'mdg1tprot.jar'"/>

            </Value>
          </Variable>
			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
		 <Tprot>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMODX_Flash0_TPROT.XML'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_GUAM_SIGNED_HEXFILE_TPROTCONF_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template>
						
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<!-- Input hexfile -->
				<Name>HEXFILE</Name>
				<Value>					
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="$InputFileClassID_InputHex_File"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="'\'" />
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="$InputFileClassID_InputHex_File"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
				</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<!-- Sign.txt -->
				<Name>SIGNATURE_OUTPUT_FILE</Name>
				<Value>					
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'HexModX_New_GUAM_SignedValues'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'HexModX_New_GUAM_SignedValues'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						<xsl:with-param name="GetExtension" select="'yes'"/>					
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				
				<!-- Output signed hexfile -->
				<Variable>
					<Name>OUTPUT_HEXFILE</Name>
					<Value>				
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:call-template name="GetSoftwareName">
								</xsl:call-template><xsl:value-of select="'_Signed'"/><xsl:value-of select="'.hex'"/>
					</Value>
				</Variable>	
				<Variable>
				<Name>MERGEDCONFIG</Name>
				<Value>
					<xsl:call-template name="FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'ECY_HSM_EXPORT_XML'" />
						<xsl:with-param name="GetValue" select="'yes'" />
					</xsl:call-template>	
					<xsl:value-of select="'\'" />					
					<xsl:call-template name="FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'ECY_HSM_EXPORT_XML'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
				</Value>
				<Mandatory>True</Mandatory>
				</Variable>					
			</Variables>
      	</Tprot>
      	

      	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
        <xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
					</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
