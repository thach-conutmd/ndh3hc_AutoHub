 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
    <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','LIB_SecuMgr.xml')" />                                                 
	<xsl:variable name="HSMADDRESSFILE"  select="concat($PCurrentXSLTDir,'/','FLASH0_HSM_Address_SecuMgr.xml')" />

   <xsl:template match="/">

		<ToolInput>
			<Mode>Script to Prepare Flash0 range for SecuMgr</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"/>
				</WorkingDirectory>
				<Scripts>
					<Script>
						<Write2PSTLib>False</Write2PSTLib>
						<Key>FLASH0_COPY_RANGE_SECUMGR</Key>
						<Comment>Script to Prepare Flash0 range for SecuMgr </Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_FLASH0_COPY_RANGE'"/>
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>		
								<xsl:call-template name="GetXMLFromFile">
												<xsl:with-param  name="File"  select="$HSMADDRESSFILE" />
								</xsl:call-template>
								<WorkingDirectory>
								<xsl:call-template name="GetWorkingDirectory"/>
								</WorkingDirectory>					
							</Datas>				
						</DataBase>
					</Script>
					<Script>
						<Write2PSTLib>False</Write2PSTLib>
						<Key>HSM_CRC_SCRIPT</Key>
						<Comment>Script to Prepare Flash0 range for SecuMgr </Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_CALCULATE_HSM_CRC_TEMPLATE'"/>
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>		
								<xsl:call-template name="GetXMLFromFile">
												<xsl:with-param  name="File"  select="$HSMADDRESSFILE" />
								</xsl:call-template>
								<HSM_CRC_PATCH_ADDRESS>
									<xsl:call-template name="Get_GUAM_HSM_CRC_PATCH_ADDRESS">
									<xsl:with-param name="HSMInfoFile">
										<xsl:call-template name="GetWorkingDirectory">
										</xsl:call-template>
										<xsl:value-of select="'/HSM_INFO_File.XML'"/>
									</xsl:with-param>
								</xsl:call-template>
								</HSM_CRC_PATCH_ADDRESS>
								<WorkingDirectory>
								<xsl:call-template name="GetWorkingDirectory"/>
								</WorkingDirectory>					
							</Datas>				
						</DataBase>
					</Script>
				</Scripts>
				<PST_Library>
				</PST_Library>
			</Input>  
			<CallInformation>
				<ToolName/>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>
