<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">      
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!--
		Main Idea: Walk through the toolchain's data step by step. Copy each node using default-rules.
		Some parts of the toolchain's data can be overwritten without any knowledge about the internal
		structure.
		For each part there exist two variables:
		- The first has to be used by the calling stylesheet. It is prefixed by either "UC" (UseCase)
		  or "RT" (RunTime). It is initialized empty in this basic library. A calling stylesheet can
		  overwrite this initial value.
		- Correspondig to this externally used variable we have an internal reference. It is prefixed 
		  "REF" and contains an XPATH. This XPATH describes the part to be replaced.	
	    On principle it is assumed that in the toolchain's data the part to be overwritten already exists
	    It may be empty but it should exist. Occasionally it could be possible to newly introduce data.
	  
	    The Stylesheet calling this library only has 
		- to provide XPATHs for the variables mentioned abobve to be used for extracting data from the 
		  tool output 
		It is not necessary to call any template. This is done within the library.				
  -->

	<!-- Path to the toolchain's data file                        -->
	<xsl:variable name="UseCaseXML" select="''" />
	<!-- Variables to be used by the calling stylesheet(s)    -->
	<xsl:variable name="RT_HSM_PIB_END" select="''"/>
	<xsl:variable name="RT_CFGEXP_MACHINE_DEV" select="''"/>
	<xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="''"/>
	<xsl:variable name="RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START" select="''"/>
	<xsl:variable name="RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START" select="''"/>
	<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_START" select="''"/>
	<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_SOURCE_END" select="''"/>
	<xsl:variable name="RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START" select="''"/>
	<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1" select="''"/>
	<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2" select="''"/>
	<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3" select="''"/>
	<xsl:variable name="RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4" select="''"/>
	<xsl:variable name="RT_HSM_PIB_ADDRESS" select="''"/>
	<xsl:variable name="RT_HSM_PIB_LENGTH" select="''"/>	
	<xsl:variable name="RT_HSM_FDB_START" select="''"/>
	<xsl:variable name="RT_HSM_FDB_OFFSET" select="''"/>	
	<xsl:variable name="RT_PIB_ENDADDRESS" select="''"/>	
	<xsl:variable name="RT_HexMod_New_GUAM_SignedValues" select="''"/>				
	<xsl:variable name="RT_HexMod_New_GUAM_HashValue" select="''"/>
	<xsl:variable name="RT_New_GUAM_Signed" select="''"/>	
	<xsl:variable name="RT_LASTRUN_FALSH0_HASHOUTPUT" select="''" />	
	<xsl:variable name="RT_TSAppCompat" select="''" />
	<xsl:variable name="RT_SECUMGR_HSM_FLAG" select="''"/>	
	<xsl:variable name="RT_TB_HANDLING_DATA" select="''"/>	
	<xsl:variable name="RT_TB_HANDLING_FLAG" select="''"/>	
	<xsl:variable name="RT_BootTableData_Hex" select="''"/>		
	<xsl:variable name="RT_Trusted_BootTbl_Hex_Size" select="''"/>		
	<xsl:variable name="RT_FLASH0_COPY_RANGE_SECUMGR" select="''"/>	
	<xsl:variable name="RT_Flash0_HEX" select="''"/>	
	<xsl:variable name="RT_HSM_CRC_SCRIPT" select="''"/>		
	<xsl:variable name="RT_SECURDATA_Key_ParaSet_File" select="''"/>
	<xsl:variable name="RT_SHE_Key_ParaSet_File_GUAM" select="''"/>
	<xsl:variable name="RT_AES_Key_ParaSet_File_GUAM" select="''"/>

  <xsl:variable name="RT_MAC_UC_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_MAC_UP_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_RSA_Key_ParaSet_File" select="''"/>
  <xsl:variable name="RT_ECC_Key_ParaSet_File" select="''"/>
  
	<xsl:variable name="RT_HSM_BLOCK_LEN_TO_HASH" select="''"/>			
	<xsl:variable name="RT_HSM_BLOCK_CERTIFICATE_ADR" select="''"/>	
	<xsl:variable name="RT_HSM_BLOCK_SIGNATURE_ADR" select="''"/>		
	<xsl:variable name="RT_HSM_SIGNING_FLAG" select="''"/>	
	
	<xsl:variable name="RT_GUAM_HEX_VERSION" select="''"/>
	<xsl:variable name="RT_UpdateCRC32_FDB" select="''"/>
	<xsl:variable name="RT_HexMod_HSM_CRC_Patched" select="''"/>
	<xsl:variable name="RT_HexMod_FDB_CRC_Patched" select="''"/>
	<xsl:variable name="RT_UpdateCRC32_HSM" select="''"/>	
	<xsl:variable name="RT_RELEASEPST" select="''"/>
   
   

<xsl:variable name="Ref_UpdateCRC32_FDB" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CRC32_FDB']/tctypes:Value"/>
<xsl:variable name="Ref_HexMod_HSM_CRC_Patched" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_HSM_CRC_Patched_Hex']/tctypes:Location"/>
<xsl:variable name="Ref_HexMod_FDB_CRC_Patched" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_FDB_CRC_Patched_Hex']/tctypes:Location"/>
<xsl:variable name="Ref_RELEASEPST" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RELEASEPST']/tctypes:Location"/>
<xsl:variable name="Ref_GUAM_HEX_VERSION" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:GUAM_HEX_VERSION"/>
<xsl:variable name="Ref_UpdateCRC32_HSM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='UpdateCRC32_HSM']/tctypes:Value"/>
<xsl:variable name="Ref_TB_HANDLING_DATA" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TB_HANDLING_DATA']/tctypes:Value"/>
<xsl:variable name="Ref_TB_HANDLING_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:TB_HANDLING_FLAG"/>
<xsl:variable name="Ref_Trusted_BootTbl_Hex_Size" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='Trusted_BootTbl_Hex_Size']/tctypes:Value"/>
<xsl:variable name="Ref_FLASH0_COPY_RANGE_SECUMGR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='FLASH0_COPY_RANGE_SECUMGR']/tctypes:Value"/>
<xsl:variable name="Ref_HSM_CRC_SCRIPT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_CRC_SCRIPT']/tctypes:Value"/>

	<xsl:variable name="Ref_BootTableData_Hex" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Trusted_BootTbl_Hex']/tctypes:Location"/>
	<xsl:variable name="Ref_SECUMGR_HSM_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SECUMGR_HSM_FLAG"/>
	
	<xsl:variable name="Ref_HexMod_New_GUAM_SignedValues" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexModX_New_GUAM_SignedValues']/tctypes:Location"/>
	<xsl:variable name="Ref_New_GUAM_Signed" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='CompleteHex_HSM_Signed']/tctypes:Location"/>
	<xsl:variable name="Ref_HexMod_New_GUAM_HashValue" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='HexMod_New_GUAM_HashValue']/tctypes:Location"/>
	<xsl:variable name="Ref_LASTRUN_FALSH0_HASHOUTPUT" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='LASTRUN_FALSH0_HASHOUTPUT']/tctypes:Location"/>
	<xsl:variable name="Ref_Flash0_HEX" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='Flash0_HEX']/tctypes:Location"/>
	
	<xsl:variable name="Ref_HSM_PIB_END" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_PIB_END']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_PIB_ADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_PIB_ADDRESS']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_PIB_LENGTH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_PIB_LENGTH']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_FDB_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_FDB_START']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_FDB_OFFSET" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_FDB_OFFSET']/tctypes:Value"/>
	<xsl:variable name="Ref_PIB_ENDADDRESS" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PIB_ENDADDRESS']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_CBLITE_COMPILED_ADDRESS_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_CBLITE_COMPILED_ADDRESS_START']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_CBLITE_IN_REPROGCONTAINER_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_CBLITE_IN_REPROGCONTAINER_START']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_SOURCE_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_SOURCE_START']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_SOURCE_END" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_SOURCE_END']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4']/tctypes:Value"/>
	<xsl:variable name="Ref_CFGEXP_MACHINE_DEV" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_MACHINE_DEV']/tctypes:Value"/> 
	<xsl:variable name="Ref_CFGEXP_MACHINE_TYPE" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='CFGEXP_MACHINE_TYPE']/tctypes:Value"/>
	<xsl:variable name="Ref_TSAppCompat" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TSAppCompat']/tctypes:Value" />

  <xsl:variable name="Ref_MAC_UC_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='MAC_UC_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
  <xsl:variable name="Ref_MAC_UP_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='MAC_UP_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
  <xsl:variable name="Ref_RSA_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='RSA_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
  <xsl:variable name="Ref_ECC_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='ECC_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
  
	<xsl:variable name="Ref_SHE_Key_ParaSet_File_GUAM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SHE_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>
	<xsl:variable name="Ref_AES_Key_ParaSet_File_GUAM" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='AES_Key_ParaSet_File']/tctypes:Location"/>
	<xsl:variable name="Ref_SECURDATA_Key_ParaSet_File" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID='SECURDATA_Key_ParaSet_File_SecuMgr']/tctypes:Location"/>	
	<xsl:variable name="Ref_HSM_BLOCK_LEN_TO_HASH" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_BLOCK_LEN_TO_HASH']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_BLOCK_CERTIFICATE_ADR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_BLOCK_CERTIFICATE_ADR']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_BLOCK_SIGNATURE_ADR" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='HSM_BLOCK_SIGNATURE_ADR']/tctypes:Value"/>
	<xsl:variable name="Ref_HSM_SIGNING_FLAG" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:HSM_SIGNING_FLAG"/>
  <!-- Starting point -->
	<xsl:template match="/">
		<xsl:call-template name="WriteBack" />
	</xsl:template>
	<!-- The initial template. Starts processing of the toolcahin's data -->
	<xsl:template name="WriteBack">
		<xsl:apply-templates select="document($UseCaseXML)/*" />
	</xsl:template>
	<!-- recurcively step throug the toolchain's data -->
	<xsl:template match="*">
		<xsl:choose>
			<xsl:when test="count(. | $Ref_RELEASEPST)=1 and $RT_RELEASEPST">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_RELEASEPST/*"/>
				</xsl:element>
			</xsl:when>
			
		<xsl:when test="count(. | $Ref_UpdateCRC32_HSM)=1 and $RT_UpdateCRC32_HSM">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_UpdateCRC32_HSM"/>
		</xsl:element>
	</xsl:when>	
	<xsl:when test="count(. | $Ref_UpdateCRC32_FDB)=1 and $RT_UpdateCRC32_FDB">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_UpdateCRC32_FDB"/>
		</xsl:element>
	</xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_HSM_CRC_Patched)=1 and $RT_HexMod_HSM_CRC_Patched">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_HSM_CRC_Patched/*"/>
        </xsl:element>
      </xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_FDB_CRC_Patched)=1 and $RT_HexMod_FDB_CRC_Patched">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_FDB_CRC_Patched/*"/>
        </xsl:element>
      </xsl:when>
	
	<xsl:when test="count(. | $Ref_GUAM_HEX_VERSION)=1 and $RT_GUAM_HEX_VERSION">
			<xsl:element name="GUAM_HEX_VERSION">
			<xsl:value-of select="$RT_GUAM_HEX_VERSION"/>
		</xsl:element>
	</xsl:when>
	
			<xsl:when test="count(. | $Ref_CFGEXP_MACHINE_DEV)=1 and $RT_CFGEXP_MACHINE_DEV">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_CFGEXP_MACHINE_DEV"/>
				</xsl:element>
			</xsl:when>
			<xsl:when test="count(. | $Ref_CFGEXP_MACHINE_TYPE)=1 and $RT_CFGEXP_MACHINE_TYPE">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_CFGEXP_MACHINE_TYPE"/>
				</xsl:element>
			</xsl:when>			
			
	<xsl:when test="count(. | $Ref_CFGEXP_CBLITE_COMPILED_ADDRESS_START)=1 and $RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_CBLITE_COMPILED_ADDRESS_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_CBLITE_IN_REPROGCONTAINER_START)=1 and $RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_CBLITE_IN_REPROGCONTAINER_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_SOURCE_START)=1 and $RT_CFGEXP_NEW_SECUMGR_SOURCE_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_SOURCE_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_SOURCE_END)=1 and $RT_CFGEXP_NEW_SECUMGR_SOURCE_END">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_SOURCE_END"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START)=1 and $RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3"/>
			</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4)=1 and $RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4"/>
			</xsl:element>
		</xsl:when>	
	    <xsl:when test="count(. | $Ref_HSM_PIB_ADDRESS)=1 and $RT_HSM_PIB_ADDRESS">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_PIB_ADDRESS"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_PIB_LENGTH)=1 and $RT_HSM_PIB_LENGTH">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_PIB_LENGTH"/>
			</xsl:element>
		</xsl:when>
		
		 <xsl:when test="count(. | $Ref_HSM_FDB_START)=1 and $RT_HSM_FDB_START">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_FDB_START"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_FDB_OFFSET)=1 and $RT_HSM_FDB_OFFSET">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_FDB_OFFSET"/>
			</xsl:element>
		</xsl:when>
			<xsl:when test="count(. | $Ref_PIB_ENDADDRESS)=1 and $RT_PIB_ENDADDRESS">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_PIB_ENDADDRESS"/>
			</xsl:element>
		</xsl:when>		
	      <xsl:when test="count(. | $Ref_New_GUAM_Signed)=1 and $RT_New_GUAM_Signed">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_New_GUAM_Signed/*"/>
        </xsl:element>
      </xsl:when>
	<xsl:when test="count(. | $Ref_HexMod_New_GUAM_HashValue)=1 and $RT_HexMod_New_GUAM_HashValue">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_New_GUAM_HashValue/*"/>
        </xsl:element>
      </xsl:when>
	  <xsl:when test="count(. | $Ref_HexMod_New_GUAM_SignedValues)=1 and $RT_HexMod_New_GUAM_SignedValues">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_HexMod_New_GUAM_SignedValues/*"/>
        </xsl:element>
      </xsl:when>		
		<xsl:when test="count(. | $Ref_LASTRUN_FALSH0_HASHOUTPUT)=1 and $RT_LASTRUN_FALSH0_HASHOUTPUT">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_LASTRUN_FALSH0_HASHOUTPUT/*"/>
				</xsl:element>
		</xsl:when>
		<xsl:when test="count(. | $Ref_TSAppCompat)=1 and $RT_TSAppCompat">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_TSAppCompat" />
				</xsl:element>
			</xsl:when>					
		<xsl:when test="count(. | $Ref_SECUMGR_HSM_FLAG)=1 and $RT_SECUMGR_HSM_FLAG">
			<xsl:element name="SECUMGR_HSM_FLAG">
			<xsl:value-of select="$RT_SECUMGR_HSM_FLAG"/>
		</xsl:element>
		</xsl:when>	
			<xsl:when test="count(. | $Ref_TB_HANDLING_DATA)=1 and $RT_TB_HANDLING_DATA">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_TB_HANDLING_DATA"/>
				</xsl:element>
			</xsl:when>						
		<xsl:when test="count(. | $Ref_TB_HANDLING_FLAG)=1 and $RT_TB_HANDLING_FLAG">
			<xsl:element name="TB_HANDLING_FLAG">
			<xsl:value-of select="$RT_TB_HANDLING_FLAG"/>
		</xsl:element>
		</xsl:when>	
		
	  <xsl:when test="count(. | $Ref_BootTableData_Hex)=1 and $RT_BootTableData_Hex">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_BootTableData_Hex/*"/>
        </xsl:element>
      </xsl:when>
			<xsl:when test="count(. | $Ref_Trusted_BootTbl_Hex_Size)=1 and $RT_Trusted_BootTbl_Hex_Size">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_Trusted_BootTbl_Hex_Size"/>
				</xsl:element>
			</xsl:when>	
			<xsl:when test="count(. | $Ref_FLASH0_COPY_RANGE_SECUMGR)=1 and $RT_FLASH0_COPY_RANGE_SECUMGR">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_FLASH0_COPY_RANGE_SECUMGR"/>
				</xsl:element>
			</xsl:when>	
	  <xsl:when test="count(. | $Ref_Flash0_HEX)=1 and $RT_Flash0_HEX">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_Flash0_HEX/*"/>
        </xsl:element>
      </xsl:when>	
			<xsl:when test="count(. | $Ref_HSM_CRC_SCRIPT)=1 and $RT_HSM_CRC_SCRIPT">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_HSM_CRC_SCRIPT"/>
				</xsl:element>
			</xsl:when>		
			<xsl:when test="count(. | $Ref_SECURDATA_Key_ParaSet_File)=1 and $RT_SECURDATA_Key_ParaSet_File">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_SECURDATA_Key_ParaSet_File/*"/>
				</xsl:element>
			</xsl:when>	
			
			<xsl:when test="count(. | $Ref_SHE_Key_ParaSet_File_GUAM)=1 and $RT_SHE_Key_ParaSet_File_GUAM">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_SHE_Key_ParaSet_File_GUAM/*"/>
				</xsl:element>
			</xsl:when>
			
			<xsl:when test="count(. | $Ref_AES_Key_ParaSet_File_GUAM)=1 and $RT_AES_Key_ParaSet_File_GUAM">
				<xsl:element name="Location">
					<xsl:copy-of select="$RT_AES_Key_ParaSet_File_GUAM/*"/>
				</xsl:element>
			</xsl:when>

      <xsl:when test="count(. | $Ref_MAC_UC_ParaSet_File)=1 and $RT_MAC_UC_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_MAC_UC_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_MAC_UP_ParaSet_File)=1 and $RT_MAC_UP_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_MAC_UP_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_RSA_Key_ParaSet_File)=1 and $RT_RSA_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_RSA_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>

      <xsl:when test="count(. | $Ref_ECC_Key_ParaSet_File)=1 and $RT_ECC_Key_ParaSet_File">
        <xsl:element name="Location">
          <xsl:copy-of select="$RT_ECC_Key_ParaSet_File/*"/>
        </xsl:element>
      </xsl:when>
      
	    <xsl:when test="count(. | $Ref_HSM_PIB_END)=1 and $RT_HSM_PIB_END">
			<xsl:element name="Value">
				<xsl:value-of select="$RT_HSM_PIB_END"/>
			</xsl:element>
		</xsl:when>	
		<xsl:when test="count(. | $Ref_HSM_BLOCK_LEN_TO_HASH)=1 and $RT_HSM_BLOCK_LEN_TO_HASH">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_HSM_BLOCK_LEN_TO_HASH"/>
				</xsl:element>
			</xsl:when>	
			<xsl:when test="count(. | $Ref_HSM_BLOCK_CERTIFICATE_ADR)=1 and $RT_HSM_BLOCK_CERTIFICATE_ADR">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_HSM_BLOCK_CERTIFICATE_ADR"/>
				</xsl:element>
			</xsl:when>	
			<xsl:when test="count(. | $Ref_HSM_BLOCK_SIGNATURE_ADR)=1 and $RT_HSM_BLOCK_SIGNATURE_ADR">
				<xsl:element name="Value">
					<xsl:value-of select="$RT_HSM_BLOCK_SIGNATURE_ADR"/>
				</xsl:element>
			</xsl:when>	
			
		<xsl:when test="count(. | $Ref_HSM_SIGNING_FLAG)=1 and $RT_HSM_SIGNING_FLAG">
			<xsl:element name="HSM_SIGNING_FLAG">
			<xsl:value-of select="$RT_HSM_SIGNING_FLAG"/>
		</xsl:element>
		</xsl:when>	
			<xsl:otherwise>
				<xsl:element name="{name()}">
					<xsl:apply-templates select="@*" />
					<xsl:apply-templates />
				</xsl:element>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>       
	<xsl:template match="@*">
		<xsl:choose>
			<xsl:when test="false"/>
			<xsl:otherwise>
				<xsl:attribute name="{name()}">
					<xsl:value-of select="." />
				</xsl:attribute>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
