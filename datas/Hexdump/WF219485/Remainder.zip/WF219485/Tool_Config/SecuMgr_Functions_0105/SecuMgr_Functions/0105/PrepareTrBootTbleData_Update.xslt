<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt" />
	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML" />
	<xsl:output method="xml" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />

  <xsl:variable name="RT_BootTableData_Hex" select="tctypes:ToolOutput/tctypes:ResultingFile/tctypes:File[child::tctypes:FileClassID='BootTableData_Hex']/tctypes:Location"/>
 
  <xsl:variable name="RT_Trusted_BootTbl_Hex_Size" select="tctypes:ToolOutput/tctypes:TRUSTED_BOOTTABLE_SIZE[child::tctypes:Name='BOOT_TABLE_SIZE_SECUMGR']/tctypes:Value" />
 
 </xsl:stylesheet>