<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainEnvironmentExtraction.xslt" />
  <xsl:variable name="UseCaseXML" select="''"/>
  <xsl:output method="xml" omit-xml-declaration='yes'
  cdata-section-elements="Key SearchExpression"/>
  <xsl:preserve-space elements="*"/>

  <xsl:template name="GetAESTemplateFile_ConfigPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AESKey_Block_Config"/>
  </xsl:template>

  <xsl:template name="GetBuildMode">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:BuildMode"/>
  </xsl:template>

  <xsl:template name="GetFlagSerialNoDatePatch">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SerialNoDatePatch"/>
  </xsl:template>

  <xsl:template name="GetFlagDynPatchBMWLogistics">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:DynPatchBMWLogistics"/>
  </xsl:template>

  <xsl:template name="GetCMBTYP_SY">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CMBTYP_SY"/>
  </xsl:template>

  <xsl:template name="GetWF_ECUGeneration">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WF_ECUGeneration"/>
  </xsl:template>

  <xsl:template name="GetCurrentToolrun">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Current_Toolrun"/>
  </xsl:template>

  <xsl:template name="GetPDConfigRoot">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PD_Config"/>
  </xsl:template>

  <xsl:template name="GetPDT_ToolRoot">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PDT_ToolRoot"/>
  </xsl:template>

  <xsl:template name="GetFGE_CheckToolPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FGE_CheckToolPath"/>
  </xsl:template>
  <xsl:template name="GetFGE_CheckToolName">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FGE_CheckToolName"/>
  </xsl:template>

  <xsl:template name="RunTime_Data_Value_Node" >
    <xsl:param name="DataClassID" />
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value/tctypes:Value"/>
  </xsl:template>

  <xsl:template name="GetSignedParameter">
    <xsl:param name="FlashSignedFlag"/>
    <xsl:param name="HSMSignedFlag"/>
    <xsl:value-of select="concat($FlashSignedFlag,$HSMSignedFlag)"/>
  </xsl:template>

  <xsl:template name="GetHardwarePartNumber">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HardwarePartNumber"/>
  </xsl:template>
  <xsl:template name="GetToolRootPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ToolRootPath"/>
  </xsl:template>

  <xsl:template name="GetFEE_Block_ConfigPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FEE_Block_Config"/>
  </xsl:template>

  <xsl:template name="GetSignFlagValue">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Sign_Flag"/>
  </xsl:template>

  <xsl:template name="GetProgramFilesDirectory">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ProgramFilesDirectory "/>
  </xsl:template>

  <xsl:template name="GetECUDesignation">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECUType"/>
  </xsl:template>


  <xsl:template name="GetSoftwareName">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SoftwareName"/>
  </xsl:template>

  <xsl:template name="GetReleaseScope">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ReleaseScope"/>
  </xsl:template>

  <xsl:template name="GetWorkingDirectory">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory"/>
  </xsl:template>


  <xsl:template name="GetSoftwarePartNumber">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SoftwarePartNumber"/>
  </xsl:template>

  <xsl:template name="GetWorkFlowID">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkFlowID"/>
  </xsl:template>

  <xsl:template name="GetFSWID">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FSWID"/>
  </xsl:template>

  <xsl:template name="GetFlashLevel">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Flash_Level"/>
  </xsl:template>

  <xsl:template name="GetHSMLevel">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HSM_Level"/>
  </xsl:template>

  <xsl:template name="GetHSMAddFeature">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HSM_AddFeature"/>
  </xsl:template>

  <xsl:template name="GetHSM_STARTADDRESS">
    <xsl:param name="BlockName"/>
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/ADDRESSMODEL/SOURCE[@ID='ECU_DATA']/ADRESS_RANGES/ADRESS_RANGE[@ID=$BlockName]/TARGET-ADDRESS/START"/>

  </xsl:template>

  <xsl:template name="GetHSM_ENDADDRESS">
    <xsl:param name="BlockName"/>
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/ADDRESSMODEL/SOURCE[@ID='ECU_DATA']/ADRESS_RANGES/ADRESS_RANGE[@ID=$BlockName]/TARGET-ADDRESS/END"/>

  </xsl:template>

  <xsl:template name="GetDebugLevel">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Debug_Level"/>
  </xsl:template>

  <xsl:template name="GetWrapperPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WrapperPath "/>
  </xsl:template>

  <xsl:template name="GetPDTools">
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:PD_TOOLNAMES" />
  </xsl:template>
  <xsl:template name="GetRunMode">
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:RUN_MODE" />
  </xsl:template>

  <xsl:template name="RunTime_Tool_Path">
    <xsl:param name="ToolName" />
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/*" />
  </xsl:template>

  <xsl:template name="GetTool_DirectoryPath">
    <xsl:param name="ToolName" />
    <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/tctypes:Directory" />
  </xsl:template>

  <xsl:template name="GetTool_Name">
    <xsl:param name="ToolName" />
    <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/tctypes:Name" />
  </xsl:template>

  <xsl:template name="GetOID">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/DATA/CERTIFICATEKEYSINFORMATION/MEMLAY/OID"/>
  </xsl:template>

  <xsl:template name="GetKEYPATH">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/DATA/CERTIFICATEKEYSINFORMATION/MEMLAY/KEYPATH"/>
  </xsl:template>

  <xsl:template name="GetOIDPUB">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/DATA/CERTIFICATEKEYSINFORMATION/MEMLAY/OID_PUB"/>
  </xsl:template>

  <!-- templates required in batch file mode -->
  <xsl:template name="path_from_pathfile">
    <xsl:param name="pathfile"/>
    <xsl:choose>
      <xsl:when test="contains($pathfile,'\')">
        <xsl:value-of select="substring-before($pathfile,'\')" />
        <xsl:text>\</xsl:text>
        <xsl:call-template name="path_from_pathfile">
          <xsl:with-param name="pathfile" select="substring-after($pathfile,'\')" />
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise />
    </xsl:choose>
  </xsl:template>

  <xsl:template name="file_from_pathfile">
    <xsl:param name="pathfile"/>
    <xsl:choose>
      <xsl:when test="contains($pathfile,'\')">
        <xsl:call-template name="file_from_pathfile">
          <xsl:with-param name="pathfile" select="substring-after($pathfile,'\')" />
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$pathfile"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Extraktionen auf Filelisten-->
  <xsl:template name="FileList_GetFileDirectory">
    <xsl:param name="FileClassID"/>
    <xsl:param name="GetValue" select="'yes'"/>

    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <!--  <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/> -->
        <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
        <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/> -->
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="FileList_GetFileName">
    <xsl:param name="FileClassID"/>
    <xsl:param name="GetValue" select="'yes'"/>
    <xsl:param name="GetExtension" select="'yes'"/>
    <!--
        <xsl:variable name="File" select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/> -->
    <xsl:variable name="File" select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <xsl:choose>
          <xsl:when test="$GetExtension='yes'">
            <xsl:value-of select="$File"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="substring($File, 1, string-length($File) - 4)"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:otherwise>
        <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>-->
        <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="GetAddressLayoutModel">
    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel"/>
  </xsl:template>



  <!-- Extraction of AddressLayout model info -->
  <xsl:template name="FillRanges_GetStartAddress">
    <xsl:param name="FillRangeName"/>
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:Fillranges/tctypes:Fillrange[@Name=$FillRangeName]/tctypes:StartAddress"/>
  </xsl:template>

  <xsl:template name="FillRanges_GetEndAddress">
    <xsl:param name="FillRangeName"/>
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:Fillranges/tctypes:Fillrange[@Name=$FillRangeName]/tctypes:EndAddress"/>
  </xsl:template>

  <xsl:template name="FillRanges_GetFillByte">
    <xsl:param name="FillRangeName"/>
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:Fillranges/tctypes:Fillrange[@Name=$FillRangeName]/tctypes:FillByte"/>
  </xsl:template>

  <xsl:template name="FillRanges_GetLength">
    <xsl:param name="FillRangeName"/>
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:Fillranges/tctypes:Fillrange[@Name=$FillRangeName]/tctypes:Length"/>
  </xsl:template>

  <xsl:template name="FillRanges_GetFillByteLayout">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:FillGapByte"/>
  </xsl:template>

  <xsl:template name="GetRAWVersion">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:RAWVersion"/>
  </xsl:template>

  <xsl:template name="GetMCSVersion">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:MCSVersion"/>
  </xsl:template>

  <xsl:template name="GetECUType">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECU_TYPE"/>
  </xsl:template>

  <xsl:template name="GetRAWMCSFilePath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FSW_ConfigPath"/>
  </xsl:template>

  <xsl:template name="GetVarilableListVersion">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VarilableListVersion"/>
  </xsl:template>


  <xsl:template name="GetRPSData">
    <xsl:param name="GetValue" select="'yes'"/>
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:RPS"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges/tctypes:RPS"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <!-- Extraction Runtime-Range	-->
  <!-- FileLists -->
  <!-- Extraktionen auf Filelisten-->
  <xsl:template name="RunTime_FileList_GetFileDirectory">
    <xsl:param name="FileClassID"/>
    <xsl:param name="GetValue" select="'yes'"/>
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <!-- <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>-->
        <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
      </xsl:when>
      <xsl:otherwise>
        <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>-->
        <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="RunTime_FileList_GetFileName">
    <xsl:param name="FileClassID"/>
    <xsl:param name="GetValue" select="'yes'"/>
    <xsl:param name="GetExtension" select="'yes'"/>
    <!-- <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>        -->
    <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <xsl:choose>
          <xsl:when test="$GetExtension='yes'">
            <xsl:value-of select="$File_Runtime"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="substring($File_Runtime, 1, string-length($File_Runtime) - 4)"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:otherwise>
        <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>  -->
        <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="RunTime_Data_Value" >
    <xsl:param name="DataClassID" />
    <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value"/>
  </xsl:template>

  <xsl:template name="GetXMLFile">
    <xsl:param name="File" />
    <xsl:apply-templates mode="myCopy" select="document($File)/*"/>
  </xsl:template>

  <xsl:template name="GetXMLFromFile">
    <xsl:param name="File" />
    <xsl:copy-of select="document($File)/*"/>
  </xsl:template>

  <xsl:template name="GetCustomerGroup">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerGroup"/>
  </xsl:template>

  <xsl:template name="GetCustomerCodeNumber">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerCodeNumber"/>
  </xsl:template>

  <xsl:template name="GetECUGeneration">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECU_Generation"/>
  </xsl:template>

  <xsl:template name="GetABMBLOCKS">
    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:ABMBlocks/*"/>
  </xsl:template>

  <xsl:template name="ConvertToUpperCase">
    <xsl:param name="string" />
    <xsl:value-of select="translate($string, 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
  </xsl:template>

  <xsl:template name="CheckJDPOrInfineon">
    <xsl:param name="ModeType" />
    <xsl:variable name="ModeTypeToUpper">
      <xsl:call-template name="ConvertToUpperCase" >
        <xsl:with-param name="string" select ="$ModeType"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:choose>
      <xsl:when test="$ModeTypeToUpper = 'BIGENDIAN'">
        <xsl:value-of select="'1'"/>
      </xsl:when>
      <xsl:when test="$ModeTypeToUpper = 'LITTLEENDIAN'">
        <xsl:value-of select="'0'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="''"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="CheckNodeExistsorNot">
    <xsl:param name="FEE_NODE" />

    <xsl:choose>
      <xsl:when test="$FEE_NODE = ''">
        <xsl:value-of select="'0'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'1'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!--Create a dynamic variable list -->
  <xsl:template name="CreateVariableList">
    <xsl:param name="File" />
    <xsl:for-each select="document($File)/Config/Variables/Variable">
      <xsl:variable name="SourceType" select="SourceType" />
      <xsl:variable name="Source" select="Source" />
      <xsl:element name="Variable">
        <xsl:element name="Name">
          <xsl:value-of select="Name" />
        </xsl:element>
        <xsl:element name="Value">
          <xsl:choose>
            <xsl:when test="$SourceType = 'HRD'">
              <xsl:value-of select="$Source" disable-output-escaping="yes" />
            </xsl:when>
            <xsl:when test="$SourceType = 'DATA'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:*[name()=$Source]"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'DATA_R'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$Source]/tctypes:Value"/>
            </xsl:when>

            <xsl:when test="$SourceType = 'FILE'">
              <!-- only if file isn't empty -->
              <xsl:if test="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name!=''">
                <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
                <xsl:value-of select="'\'"/>
                <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
              </xsl:if>
            </xsl:when>

            <xsl:when test="$SourceType = 'FILE_R'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
              <xsl:value-of select="'\'"/>
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'LIB'">
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="$Source" />
              </xsl:call-template>
            </xsl:when>
            <xsl:otherwise></xsl:otherwise>
          </xsl:choose>
        </xsl:element>
        <xsl:element name="Mandatory">
          <xsl:value-of select="Mandatory" />
        </xsl:element>
      </xsl:element>
    </xsl:for-each>
  </xsl:template>

  <xsl:template mode="myCopy" match="*">
    <xsl:element name="{name(.)}">
      <xsl:copy-of select="@*" />
      <xsl:apply-templates mode="myCopy" />
    </xsl:element>
  </xsl:template>

  <xsl:template name="GetHexmodToolPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HEXMODXPATH"/>
  </xsl:template>

  <!--  <xsl:template name="GetHexmodToolVersion">
	 <xsl:param name="ToolPath"/>
     <xsl:param name="StringInput"/>		
		           
	<xsl:value-of select="normalize-space(substring-after($ToolPath,$StringInput))"/>				
          
	</xsl:template> -->
  <xsl:template name="GetHexmodToolVersion">
    <xsl:param name="ToolPath"/>
    <xsl:value-of select="substring-before(substring-after($ToolPath,'hexmodx\'),'\bin')" />
  </xsl:template>

  <xsl:template name="GetGUAM_FLAG">
    <xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:GUAM_FLAG"/>
    <xsl:choose>
      <xsl:when test="$FlagValue = '2'">
        <xsl:value-of select="'2'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'1'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="GetLastCharacter">
    <xsl:param name="StringValue"/>
    <xsl:value-of select="substring($StringValue, string-length($StringValue), string-length($StringValue))"/>
  </xsl:template>


  <xsl:template name="Get_GUAM_HSM_LENGTH_ADDR">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSM_LENGTH_CRC"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_HSM_START_CRC">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSM_START_CRC"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_HSM_LEN_VALUE">
    <xsl:param name="HSMInfoFile" />
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSM_ACTUAL_LENGTH_CRC"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_HSM_CRC_PATCH_ADDRESS">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSMCRC_PATCH_ADDR"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_HSM_START_FDBCRC">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSM_START_FDBCRC"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_HSM_LENGTH_FDBCRC">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/HSM_LENGTH_FDBCRC"/>
  </xsl:template>

  <xsl:template name="Get_GUAM_FDB_CRC_PATCH_ADDRESS">
    <xsl:param name="HSMInfoFile"/>
    <xsl:value-of select="document($HSMInfoFile)/GUAM_FDB_INFO/FDBCRC_PATCH_ADDR"/>
  </xsl:template>

  <xsl:template name="GetUNC_T_Drive">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:UNC_T_Drive"/>
  </xsl:template>

  <xsl:template name="ReplaceString">
    <xsl:param name="text" />
    <xsl:param name="replace" />
    <xsl:param name="by" />
    <xsl:choose>
      <xsl:when test="contains($text, $replace)">
        <xsl:value-of select="substring-before($text,$replace)" />
        <xsl:value-of select="$by" />
        <xsl:call-template name="ReplaceString">
          <xsl:with-param name="text" select="substring-after($text,$replace)" />
          <xsl:with-param name="replace" select="$replace" />
          <xsl:with-param name="by" select="$by" />
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$text" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="GetSecuMgr_HSM_Matrix_Path">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SecuMgr_HSM_Matrix_Path"/>
  </xsl:template>

  <xsl:template name="DeriveTBHanlingFlag">
    <xsl:param name="input_text" />
    <xsl:variable name="Trimmed_Value">
      <xsl:call-template name="Trim">
        <xsl:with-param name="input">
          <xsl:value-of select="$input_text" />
        </xsl:with-param>
      </xsl:call-template>
    </xsl:variable>

    <xsl:choose>
      <xsl:when test="string-length($Trimmed_Value)= 0">
        <xsl:value-of select="'0'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'1'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <xsl:template name="Derive_HSMFSigningFlag">
    <xsl:param name="input_text1" />
    <xsl:param name="input_text2" />
    <xsl:param name="input_text3" />
    <xsl:variable name="Trimmed_Value1">
      <xsl:call-template name="Trim">
        <xsl:with-param name="input">
          <xsl:value-of select="$input_text1" />
        </xsl:with-param>
      </xsl:call-template>
    </xsl:variable>

    <xsl:variable name="Trimmed_Value2">
      <xsl:call-template name="Trim">
        <xsl:with-param name="input">
          <xsl:value-of select="$input_text2" />
        </xsl:with-param>
      </xsl:call-template>
    </xsl:variable>

    <xsl:variable name="Trimmed_Value3">
      <xsl:call-template name="Trim">
        <xsl:with-param name="input">
          <xsl:value-of select="$input_text3" />
        </xsl:with-param>
      </xsl:call-template>
    </xsl:variable>

    <xsl:choose>
      <xsl:when test="string-length($Trimmed_Value1) &gt; 1 and  string-length($Trimmed_Value2) &gt; 1 and string-length($Trimmed_Value3) &gt; 1">
        <xsl:value-of select="'1'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'0'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:variable name="whitespaceCharacters" select="'&#09;&#10;&#13; '" />

  <!-- Trim Right side of the String -->
  <xsl:template name="TrimRight">
    <xsl:param name="input" />
    <xsl:param name="trim" select="$whitespaceCharacters" />

    <xsl:variable name="length" select="string-length($input)" />
    <xsl:if test="string-length($input) &gt; 0">
      <xsl:choose>
        <xsl:when test="contains($trim, substring($input, $length, 1))">
          <xsl:call-template name="TrimRight">
            <xsl:with-param name="input" select="substring($input, 1, $length - 1)" />
            <xsl:with-param name="trim" select="$trim" />
          </xsl:call-template>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="$input" />
        </xsl:otherwise>
      </xsl:choose>
    </xsl:if>
  </xsl:template>

  <!-- Trim Left side of the String -->
  <xsl:template name="TrimLeft">
    <xsl:param name="input" />
    <xsl:param name="trim" select="$whitespaceCharacters" />

    <xsl:if test="string-length($input) &gt; 0">
      <xsl:choose>
        <xsl:when test="contains($trim, substring($input, 1, 1))">
          <xsl:call-template name="TrimLeft">
            <xsl:with-param name="input" select="substring($input, 2)" />
            <xsl:with-param name="trim" select="$trim" />
          </xsl:call-template>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="$input" />
        </xsl:otherwise>
      </xsl:choose>
    </xsl:if>
  </xsl:template>

  <!-- Trim both sides of the String -->
  <xsl:template name="Trim">
    <xsl:param name="input" />
    <xsl:param name="trim" select="$whitespaceCharacters" />
    <xsl:call-template name="TrimRight">
      <xsl:with-param name="input">
        <xsl:call-template name="TrimLeft">
          <xsl:with-param name="input" select="$input" />
          <xsl:with-param name="trim" select="$trim" />
        </xsl:call-template>
      </xsl:with-param>
      <xsl:with-param name="trim" select="$trim" />
    </xsl:call-template>
  </xsl:template>

  <xsl:template name="GetFLASH0_STARTADDRESS">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/SECUMGR_HSM_INFO/FLASH0_START"/>
  </xsl:template>

  <xsl:template name="GetFLASH0_ENDADDRESS">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/SECUMGR_HSM_INFO/FLASH0_END"/>
  </xsl:template>

  <xsl:template name="GetFLASH0_LENGTH">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/SECUMGR_HSM_INFO/FLASH0_LEN"/>
  </xsl:template>

  <xsl:template name="GetHSMFLAG">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SECUMGR_HSM_FLAG"/>
  </xsl:template>

  <xsl:template name="GetFSWKeys_Config_Template">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FSWKeys_Config_Template"/>
  </xsl:template>

  <xsl:template name="GetTrustedBoot_ConfigPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Trusted_BootTable_Config"/>
  </xsl:template>

</xsl:stylesheet>
