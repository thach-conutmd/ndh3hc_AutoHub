!TRANSFORMATION

//---------------------------------------------------
  !begin 
//---------------------------------------------------

[]

  source("MCS").descendant[?variable|?fileinsert].putindex(gid,@value,that.@name).null,
  source("RawContainer")
;

//  !string [r.next:1[type?pi&(gid?variable|gid?fileinsert|gid?fillin)]] !continue;;
//  !string [r.previous:1[type?pi&(gid?variable|gid?fileinsert|gid?fillin)]] !continue;;


//---------------------------------------------------
  !pi 
//---------------------------------------------------

[this[?variable]]

  (*i := data.parse("(@*^(name)=\"%)^[\"]+(@*%)")).null,
  getindex("variable",*i)
    .parse("((&%&amp;)|(\\<%&lt;)|(>%&gt;)|(\"%&quot;)|('%&apos;)|@)*")
;


//---------------------------------------------------
  !pi 
//---------------------------------------------------

[this[?fileinsert]]

  (*i := data.parse("(@*^(name)=\"%)^[\"]+(@*%)")).null,
  (*file := getindex("fileinsert",*i))
    .MMsystem\isFile()
    .(read(*file,"data",<|encoding|>node{"iso-8859-1"}))
    .parse("((&%&amp;)|(\\<%&lt;)|(>%&gt;)|(\"%&quot;)|('%&apos;)|@)*"),
  closesource(*file).null
;

//---------------------------------------------------
  !pi 
//---------------------------------------------------

[this[?fillin]]

  !replace 
  
    (*i := data.parse("(@*^(name)=\"%)^[\"]+(@*%)")).null,
    (
      getindex("variable",*i).(<|variable,data:=self.data|>pi)
    |
      getindex("fileinsert",*i).(<|fileinsert,data:=self.data|>pi)
    )
;
