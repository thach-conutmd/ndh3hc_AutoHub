<!SGML
  "ISO 8879:1986"
CHARSET
  BASESET
    "ISO 646-1983//CHARSET International Reference Version (IRV)//ESC 2/5 4/0"
  DESCSET
      0   9 UNUSED
      9   2   9
     11   2 UNUSED
     13   1  13
     14  18 UNUSED
     32  95  32
    127   1 UNUSED
  BASESET
    "ISO Registration Number 100//CHARSET ECMA-94 Right Part of Latin Alphabet Nr. 1//ESC 2/13 4/1"
  DESCSET
    128  32 UNUSED
    160  95  32
    255   1 UNUSED
CAPACITY
  SGMLREF
  TOTALCAP 1000000 -- default = 35000 --
  ENTCAP   100000 -- default = 35000 --
  ENTCHCAP 100000 -- default = 35000 --
  ELEMCAP  100000 -- default = 35000 --
  GRPCAP   1000000 -- default = 35000 --
  EXGRPCAP 100000 -- default = 35000 --
  EXNMCAP  100000 -- default = 35000 --
  ATTCAP   100000 -- default = 35000 --
  ATTCHCAP 100000 -- default = 35000 --
  AVGRPCAP 100000 -- default = 35000 --
  NOTCAP   100000 -- default = 35000 --
  NOTCHCAP 100000 -- default = 35000 --
  IDCAP    100000 -- default = 35000 --
  IDREFCAP 100000 -- default = 35000 --
  MAPCAP   100000 -- default = 35000 --
  LKSETCAP 100000 -- default = 35000 --
  LKNMCAP  100000 -- default = 35000 --
SCOPE DOCUMENT
SYNTAX
  SHUNCHAR CONTROLS 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 127 255
  BASESET
    "ISO 646-1983//CHARSET International Reference Version (IRV)//ESC 2/5 4/0"
  DESCSET
      0 128 0
  FUNCTION
    RE           13
    RS           10
    SPACE        32
    TAB SEPCHAR   9
  NAMING
    LCNMSTRT ""
    UCNMSTRT ""
    LCNMCHAR "-."
    UCNMCHAR "-."
    NAMECASE
      GENERAL YES
      ENTITY NO
  DELIM
    GENERAL SGMLREF
    SHORTREF SGMLREF
  NAMES SGMLREF
  QUANTITY SGMLREF
    ATTCNT 100 -- default = 40 --
    ATTSPLEN 960 -- default = 960 --
    BSEQLEN 960 -- default = 960 --
    DTAGLEN 16 -- default = 16 --
    DTEMPLEN 16 -- default = 16 --
    ENTLVL 16 -- default = 16 --
    GRPCNT 100 -- default = 32 --
    GRPGTCNT 96 -- default = 96 --
    GRPLVL 16 -- default = 16 --
    LITLEN 600 -- bei AIS:600; default = 240 --
    NAMELEN 40 -- bei AIS:40;default = 8 --
    NORMSEP 2 -- default = 2 --
    PILEN 1000 -- default = 240 --
    TAGLEN 960 -- default = 960 --
    TAGLVL 24 -- default = 24 --
FEATURES
  MINIMIZE DATATAG NO OMITTAG YES RANK NO SHORTTAG YES
  LINK SIMPLE NO IMPLICIT NO EXPLICIT NO
  OTHER CONCUR NO SUBDOC NO FORMAL YES
-- bei AIS:OTHER CONCUR NO SUBDOC YES 99999999 FORMAL YES --
APPINFO NONE
>
