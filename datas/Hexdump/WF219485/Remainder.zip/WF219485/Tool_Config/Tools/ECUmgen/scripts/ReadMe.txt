23.02.2007
GS-EC/EDG3-Wahler
file ECUmerge.xml.mmx ausgetauscht alte Version in .\save
Massnahme wegen Behandlung sgm-Container VW �ber ECUmGen
siehe auch .\saveEcu-Memory-Container-Tool.msp