@echo off
IF "%1%"="" GOTO HELP
start /wait ecumgen -error stop -log .\_ecu.log -lo -l0 -batch %1 %2 %3 %4 %5 %6 %7 %8 %9
type _ecu.log
goto END
:HELP
echo Usage: ECUbatch mcafile [-target container] [-error [stop continue show]] [-l[1-3]]
:END