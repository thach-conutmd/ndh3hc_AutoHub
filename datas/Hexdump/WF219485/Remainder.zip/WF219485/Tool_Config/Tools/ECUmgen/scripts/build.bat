@echo off

for %f in (*.mm) do mmx -c -M %f
