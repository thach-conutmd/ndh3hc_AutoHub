<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<!-- <xsl:param name="PRecentLoopCount"/> -->
	<!-- <xsl:variable name="CurrentIndex" select="$PRecentLoopCount"/> -->

	<xsl:template match="/">
		<ToolInput>
			<Mode>HexmodX - Create AES Encrypted Files</Mode>
			<HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>			
			<Module>EncryptXML</Module>	
			<Module>OutputXML</Module>
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_COMPRESSED_HEX_TO_ENCRYPTED_ENC_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
  				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>			    		    
			    <Variable>
					<Name>HEXMODX_ENCRYPT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_ENCRYPT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>

			</Variables>
     	</MainXML>
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_COMPRESSED_HEX_TO_ENCRYPTED_ENC_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE_NAME</Name>
						<Value>
								
								<!-- <xsl:call-template name="GetSoftwareName"/>   -->
								<!-- </xsl:call-template><xsl:value-of select="'_EOL'"/> -->
								<xsl:call-template name="RunTime_FileList_GetFileName" >
									<xsl:with-param name="FileClassID" select="'ASW0_DS0_Hex'"/>
									<xsl:with-param name="GetValue" select="'yes'"/>
									<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
								</Value>
				</Variable>     			
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>		

     <!-- Encrypt Config-->
    <EncryptXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Encrypt_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_COMPRESSED_HEX_TO_ENCRYPTED_ENC_ENCRYPT_XML'"/></xsl:call-template></Script>
     		<Variables> 
				<Variable>
					<Name>AESKEY</Name>
					<Value>
						<xsl:call-template name="GetRAWkey">
							<xsl:with-param name="File">
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\Raw_Key_PatchcheckInfo.xml'" />
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>   			
				<Variable>
					<Name>AESKEYINITIAL</Name>
					<Value>
						<xsl:value-of select="'0x00000000000000000000000000000000'" /> <!--fixed value according to requiremment-->
					</Value>
				</Variable>			
     			<Variable>
					<Name>HEXMODX_AES_ENCRYPT_ALGORITHM</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_AES_ENCRYPT_ALGORITHM'"/></xsl:call-template></Value>
				</Variable>
			</Variables>
	</EncryptXML>
	
	 <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_COMPRESSED_HEX_TO_ENCRYPTED_ENC_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:value-of select="'BIN'" /></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value>
					<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template><xsl:value-of select="'\'" />
								<xsl:call-template name="GetSoftwareName"/>
								<xsl:value-of select="'.enc'" />
								
								</Value>
				</Variable>
			</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
			</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput> 
	</xsl:template>
</xsl:stylesheet>
