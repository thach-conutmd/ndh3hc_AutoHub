<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Derive Tool Version for MDG build </Mode>
			<PST_Library>
				<Item>
					<ID>SUPPRESSFRAMEWORK</ID>
					<Value>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SUPPRESSFRAMEWORK'" />
						</xsl:call-template>
					</Value>
				</Item>
			</PST_Library>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				<WrapperPath>
					<xsl:call-template name="GetWrapperPath"></xsl:call-template>
				</WrapperPath>
				<Files>
					<BasePST>
						<Directory>
							<xsl:call-template name="FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'MEDC17_TOOLS'"/>
							</xsl:call-template>
						</Directory>
						<Name>
							<xsl:call-template name="FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'MEDC17_TOOLS'"/>
							</xsl:call-template>
						</Name>
					</BasePST>
					<PDTools>
						<xsl:call-template name="GetPDTools"></xsl:call-template>
					</PDTools>
					<RunMode>
						<xsl:call-template name="GetRunMode"></xsl:call-template>
					</RunMode>
					<Library_Tools>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'TOOL_LIST'" />
						</xsl:call-template>
					</Library_Tools>
				</Files>
				<BuidVersionLabel>PRJ_BUILD_VERSION</BuidVersionLabel>
				<BuildVersion>mdgb</BuildVersion>
				<Variables>
					<Variable>
						<Name></Name>
						<Value></Value>
					</Variable>
				</Variables>
			</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
