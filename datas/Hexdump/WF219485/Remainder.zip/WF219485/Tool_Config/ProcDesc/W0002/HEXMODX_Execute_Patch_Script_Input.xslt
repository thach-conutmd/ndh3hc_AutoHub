<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>HexModX - Patch labels</Mode>
			<HexModeInput>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				<Modules>
					<Module>MainXML</Module>
					<Module>InputXML</Module>
					<Module>OutputXML</Module>
				</Modules>
				<!-- Main - Config -->
				<MainXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name>
							<xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_MAIN_'" />
							<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
							<xsl:value-of select="'.xml'" />
						</Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_MAIN_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>HEXMODX_MAIN_LOGFILE</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMODX_EXECUTE_PATCHSCRIPT_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.txt'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMODX_INPUT_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.xml'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMODX_OUTPUT_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.xml'" />
							</Value>
						</Variable>
						<Variable>
							<Name>HEXMODX_PATCHCHECK_XML_NAME</Name>
							<Value>
								<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
								<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template>
								<xsl:value-of select="'\'" />
								<xsl:call-template name="RunTime_FileList_GetFileName" >
								<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
				 				</xsl:call-template>
							</Value>
						</Variable>
					</Variables>
				</MainXML>
				<!-- Input Config-->
				<InputXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name>
							<xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_'" />
							<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
							<xsl:value-of select="'.xml'" />
						</Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_INPUT_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>HEXFILE</Name>
							<Value>
							<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'HexModX_MergedHexFile'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'HexModX_MergedHexFile'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
							</Value>
						</Variable>
						<Variable>
								<Name>FILETYPE</Name>
								<Value><xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
						</Variable>
						<Variable>
							<Name>MODETYPE</Name>
								<Value><xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
						</Variable>
					</Variables>
				</InputXML>
				<OutputXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name>
							<xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_'" />
							<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
							<xsl:value-of select="'.xml'" />
						</Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_EXECUTE_PATCHSCRIPT_OUTPUT_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>HEXFILE</Name>
							<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'" />							
							<xsl:value-of select="'Patched.hex'" />
							</Value>						
						</Variable>
						<Variable>
							<Name>FILETYPE</Name>
							<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
						</Variable>
					</Variables>
				</OutputXML>
				<LogFileAnalyser>
					<Files>
						<File>
							<Classification>Hexmod17-Main-Logfile</Classification>
							<Key>PATCH_HEX_CODE</Key>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							</Directory>
							<Name>
								<xsl:value-of select="'HEXMODX_EXECUTE_PATCHSCRIPT_LOG_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.txt'" />
							</Name>
						</File>
					</Files>
				</LogFileAnalyser>
				<PST_Library></PST_Library>
			</HexModeInput>
			<CallInformation>
					<ToolName>HEXMODX</ToolName>
					<CallType></CallType>
					<ToolVersion></ToolVersion>
					<ToolLocation>
						<xsl:call-template name="RunTime_Tool_Path">
						        <xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			      </xsl:call-template>
						</ToolLocation>
					<InputVerification></InputVerification>
	 </CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
