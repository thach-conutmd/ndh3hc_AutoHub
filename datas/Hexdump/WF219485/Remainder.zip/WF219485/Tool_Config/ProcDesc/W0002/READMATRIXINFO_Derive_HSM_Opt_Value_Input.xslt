 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:template match="/">
		<ToolInput>
			<Mode>Derive HSM_OPT Value for FSW Container</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"/>
				</WorkingDirectory>
				<DefaultValueMessage>HSM_Opt Value</DefaultValueMessage>
				<ConfigFile>
					<Directory>
						<xsl:call-template name="GetMatrixPath"></xsl:call-template>
					</Directory>
					<Name>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HSM_ADDFEATURE_MATRIX_NAME'"/>
						</xsl:call-template>
					</Name>
				</ConfigFile>	
				<Variables>  
					<Variable>
						<Name>HSM_ADD_FEATURE</Name>
						<Value>
							<xsl:call-template name="GetHSMAddFeature"/>
						</Value>
					</Variable>
				</Variables>  
				<LogFileAnalyser>
					<Files>
					</Files>
				</LogFileAnalyser>	
			</Input>  
			<CallInformation>
				<ToolName/>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>
