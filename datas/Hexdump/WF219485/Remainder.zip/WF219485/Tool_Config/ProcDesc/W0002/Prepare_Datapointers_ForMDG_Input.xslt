 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolInput>
		<Mode>Read FSWAdressModel and Prepare Data Pointers and Checksums</Mode>
		<InputFile>
		
		<Directory>
		<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'FSW_AddressModel_XMLFile'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
		</Directory>
		
		<Name>
		<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'FSW_AddressModel_XMLFile'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
		
		</Name>
		</InputFile>
		<LogFile>
			<Directory>
				 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
			</Directory>
				
			<Name>
				<xsl:value-of select="'Datapointer_Log.log'" />				
			</Name>		
		</LogFile>		
		<Sign_Flag><xsl:call-template name="GetSignFlagValue"/></Sign_Flag>
		<Flash0_Required><xsl:call-template name="GetFlash0_Required"/></Flash0_Required>
		 <CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation></ToolLocation>
			<InputVerification></InputVerification>
		 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
