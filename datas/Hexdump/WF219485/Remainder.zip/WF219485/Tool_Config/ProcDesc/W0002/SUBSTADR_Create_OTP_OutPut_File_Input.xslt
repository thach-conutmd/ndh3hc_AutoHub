 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>Copy OTP Info to file</Mode>
    <Input>
     	<SourceTemplateFile>
			<Directory>
			</Directory>
			<Name>
			</Name>
		</SourceTemplateFile>
		<TargetTemplateFile>
			<Directory>
			</Directory>
			<Name>
			</Name>
		</TargetTemplateFile>
		<Script><xsl:value-of select="'OTP_KEY = '"/>
				<xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'OTP_Key'"/>
				</xsl:call-template>
				<xsl:text disable-output-escaping="yes">    </xsl:text>
				<xsl:value-of select="'OTP_OVERVIEW = '"/>
				<xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'OTP_Overview'"/>
				</xsl:call-template>
		</Script>
		<List></List>
    </Input>  
    </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>