 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
   <xsl:variable name="Flash0AdrModlFile" select="concat($WorkingDir, '\FLASH_0_AdrMod.xml')" />
                                                                     

   <xsl:template match="/">

		<ToolInput>
			<Mode>Script to Update FSW AddressModel For Flash0 GUAM</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"/>
				</WorkingDirectory>
				<Scripts>
					<Script>
						<Write2PSTLib>False</Write2PSTLib>
						<Key>REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL_GUAM</Key>
						<Comment>Script for creation of Flash0 Hexfile </Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_REPLACE_FLASH0_ADDRESS_INTO_FSWADDRESSMODEL_GUAM'"/>
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>	
								<FswAddressModelFile>
								
										<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
											<xsl:with-param name="FileClassID" select="'FSW_AddressModel_XMLFile'"/>
											<xsl:with-param name="GetValue" select="'yes'"/> 
										</xsl:call-template>
								
											<xsl:value-of select="'\'" />
									
										<xsl:call-template name="RunTime_FileList_GetFileName" >
										<xsl:with-param name="FileClassID" select="'FSW_AddressModel_XMLFile'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
										</xsl:call-template>											
									
								</FswAddressModelFile>
								<WorkingDirectory>
								<xsl:call-template name="GetWorkingDirectory"/>
								</WorkingDirectory>
								<STARTADDRESS>
									<xsl:call-template name="RunTime_Data_Value">
										<xsl:with-param name="DataClassID" select="'CFGEXP_NEW_SECUMGR_SOURCE_START'"/>
									</xsl:call-template>
								</STARTADDRESS>
								<ENDADDRESS>
									<xsl:call-template name="RunTime_Data_Value">
										<xsl:with-param name="DataClassID" select="'CFGEXP_NEW_SECUMGR_SOURCE_END'"/>
									</xsl:call-template>
								</ENDADDRESS>						
							</Datas>				
						</DataBase>
					</Script>
				</Scripts>
				<PST_Library>
				</PST_Library>
			</Input>  
			<CallInformation>
				<ToolName/>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>
