<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

  <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
  <xsl:variable name="RT_RELEASEPST" select="tctypes:ToolOutput/tctypes:RunHexMod17Output/tctypes:ResultingFile"/>
  <xsl:variable name="RT_HexModx_SignedHexfile_Complete_To_WorkFlow" select="tctypes:ToolOutput/tctypes:RunHexMod17Output/tctypes:DataToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='RELEASEPST']/tctypes:Data"/>
  
 <xsl:variable name="RT_HexMod_SignedHexfile_Complete" select="tctypes:ToolOutput/tctypes:RunHexMod17Output/tctypes:ResultingFile"/> 
 
 
</xsl:stylesheet>