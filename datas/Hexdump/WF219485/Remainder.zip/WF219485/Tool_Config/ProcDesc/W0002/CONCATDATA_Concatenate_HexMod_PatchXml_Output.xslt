 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<ResultingFiles>
				<File>
					<FileClassID>Patch_Script_File</FileClassID>
					<FileClassName>Patch_Script_File</FileClassName>
					<Location>
					<Directory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'HEXMOD_EXECUTE_PATCH_'"/>
							<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
							<xsl:value-of select="'.xml'"/>
						</Name>			
					</Location>
				</File>
    		</ResultingFiles>
    		<TargetFile>
				<Location>
			
					<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					</Directory>
						<Name><xsl:value-of select="'HEXMOD_EXECUTE_PATCH_'"/>
							<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
							<xsl:value-of select="'.xml'"/>
						</Name>
				</Location>
    		</TargetFile>
		</Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
  </xsl:template>
</xsl:stylesheet>
