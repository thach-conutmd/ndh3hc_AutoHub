<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				<ResultingFiles>
					<File>
						<FileClassID>Hex_Compare_Known_File</FileClassID>
						<FileClassName>Hex_Compare_Known_File</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							</Directory>
							<Name>						
								<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>							
								<xsl:value-of select="'_Known.xlsx'" />
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>Hex_Compare_UnKnown_File</FileClassID>
						<FileClassName>Hex_Compare_UnKnown_File</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							</Directory>
							<Name>
								<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
								<xsl:value-of select="'_Unknown.xlsx'" />
							</Name>
						</Location>
					</File>

				</ResultingFiles>
        <DataToWorkFlow>                  
          <WorkFlowData>
            <WorkFlowID>HEX_CMP</WorkFlowID>
            <WorkFlowName>HEX_CMP</WorkFlowName>
            <Data>
              <DataClassID>FileName</DataClassID>
              <DataClassName>HEX_CMP</DataClassName>
              <DataValue>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\'"/>
                <xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
                <xsl:value-of select="'_Known.xlsx'" />
              </DataValue>
              <DataType>String</DataType>
            </Data>
          </WorkFlowData>
          <WorkFlowData>
            <WorkFlowID>HEX_CMP_UN</WorkFlowID>
            <WorkFlowName>HEX_CMP_UN</WorkFlowName>
            <Data>
              <DataClassID>FileName</DataClassID>
              <DataClassName>HEX_CMP_UN</DataClassName>
              <DataValue>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\'"/>
                <xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
                <xsl:value-of select="'_Unknown.xlsx'" />
              </DataValue>
              <DataType>String</DataType>
            </Data>
          </WorkFlowData>
        </DataToWorkFlow>


        <Results>
					<Item>
						<ID>Known_TotalLabelMatches</ID>
						<Value></Value>
					</Item>
					<Item>
						<ID>Known_TotalKnownDifferences</ID>
						<Value></Value>
					</Item>
					<Item>
						<ID>UnKnown_TotalUnKnownDifferences</ID>
						<Value></Value>
					</Item>
					<Item>
						<ID>UnKnown_HasDifferences</ID>
						<Value></Value>
					</Item>
				</Results>
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
