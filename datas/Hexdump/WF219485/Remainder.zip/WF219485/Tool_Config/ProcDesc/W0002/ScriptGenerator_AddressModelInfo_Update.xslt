<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


 <xsl:variable name="RT_KONSERVE_PATCHANDCHECK_LABELS" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='KONSERVE_PATCHANDCHECK_LABELS']/tctypes:Value"/>
 <xsl:variable name="RT_HEXMODX_PATCH_MAIN_XML" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='HEXMODX_PATCH_MAIN_XML']/tctypes:Value"/>
 <xsl:variable name="RT_Updated_CHECKSUM_VALUE" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECKSUM_LENGTH_SPECIFIC_REGEX']/tctypes:Value"/>
 <xsl:variable name="RT_CB_INFOBLOCKID_302" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CB_INFOBLOCKID_302']/tctypes:Value"/>
 <xsl:variable name="RT_LASTRUN_HEXMOD_HASHOUTPUT" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='LASTRUN_HEXMOD_HASHOUTPUT']/tctypes:Location"/>
 <xsl:variable name="RT_LASTRUN_WITHOUTHSM_HASHOUTPUT" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='LASTRUN_WITHOUTHSM_HASHOUTPUT']/tctypes:Location"/>
 <xsl:variable name="RT_LASTRUN_FALSH0_HASHOUTPUT" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='LASTRUN_FALSH0_HASHOUTPUT']/tctypes:Location"/>
 <xsl:variable name="RT_LASTRUN_Reprog_HASHOUTPUT" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='LASTRUN_Reprog_HASHOUTPUT']/tctypes:Location"/>
 <xsl:variable name="RT_LASTRUN_GUAM_HASHOUTPUT" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='LASTRUN_GUAM_HASHOUTPUT']/tctypes:Location"/>
  <xsl:variable name="RT_GUAM_FLAG" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:GUAM_FLAG"/>
 
 
</xsl:stylesheet>