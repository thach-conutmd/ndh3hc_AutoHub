 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="AddressModelFile"  select="concat($WorkingDir, '\AddressModel.xml')" />
<xsl:variable name="InfotableLogFile"  select="concat($WorkingDir, '\InfotableLog.xml')" />

<xsl:template match="/">

    <ToolInput>
    <Mode> Prepare ADDRESS_MODEL_INFO file</Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>
				<Script>
					<Write2PSTLib>False</Write2PSTLib>
					<Key>NON_BOOT_BLOCKS</Key>
					<Comment>Script Prepare Non boot blocks </Comment>
					<ScriptTemplate>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_NON_BOOT_BLOCKS'" />
						</xsl:call-template>
					</ScriptTemplate>
					<DataBase>
					<Datas>
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  select="$AddressModelFile" />
						</xsl:call-template>				
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  >
						<xsl:call-template name="GetWrapperPath" />
							<xsl:value-of select="'\BOOT_BLOCKS.xml'"/>				 
								</xsl:with-param>
							</xsl:call-template>
						<Non_Boot_Blocks_XML>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>									
							<xsl:value-of select="'\'"/>						
							<xsl:value-of select="'NonBootBlocks.xml'"/>
						</Non_Boot_Blocks_XML>
					</Datas>
					</DataBase>
				</Script>
			<Script>
										<Write2PSTLib>False</Write2PSTLib>
										<Key>ADDRESS_MODEL_INFO</Key>
										<Comment>Script Prepare Non boot blocks </Comment>
										<ScriptTemplate>
											<xsl:call-template name="GetEnvironmentValue">
												<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_ADDRESS_MODEL_INFO'" />
											</xsl:call-template>
										</ScriptTemplate>
										<DataBase>
										 <Datas>
											<xsl:call-template name="GetXMLFromFile">
												<xsl:with-param  name="File"  select="$AddressModelFile" />
											</xsl:call-template>												
											<AddressModel_Info_XML>
												<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>									
												<xsl:value-of select="'\'"/>						
												<xsl:value-of select="'AddressModelInfo.xml'"/>
											</AddressModel_Info_XML>
										  </Datas>
										</DataBase>
			</Script>
		<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>RENAME_HASH_FILES_FOR_LADE_HANDLING</Key>
						<Comment>Script for renaming PD hash files</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_RENAME_HASH_FILES_FOR_LADE_HANDLING'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>							
							<Hash_File_Sign>				
								<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template>
									<xsl:value-of select="'\HEXMOD_HASHOUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.TXT'"/>
							</Hash_File_Sign>
							<Hash_Without_HSM>
								<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template>
									<xsl:value-of select="'\HEXMOD_WITHOUTHSM_HASHOUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.TXT'"/>
							</Hash_Without_HSM>
							<Hash_File_Reprog>
								<xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template>
								<xsl:value-of select="'\HEXMOD_Reprog_HASHOUTPUT_'"/>
									<xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.TXT'"/>
							</Hash_File_Reprog>
							<Hash_File_Flash0>
								<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template>
								<xsl:value-of select="'\HEXMOD_FALSH0_HASHOUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.TXT'"/>	
							</Hash_File_Flash0>		
							<Hash_File_GUAM>
								<xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template>
								<xsl:value-of select="'\HEXMODX_New_GUAM_HASHOUTPUT'"/>
								<xsl:value-of select="'.TXT'"/>	
							</Hash_File_GUAM>		
						</DataBase>
					</Script>		
		</Scripts>
		<PST_Library>
		</PST_Library>
		
    </Input>  
	
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
