 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>
 <xsl:param name="PRecentLoopCount"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="CurrentIndex" select="$PRecentLoopCount"/>
<xsl:variable name="NumberOfVariants" select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants" />

    <xsl:template match="/">
    
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
    <Temp>
		<xsl:choose>
			<xsl:when test="$NumberOfVariants='0'">
				<xsl:value-of select="'HexMod17_PatchedHexfile_1'"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="'HexMod17_PatchedHexfile_'"/><xsl:value-of select="$CurrentIndex"/>
			</xsl:otherwise>
		</xsl:choose>
	</Temp>
    <TempFile>
		<xsl:choose>
			<xsl:when test="$NumberOfVariants='0'">
				<xsl:value-of select="'HexModx_VC_HexFile_1'"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="'HexModx_VC_HexFile_'"/><xsl:value-of select="$CurrentIndex"/>
			</xsl:otherwise>
		</xsl:choose>
	</TempFile>
		<RunHexMod17Output>
    		<ResultingFile> 
     		   <Directory><xsl:call-template name="GetWorkingDirectory">
					</xsl:call-template></Directory>
			   <Name>
			   <xsl:choose>
			    <xsl:when test="$NumberOfVariants='0'">
						<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
						<xsl:value-of select="'_Patched'"/><xsl:value-of select="'.hex'"/>
				</xsl:when>
				<xsl:otherwise>
						<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
						<xsl:value-of select="'_Patched_'"/><xsl:value-of select="$CurrentIndex"/><xsl:value-of select="'.hex'"/>
				</xsl:otherwise>
				</xsl:choose>
				
				</Name>
    		</ResultingFile>	
		</RunHexMod17Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
 
    </xsl:template>
</xsl:stylesheet>
