 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="DataHandling" select="/tctypes:UseCase/tctypes:Data/tctypes:Data_Handling" />
<xsl:variable name="NumberOfVariants" select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants" />
<xsl:variable name="DH_NoOfVar_Concatenated"  select="concat($DataHandling,$NumberOfVariants )" />
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>PED Compare Hex Files</Mode>
    <Input>
    
    	<!-- Init-Values for Progress-Display -->
		<EstimatedRunTime>10</EstimatedRunTime>	<!-- 10 Minutes-->
		<DateTimeInterval>0</DateTimeInterval>				<!-- 1 = Minutes  / 0 = Seconds-->
		
     	<SourceTemplateFile>
			<Directory></Directory>
			<Name></Name>
		</SourceTemplateFile>
		<TargetTemplateFile>
			<Directory><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template></Directory>
			<Name><xsl:value-of select="'\Hex_Compare.pcm'"/></Name>
		</TargetTemplateFile>
		
		<Script>
			<xsl:call-template name="RunTime_Data_Value">
				<xsl:with-param name="DataClassID" select="'PED_SCRIPT_HEXCODE_COMPARE'" />
			</xsl:call-template>
		</Script>
		<ScriptMandatory>1</ScriptMandatory>
		<Variables>
			<Variable>
				<Name>WORKINGDIRECTORY</Name>
				<Value><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template></Value>
			</Variable>	
		</Variables>
		<CommandLine><xsl:value-of select="' -l '"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\Hex_Compare.log'"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' -b '"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\Hex_Compare.pcm'"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>	
						
						<!-- p1 Realese Hex-->
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template><xsl:value-of select="'\'"/>						
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>
						
						<xsl:choose>
						<xsl:when test="$DH_NoOfVar_Concatenated='00'">
						<!-- p2 App Hex-->
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template><!--<xsl:value-of select="'\'"/> -->					
						<xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>
						</xsl:when>
						
						<xsl:otherwise>
						<!-- p2 App Hex-->
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template><!--<xsl:value-of select="'\'"/> -->					
						<xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>
						</xsl:otherwise>
						</xsl:choose>
						<!-- p3 Output: *.cmp-->
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
						<xsl:value-of select="'.cmp'"/>
						<xsl:value-of select="'&quot;'"/>
		</CommandLine>
		<LogFileAnalyser>
			<Files>
					<File>
						<Classification>Ped-Logfile</Classification>
						<Key>PED_HEX_COMPARE_MDG</Key>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:value-of select="'Hex_Compare.log'"/></Name>
					</File>
				</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName>PED</ToolName>
		<CallType></CallType>
		<ToolVersion>1v19</ToolVersion>
		<ToolLocation>
      <xsl:call-template name="RunTime_Tool_Path">
        <xsl:with-param name="ToolName" select="'PEDVERSION'"/>
      </xsl:call-template>
    </ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
