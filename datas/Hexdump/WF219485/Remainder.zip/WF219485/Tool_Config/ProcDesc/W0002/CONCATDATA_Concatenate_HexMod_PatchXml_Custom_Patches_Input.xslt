 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>Concatenation of HexMod PatchXml</Mode>
    <Input>
		<!-- Source data Type 1- Binary Data 2- Ascii Data 3 -Unicode Data-->
		<SourceDataType><xsl:value-of select="'2'"/></SourceDataType>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<List>
			<!-- Entry for Source Input files. Order should be same as Merge order -->										
						
			<Entry>
					<SourceFile>
						<Directory></Directory>
						<Name></Name>
					</SourceFile>
					<SourceData><![CDATA[<?xml version="1.0" encoding="UTF-8" ?>
					<CONF xmlns="www.rbin.com/mds-1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="www.rbin.com/mds-1 ..\schemas\baseio.xsd">
					<HEXMOD>]]></SourceData>				
			</Entry>
			<Entry>
				<SourceFile>
					<Directory></Directory>
					<Name></Name>
				</SourceFile>
				<SourceData><![CDATA[<PATCHCHECK RESULT-LOC="]]><xsl:call-template name="RunTime_FileList_GetFileDirectory">
				<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
				</xsl:call-template>
				<xsl:value-of select="'\'"/>
				<xsl:call-template name="RunTime_FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
				</xsl:call-template><![CDATA[">]]></SourceData>			
			</Entry>
			<Entry>
				<SourceFile>
					<Directory><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
					<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template></Directory>
					<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
					<xsl:with-param name="FileClassID" select="'Patch_Script_File'"/>
					<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template></Name>
				</SourceFile>
				<SourceData></SourceData>				
			</Entry>
			<Entry>
			<SourceFile>
					<Directory><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
					<xsl:with-param name="FileClassID" select="'Replaced_Infotable_PatchFile'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template></Directory>
					<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
					<xsl:with-param name="FileClassID" select="'Replaced_Infotable_PatchFile'"/>
					<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template></Name>
				</SourceFile>
				<SourceData></SourceData>
			</Entry>
      <Entry>
        <SourceFile>
          <Directory>
          </Directory>
          <Name></Name>
        </SourceFile>
        <SourceData><![CDATA[</PATCHCHECK></HEXMOD></CONF>]]></SourceData>
      </Entry>
      	</List>
    </Input>  
    </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>