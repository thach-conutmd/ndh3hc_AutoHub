<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				<ResultingFiles>
						<File>
							<FileClassID>Flash0</FileClassID>
							<FileClassName>Flash0</FileClassName>
							<Location>
								<Directory>
									<xsl:call-template name="GetWorkingDirectory"/>
								</Directory>
								<Name>
									<xsl:value-of select="'ASW0Trojan_Factory_Temp.hex'"/>
								</Name>
							</Location>
						</File>
							<File>
							<FileClassID>Flash0_Factory_TEMP_Ena</FileClassID>
							<FileClassName>Flash0_Factory_TEMP Ena</FileClassName>
							<Location>
								<Directory>
									<xsl:call-template name="GetWorkingDirectory"/>
								</Directory>
								<Name>
									<xsl:value-of select="'ASW0Trojan_Factory_Ena_Temp.hex'"/>
								</Name>
							</Location>
						</File>
						<File>
							<FileClassID>Flash0_AddressModel</FileClassID>
							<FileClassName>Flash0_AddressModel_Factory</FileClassName>
							<Location>
								<Directory>
									<xsl:call-template name="GetWorkingDirectory"/>
								</Directory>
								<Name>
									<xsl:value-of select="'FLASH0_AddressModel.xml'"/>
								</Name>
							</Location>
						</File>
						<File>
							<FileClassID>Flash0_AddressModel_ENA</FileClassID>
							<FileClassName>Flash0_AddressModel_Fac_Ena</FileClassName>
							<Location>
								<Directory>
									<xsl:call-template name="GetWorkingDirectory"/>
								</Directory>
								<Name>
									<xsl:value-of select="'FLASH0_AddressModelEna.xml'"/>
								</Name>
							</Location>
						</File>
					<File>
						<FileClassID>Flash0_Log</FileClassID>
						<FileClassName>Flash0_Log</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'LOG_CreateFlash0.txt'"/>
							</Name>
						</Location>
					</File>
				</ResultingFiles>
			</Output>
			<ReturnInformation>
				<ReturnCode/>
				<TimeStart/>
				<TimeFinish/>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
