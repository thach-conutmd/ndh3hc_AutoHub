<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Run KMSKDF Tool from local </Mode>
			<SignToolRemoteInput>
				<InputFile>
					<Directory><xsl:call-template name="GetWrapperPath"></xsl:call-template></Directory>
					<Name><xsl:value-of select="'Dummy.txt'"/></Name> 				
				</InputFile>
				<AdditionalInfo>						
					<COMMAND_LINE>									
					<!-- <xsl:call-template name="GetEnvironmentValue"> -->
								<!-- <xsl:with-param name="LookUpItem" select="'MEMLAY_KEYPATH'"/> -->
						<!-- </xsl:call-template> -->
						<!-- <xsl:value-of select="'RBAROOT2:CN\\RBA2MDG1:CN\\RBA2MDG1/HONDA1:CN\\GenEncrSW_MDG1_HONDA_V01'"/>		
						-->
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'KDF_KEY_PATH'" />
							</xsl:call-template>
							<xsl:value-of select="'\\'"/>
							<!-- <xsl:call-template name="RunTime_Data_Value"> -->
								<!-- <xsl:with-param name="DataClassID" select="'ENCRYPTION_LABEL_SLOT'" /> -->
							<!-- </xsl:call-template> -->
							<xsl:call-template name="GetCoreMaster"></xsl:call-template>
							<!-- Derive from SHE -->
							<xsl:value-of select="' '"/>
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'ENCRYPTION_CONTEXT_KEY'" />
							</xsl:call-template>								
							<xsl:value-of select="' '"/>
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'ENCRYPTION_LABEL_SLOT'" />
							</xsl:call-template>					
					</COMMAND_LINE>						
					<!-- Aditional info can be added if required -->					
				</AdditionalInfo>
				<WTS>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'TSAppCompat'" />
					</xsl:call-template>
				</WTS>
				<WorkFlowID><xsl:call-template name="GetWorkFlowID"></xsl:call-template></WorkFlowID>
			</SignToolRemoteInput>
			<CallInformation>
				<ToolName>KDFTOOL</ToolName>
				<CallType></CallType>
				<ToolVersion>1v00</ToolVersion>
				<ToolLocation>
				<Directory><xsl:value-of select="'C:\MDG1\Tprotpackage\UBKPKI_KMS_KDF\'"/></Directory>
					<Name><xsl:value-of select="'UBKPKI_KDF.bat'"/></Name>	
				</ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>