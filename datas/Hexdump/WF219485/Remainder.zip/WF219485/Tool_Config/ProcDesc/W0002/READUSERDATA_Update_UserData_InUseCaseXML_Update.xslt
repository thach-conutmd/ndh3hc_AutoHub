<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:variable name="RT_User_LastName" select="tctypes:ToolOutput/tctypes:Output/tctypes:LastName"/>
<xsl:variable name="RT_User_FirstName" select="tctypes:ToolOutput/tctypes:Output/tctypes:FirstName"/>
<xsl:variable name="RT_User_Company" select="tctypes:ToolOutput/tctypes:Output/tctypes:Company"/>
<xsl:variable name="RT_User_Department" select="tctypes:ToolOutput/tctypes:Output/tctypes:Department"/>
<xsl:variable name="RT_User_Role" select="tctypes:ToolOutput/tctypes:Output/tctypes:Role"/>
<xsl:variable name="RT_User_ZIP" select="tctypes:ToolOutput/tctypes:Output/tctypes:ZIP"/>
<xsl:variable name="RT_User_City" select="tctypes:ToolOutput/tctypes:Output/tctypes:City"/>
<xsl:variable name="RT_User_Phone" select="tctypes:ToolOutput/tctypes:Output/tctypes:Phone"/>
<xsl:variable name="RT_User_Fax" select="tctypes:ToolOutput/tctypes:Output/tctypes:Fax"/>
 <xsl:variable name="RT_User_EMail" select="tctypes:ToolOutput/tctypes:Output/tctypes:EMail"/>
 <xsl:variable name="RT_User_Address" select="tctypes:ToolOutput/tctypes:Output/tctypes:Address"/>
 
</xsl:stylesheet>