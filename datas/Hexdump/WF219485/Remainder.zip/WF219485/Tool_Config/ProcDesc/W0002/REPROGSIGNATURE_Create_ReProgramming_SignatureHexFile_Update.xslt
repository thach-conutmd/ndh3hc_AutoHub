<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt" />
	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML" />
	<xsl:output method="xml" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
 
    <!-- <xsl:variable name="RT_BIN2HEX_Reprog" select="tctypes:ToolOutput/tctypes:ResultingFile" /> -->
    
    <xsl:variable name="RT_REPROGRAM_SIGNATURE_SIZE" select="tctypes:ToolOutput/tctypes:REPROG_SIGNATURE_SIZE[child::tctypes:Name='Signed_tag1']/tctypes:Value" />
    
    <xsl:variable name="RT_REPROGRAM_SIGNATURE_SIZE_Flash0" select="tctypes:ToolOutput/tctypes:REPROG_SIGNATURE_SIZE[child::tctypes:Name='Signed_tag2']/tctypes:Value" />
	
	<xsl:variable name="RT_CERTIFICATE_SIZE" select="tctypes:ToolOutput/tctypes:REPROG_CERTIFICATE_SIZE[child::tctypes:Name='CertificateLength']/tctypes:Value" />
    
</xsl:stylesheet>