<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainExtractionLib.xslt" />
  <xsl:import href="ToolChainEnvironmentExtraction.xslt" />
  <xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
  <xsl:preserve-space elements="*" />
  <!-- Parameter for Usecase-xml and PST-Libray -->
  <xsl:param name="PLibraryXML" />
  <xsl:param name="PUseCaseXML" />
  <!-- Variables for UsecaseData and Libraryfile -->
  <xsl:variable name="LibraryXML" select="$PLibraryXML" />
  <xsl:variable name="UseCaseXML" select="$PUseCaseXML" />

  <xsl:template match="/">
    <ToolInput>
      <Mode>Script Generator : Check File exists</Mode>
      <Input>
        <WorkingDirectory>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
        </WorkingDirectory>
        <Scripts>
          <Script>
            <Write2PSTLib>False</Write2PSTLib>
            <Key>CBLITE_FLAG</Key>
            <Comment>Check CBLite file exists and update the CBLITE_FLAG</Comment>
            <ScriptTemplate>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_CHECK_FILE_EXIST'" />
              </xsl:call-template>
            </ScriptTemplate>
            <DataBase>
               <FileToCheck><xsl:call-template name="FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'CBLITE_HEXFILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'CBLITE_HEXFILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></FileToCheck>
            </DataBase>
          </Script>
        </Scripts>
      </Input>
      <CallInformation>
        <ToolName></ToolName>
        <CallType></CallType>
        <ToolVersion></ToolVersion>
        <ToolLocation></ToolLocation>
        <InputVerification></InputVerification>
      </CallInformation>
    </ToolInput>
  </xsl:template>
</xsl:stylesheet>
