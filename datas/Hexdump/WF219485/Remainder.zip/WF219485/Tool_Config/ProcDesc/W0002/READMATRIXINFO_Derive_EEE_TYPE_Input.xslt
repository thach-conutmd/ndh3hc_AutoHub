 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Derive EEE_TYPE value</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Default EEE_TYPE Value</DefaultValueMessage>
     	<ConfigFile>
			<Name><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'EEE_TYPE_MATRIX_NAME'"/></xsl:call-template></Name>
			<Directory>
				<xsl:call-template name="GetMatrixPath"></xsl:call-template></Directory>				
		</ConfigFile>	
		<Variables>
			<Variable>
				<Name>FEE_EMULATION_TYPE_HSM</Name>
				<Value>
                <xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'FEE_EMULATION_TYPE_HSM'"/></xsl:call-template>
        </Value>
			</Variable>
			<Variable>
				<Name>FEE_EMULATION_TYPE_HOST</Name>
				<Value>
                <xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'FEE_EMULATION_TYPE_HOST'"/></xsl:call-template>
        </Value>
			</Variable>
		</Variables> 
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
