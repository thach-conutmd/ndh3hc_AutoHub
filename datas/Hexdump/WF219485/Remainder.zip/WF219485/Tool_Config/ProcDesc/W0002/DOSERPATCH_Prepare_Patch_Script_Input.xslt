<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<xsl:param name="PInputFileClassID_AddressList" />
	<xsl:param name="PInputFileClassID_A2L_File" />
	<xsl:param name="PInputFileClassID_FdefList" />

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Prepare DoSerPatch Script</Mode>
			<Input>
			
				<!-- Place holder for Working directory -->
				<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
				<!-- Source template file contains the path for the patch key id file of ped/hexmod-->
				<SourceTemplateFile>
					<Location>
					<xsl:call-template name="GetConfigFolder"></xsl:call-template>
						<xsl:value-of select="'\'"/> 
					<xsl:call-template name="RunTime_Data_Value">
					        <xsl:with-param name="DataClassID" select="'PatchPath'" />
           				 </xsl:call-template>
					</Location>
				</SourceTemplateFile>
				<!-- Target template file creates the temporary patch key id file of ped/hexmod for runtime execution-->
				<TargetTemplateFile>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
						<Name>TmpPatchKeyID.xml</Name>
					</Location>
				</TargetTemplateFile>
				<!-- Script: If the patch key id content has to be extracted from Library or ToolChainUsecase.xml file-->
				<!-- If the script is available in the Library or ToolChainUsecase.xml file then File Location is -->
				<!-- not required to be provided in the <SourceTemplateFile> node.-->
				<!-- If the script is not available in the <SourceTemplateFile> node then script node loaded from the Library or ToolChainUsecase.xml file -->
				<!-- Script content is optional -->
				<Script>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'PATCH_KEY_SCRIPT'" />
					</xsl:call-template>
				</Script>
				<!-- ScriptType is the placeholder to provide Hexmod/Ped for the patch script, if its empty, then PED is defualt. -->
				<ScriptType>Hexmod</ScriptType>
				<Files>
					<!-- Files required for the Patch script execution -->
					<!-- Placeholder for the ADL File/log file/A2L file/DCM file,etc.,  -->
					<!-- Regular Expression can be provided for the Label Names as "$Label" in the Expression  -->
					<File>
						<FileClassID>ADL_File</FileClassID>
						<FileClassName>ADL_File</FileClassName>
						<Location>
							<Directory>
                					<xsl:call-template name="FileList_GetFileDirectory" >
					   <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
					   <xsl:with-param name="GetValue" select="'yes'"/> 
					   </xsl:call-template>
             					</Directory>
							<Name><xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template></Name>
						</Location>
						<RegEx><![CDATA[ $Label \s*(?'Value'([0-9A-Za-z]*))]]></RegEx>
					</File>
					<File>
						<FileClassID>A2L_FILE</FileClassID>
						<FileClassName>A2L_FILE</FileClassName>
						<Location>
							<Directory>
        						<xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'A2L_FILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>
              						</Directory>
							<Name><xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'A2L_FILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template></Name>
						</Location>
						<RegEx><![CDATA[ /begin [A-Za-z_]+\s*\n\s*[ \t] $Label *[\S  ]*\s*[\S ]*\s*[\S ]*\s*(?'Value'(0x[0-9A-Za-z]*))]]></RegEx>
					</File>
					<!-- Placeholder for the FileClassID should be attribute "Type" of the <GETSCRIPT_L> command for Hexmod Script -->
					<!-- Placeholder for the FileClassID should be last parameter of the getscript_l command for Ped Script  -->
					<!-- <File>
						<FileClassID>FdefList</FileClassID>
						<FileClassName>FdefList</FileClassName>
						<Location>
							<Directory>
               							<xsl:call-template name="FileList_GetFileDirectory" >
	       							<xsl:with-param name="FileClassID" select="FdefList"/>
	       							<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template>
              						</Directory>
							<Name>
								<xsl:call-template name="FileList_GetFileName" >
								<xsl:with-param name="FileClassID" select="FdefList"/>
								<xsl:with-param name="GetValue" select="'yes'"/>
								</xsl:call-template>
							</Name>
						</Location>
						<RegEx><![CDATA[\s*\S*$Label\s*\S*]]></RegEx>						
					</File>		-->			
					<File>
						<FileClassID>LogFile</FileClassID>
						<FileClassName>LogFile</FileClassName>
						<Location>
							<Directory>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              </Directory>
							<Name>Scriptlogfile.log</Name>
						</Location>
					</File>
				</Files>
				<LogFileAnalyser>
					<!-- Placeholder to analyse the log file  -->
					<Files>
						<File>
							<Classification>Patch-HexCode</Classification>
							<Key>PATCH_HEX_CODE</Key>
							<Directory>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              </Directory>
							<Name>Scriptlogfile.log</Name>
						</File>
					</Files>
				</LogFileAnalyser>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
