 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <Input>
		<Mode>Delete File TOFLOW.TXT and PatInf_FlowJobNumber.txt</Mode>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
   		<Files>  

	<!--		<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'TOFLOW.TXT'"/></File>
			<File><xsl:value-of select="'T:\zec\003\Patches\Script_Log\PatInf_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.txt'"/></File>	 -->								
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\PatInf_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.txt'"/></File>									
		</Files>		
		
		<CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>
     </Input>     	
   </xsl:template>
</xsl:stylesheet>
