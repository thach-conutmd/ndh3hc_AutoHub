<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt" />
	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML" />
	<xsl:output method="xml" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />


  <xsl:variable name="RT_Knownoutput_log"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='Hex_Compare_Known_File']/tctypes:Location"/>
  <xsl:variable name="RT_Unknownoutput_log"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='Hex_Compare_UnKnown_File']/tctypes:Location"/>
  <xsl:variable name="RT_Knownoutput_log_To_WorkFlow"	select="tctypes:ToolOutput/tctypes:Output/tctypes:DataToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='HEX_CMP']/tctypes:Data"/>
  <xsl:variable name="RT_Unknownoutput_log_To_WorkFlow"	select="tctypes:ToolOutput/tctypes:Output/tctypes:DataToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='HEX_CMP_UN']/tctypes:Data"/>
  <!-- Duplicate fileclassID update to runtimeinformation -->
  <xsl:variable name="RT_HEX_CMP"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='Hex_Compare_Known_File']/tctypes:Location"/>
  <xsl:variable name="RT_HEX_CMP_UN"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='Hex_Compare_UnKnown_File']/tctypes:Location"/>
  

</xsl:stylesheet>