 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<ResultingFiles>
					<File>
						<FileClassID>BC_GEN_Output</FileClassID>
						<FileClassName>BC_GEN_Output</FileClassName>
						<Location>
							<Directory>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              </Directory>
							<Name>
                <xsl:call-template name="GetSoftwareName"></xsl:call-template>
                <xsl:value-of select="'_Check_BC_Gen.log'"/>
              </Name>
							
						</Location>
					</File>
					 <File>
						<FileClassID>PatInf</FileClassID>
						<FileClassName>PatInf</FileClassName>
						<Location>
							<Directory>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              </Directory>
              <Name>
                <xsl:value-of select="'PatInf_'"/>
                <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
                <xsl:value-of select="'.txt'"/>
              </Name>
						</Location>
					</File>
		<!--			<File>
						<FileClassID>PatInf_ZecArea</FileClassID>
						<FileClassName>PatInf</FileClassName>
						<Location>
							<Directory>
                <xsl:value-of select="'T:\zec\'"/>
                <xsl:call-template name="GetCustomerGroup"></xsl:call-template>
                <xsl:value-of select="'\Patches\script_log'"/></Directory>
							<Name>
                <xsl:value-of select="'PatInf_'"/>
                <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
                <xsl:value-of select="'.txt'"/>
              </Name>					
						</Location>
					</File>	  -->
			</ResultingFiles>
    <DataToWorkFlow>
        <WorkFlowData>
          <WorkFlowID>PAT_INF</WorkFlowID>
          <WorkFlowName>PAT_INF</WorkFlowName>
          <Data>
            <DataClassID>FileName</DataClassID>
            <DataClassName>PAT_INF</DataClassName>
            <DataValue>
              <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              <xsl:value-of select="'\'"/>
             <xsl:value-of select="'PatInf_'"/>
	       <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
                <xsl:value-of select="'.txt'"/>
             
            </DataValue>
            <DataType>String</DataType>
          </Data>
        </WorkFlowData>
      </DataToWorkFlow> 
		</Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
  </xsl:template>
</xsl:stylesheet>
