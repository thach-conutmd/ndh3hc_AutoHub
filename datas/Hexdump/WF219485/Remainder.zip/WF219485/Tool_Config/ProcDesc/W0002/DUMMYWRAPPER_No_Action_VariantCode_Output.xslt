<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 
<xsl:variable name="NumberOfVariants" select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants" />
 
 
    <xsl:template match="/">
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
		<ResultingFile>
		          <Directory>
		            <xsl:call-template name="GetWorkingDirectory">
		            </xsl:call-template>
		          </Directory>
		          <Name>
				   <xsl:choose>
						<xsl:when test="$NumberOfVariants='0'">
							<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
							<xsl:value-of select="'_Patched'"/><xsl:value-of select="'.hex'"/>
						</xsl:when>
						<xsl:when test="$NumberOfVariants='1'">
							<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
							<xsl:value-of select="'_Patched_1.hex'"/>
						</xsl:when>
					</xsl:choose>
				</Name>
        	</ResultingFile>
		</Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
  </xsl:template>
</xsl:stylesheet>
