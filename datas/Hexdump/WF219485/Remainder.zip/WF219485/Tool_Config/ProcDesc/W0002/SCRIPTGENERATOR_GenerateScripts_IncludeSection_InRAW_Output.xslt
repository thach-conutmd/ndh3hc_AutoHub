 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:template match="/">

		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				<ResultingFiles>
					<File>
						<FileClassID>RawFileUpdated</FileClassID>
						<FileClassName>RawFileUpdated</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:call-template name="RunTime_Data_Value">	
									<xsl:with-param name="DataClassID" select="'RAWMCSVersion'" />								
								</xsl:call-template>
								<xsl:value-of select="'.raw'" />
							</Name>
						</Location>
					</File>
				</ResultingFiles>
				<Scripts/>
				<PST_Library>
				</PST_Library>
			</Output>
			<ReturnInformation>
				<ReturnCode/>
				<TimeStart/>
				<TimeFinish/>
				<ErrorInformation>
					<ErrorNumber/>
					<ErrorMessage/>
				</ErrorInformation>
			</ReturnInformation>    		
		</ToolOutput> 

	</xsl:template>
</xsl:stylesheet>
