 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" indent="yes"
			cdata-section-elements="Key SearchExpression"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 

	<xsl:template match="/">
		<ToolInput>
			<Mode>Substitute Values and create Hexcode log file</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory><xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'FSW_FEE_BLOCK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
					</Directory>
					<Name><xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'FSW_FEE_BLOCK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
					</Name>
				</SourceTemplateFile>
				<TargetTemplateFile>
					<Directory><xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'FSW_FEE_BLOCK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
					</Directory>
					<Name><xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'FSW_FEE_BLOCK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
					</Name>
				</TargetTemplateFile>
				<Script>
				</Script>
				<List></List>
				<CompleteFileCheckforVariables>1</CompleteFileCheckforVariables>
				<Variables>
					 <xsl:call-template name="CreateVariableList">
						<xsl:with-param name="File">
							<xsl:call-template name="GetConfigFolder"></xsl:call-template>
							     <xsl:value-of select="'\'" />
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'Fee_VariableList'"/>
							</xsl:call-template>
						</xsl:with-param>
					 </xsl:call-template>
				</Variables>
			</Input>  
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>