<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 
 <xsl:variable name="RT_ENCRYPTION_CONTEXT_KEY" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ENCRYPTION_CONTEXT_KEY']/tctypes:Value"/>
 <xsl:variable name="RT_ENCRYPTION_LABEL_SLOT" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='ENCRYPTION_LABEL_SLOT']/tctypes:Value"/>
		


</xsl:stylesheet>