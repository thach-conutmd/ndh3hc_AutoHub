 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="Flash0Required">
	<xsl:call-template name="GetFlash0_Required"></xsl:call-template>
 </xsl:variable>

    <xsl:template match="/">
    
    <ToolInput>
    
    <Mode>HexModX - CleanUp Hexfile</Mode>
    
    <HexModeInput>
    
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>OutputXML</Module>
			<Module>CleanUpXML</Module>
			<xsl:if test="$Flash0Required='1'">
				<Module>CleanUpXMLHSM0</Module>				
				<Module>CleanUpXMLHSM1</Module>	
			</xsl:if>
		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_CleanUp_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
			
     		<Script>
			<xsl:if test="$Flash0Required='1'">
				<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_MAIN_XML'"/></xsl:call-template>
			</xsl:if>	
			<xsl:if test="$Flash0Required='0'">
     		<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_WITHOUT_HSM_MAIN_XML'"/></xsl:call-template>
			</xsl:if>
			</Script>
					
			
			
     		<Variables>
				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>				
				<Variable>
					<Name>HEXMOD_CLEANUP_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>	
				<xsl:if test="$Flash0Required='1'">
				<Variable>
					<Name>HEXMOD_CLEANUP_XML_NAME_HSM0</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_HSM0_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>	
				<Variable>
					<Name>HEXMOD_CLEANUP_XML_NAME_HSM1</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_CLEANUP_HSM1_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>	
				</xsl:if>
		</Variables> 
     	</MainXML>
     	
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_CLEANUP_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>

       			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
 			</Variables>     	
 			
	</InputXML>
	
    <!-- Output Config-->
    <OutputXML>
      		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_CLEANUP_OUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CLEANUP_HEXFILE_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/>
						   <xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
						   <xsl:value-of select="'_c.hex'"/></Value>        
				</Variable> 
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				
      		</Variables>
      		
 	</OutputXML> 	     	
    <!-- CleanUpXML Config-->
    <CleanUpXML>
      		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_CLEANUP_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_HEXFILE_CLEANUP_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>START_ADDRESS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'XADDRESS'"/></xsl:call-template></Value>
				</Variable>
      		</Variables>
      		
 	</CleanUpXML> 
	
	<xsl:if test="$Flash0Required='1'">
	<!-- CleanUpXML HSm0 Config-->
    <CleanUpXMLHSM0>
      		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_CLEANUP_HSM0_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_HEXFILE_CLEANUP_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>START_ADDRESS</Name>
					<Value>
					 <xsl:call-template name="GetHSM_STARTADDRESS">
						<xsl:with-param name="BlockName" select="'HSM0'"></xsl:with-param>
						<xsl:with-param name="File">
						 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						  <xsl:value-of select="'\'"/>
						 <xsl:value-of select="'FSW_AddressModel.xml'"/>
						</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
      		</Variables>
      		
 	</CleanUpXMLHSM0>
	<!-- CleanUpXML HSM1 Config-->
    <CleanUpXMLHSM1>
      		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_CLEANUP_HSM1_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_HEXFILE_CLEANUP_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>START_ADDRESS</Name>
					<Value>						
						 <xsl:call-template name="GetHSM_STARTADDRESS">
						<xsl:with-param name="BlockName" select="'HSM1'"></xsl:with-param>
						<xsl:with-param name="File">
						 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						  <xsl:value-of select="'\'"/>
						 <xsl:value-of select="'FSW_AddressModel.xml'"/>
						</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
      		</Variables>
      		
 	</CleanUpXMLHSM1>
	</xsl:if>
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_CLEANUP_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     		<CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
      <xsl:call-template name="RunTime_Tool_Path">
        <xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
      </xsl:call-template>		
		</ToolLocation>
		<InputVerification></InputVerification>
		</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
