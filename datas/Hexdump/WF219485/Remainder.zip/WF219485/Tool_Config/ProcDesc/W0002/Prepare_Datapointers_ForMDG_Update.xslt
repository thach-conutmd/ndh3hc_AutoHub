<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

  <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_DATA_POINTERS_FILE" select="tctypes:ToolOutput/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='DATAPOINTER_Output']/tctypes:Location" />
 <xsl:variable name="RT_CHECKSUMS_XMLFILE" select="tctypes:ToolOutput/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='HEXMODX_CHECKSUM_XML']/tctypes:Location" />
 
 <xsl:variable name="RT_HEXMODX_CHECKSUM_SCRIPT" select="tctypes:ToolOutput/tctypes:PST_Library/tctypes:Item[child::tctypes:ID='HEXMODX_CHECKSUM_SCRIPT_TEMPLATE']/tctypes:Value"/>
 <xsl:variable name="RT_REPROG_DATABLOCKS_TEMPLATE" select="tctypes:ToolOutput/tctypes:PST_Library/tctypes:Item[child::tctypes:ID='REPROG_DATABLOCKS_TEMPLATE']/tctypes:Value"/> 
  
  <xsl:variable name="RT_SignTool_Reprog_HashValue" select="tctypes:ToolOutput/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='REPROG_UNSIGNED_TXTFILE']/tctypes:Location" />
  
 <!-- <xsl:variable name="RT_REPROG_DATABLOCKS_TEMPLATE_Flash0" select="tctypes:ToolOutput/tctypes:PST_Library/tctypes:Item[child::tctypes:ID='REPROG_DATABLOCKS_FLASH0_TEMPLATE']/tctypes:Value"/>  -->
  
</xsl:stylesheet>