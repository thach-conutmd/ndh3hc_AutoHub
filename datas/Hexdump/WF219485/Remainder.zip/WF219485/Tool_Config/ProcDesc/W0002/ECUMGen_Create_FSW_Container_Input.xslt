<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
  <xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression"/>
  <xsl:preserve-space elements="*"/>

  <!-- Parameter for Usecase-xml and PST-Libray -->
  <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

  <!-- Variables for UsecaseData and Libraryfile -->
  <xsl:variable name="LibraryXML" select="$PLibraryXML"/>
  <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 

  <xsl:template match="/">
    <ToolInput>
      <Mode>Create ECU-MEM-Container</Mode>
      <ECUMGenInput>
        <WorkingDirectory>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
        </WorkingDirectory>
        			<CNT_FileClassID>
          				<xsl:value-of select="'FSW_CONT'"/>
        			</CNT_FileClassID>		
        <!-- Run Tool in Batch-Mode (Silent) -->
        <BatchMode>True</BatchMode>
        <!-- RAW-Template -->
        <RAW>
          <TemplateFile>
            <Directory>
					<xsl:call-template name="GetWorkingDirectory">
					</xsl:call-template>
			</Directory>
            <Name><xsl:call-template name="RunTime_Data_Value">
			<xsl:with-param name="DataClassID" select="'RawFileNameUpdated'"/>					
				</xsl:call-template>
			</Name>
          </TemplateFile>
          <!-- Script-->
          <Script></Script>

          <!-- Use Extern RAW-->
          <UseExternRAW>1</UseExternRAW>

          <!-- Fetch the RAW file version from usecase xml-->
          <RAW_Version></RAW_Version>

        </RAW>
        <!-- MCS-Template -->
        <MCS>
          <!-- Template-File-->
          <TemplateFile>
            <Directory>
             <xsl:call-template name="GetRawMcsVersionPath"></xsl:call-template>
            </Directory>
            <Name><xsl:call-template name="RunTime_Data_Value">
			<xsl:with-param name="DataClassID" select="'RAWMCSVersion'"/>					
			</xsl:call-template>
		<xsl:value-of select="'.mcs'" /></Name>
          </TemplateFile>
          <!-- Script-->
          <Script></Script>

          <!-- Use Extern MCS-->
          <UseExternMCS>1</UseExternMCS>

          <!-- Fetch the MCS file version from usecase xml-->
          <MCS_Version></MCS_Version>

          <!-- Optional Variable List file info -->
          <MCS_VARIABLE_LIST>
          </MCS_VARIABLE_LIST>

          <!-- Version of the Variable List File  -->
          <MCS_VARIABLE_LIST_VERSION>
            <!--xsl:call-template name="GetVarilableListVersion"></xsl:call-template-->
          </MCS_VARIABLE_LIST_VERSION>

          <!-- Madatory node for Source for Variable List file info . Note : Directory and Name can be empty-->
          <MCS_VARIABLE_LIST_SOURCE>
            <Directory></Directory>
            <Name></Name>
          </MCS_VARIABLE_LIST_SOURCE>


          <!--List of variables-->
          <Variables>         
        
	    				
	  			  
	  		  <Variable>
	  					<Name>HEXFILE_SIGNATURE</Name>
	  					<Value>
	  					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
	  					<xsl:value-of select="'\Signed_tag1.hex'"/>
	  								</Value>
	  				</Variable>
					<Variable>
	  					<Name>HEXFILE_CERTIFICATE</Name>
	  					<Value>
	  					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
	  					<xsl:value-of select="'\Certificate.hex'"/>
	  								</Value>
	  				</Variable>
	  			    <Variable>
	  					<Name>HEXFILE_SIGNATURE_0</Name>
	  					<Value>
	  					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
	  					<xsl:value-of select="'\Signed_tag2.hex'"/>
	  								
	  								</Value>
	  				</Variable>
					
					 <Variable>
	  					<Name>HEXFILE_SIGNATURE_0_Dummy</Name>
	  					<Value>
	  					<xsl:call-template name="GetWrapperPath"></xsl:call-template>
	  					<xsl:value-of select="'\Signed_tag2.hex'"/>
	  								
	  								</Value>
	  				</Variable>	
					
					 <Variable>
	  					<Name>HEXFILE_FLASH_0_Dummy</Name>
	  					<Value>
	  					<xsl:call-template name="GetWrapperPath"></xsl:call-template>
	  					<xsl:value-of select="'\Dummy_FLASH_0.hex'"/>
	  								
	  								</Value>
	  				</Variable>
		
          
          
            <xsl:call-template name="CreateVariableList" >
              <xsl:with-param name="File">
                  <xsl:call-template name="GetRawMcsVersionPath"></xsl:call-template>
                <xsl:value-of select="'\'" />
                  <xsl:call-template name="RunTime_Data_Value">
		  		<xsl:with-param name="DataClassID" select="'VariableListFile'"/>					
		  			</xsl:call-template>
				<xsl:value-of select="'.xml'" />
              </xsl:with-param>
            </xsl:call-template>



          </Variables>
        </MCS>
        <!-- Log-Files for Logfile-Analyzing-->
        <LogFileAnalyser>
          <Files>
          </Files>
        </LogFileAnalyser>
        <PST_Library>
        </PST_Library>
      </ECUMGenInput>
      <CallInformation>
        <ToolName>ECUMGEN_VERSION</ToolName>
        <CallType></CallType>
        <ToolVersion>1v1a</ToolVersion>
        <!-- Path/Name of ECUMGen-Tool-->
		<ToolLocation>
			      <xsl:call-template name="RunTime_Tool_Path">
			        <xsl:with-param name="ToolName" select="'ECUMGEN_VERSION'"/>
			</xsl:call-template>
		</ToolLocation>
        <InputVerification></InputVerification>
      </CallInformation>
    </ToolInput>
  </xsl:template>
</xsl:stylesheet>
