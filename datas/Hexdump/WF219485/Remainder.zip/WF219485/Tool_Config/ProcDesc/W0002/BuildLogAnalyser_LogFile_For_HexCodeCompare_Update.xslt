<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

  <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_BC_Gen_log"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='BC_GEN_Output']/tctypes:Location"/>
  <xsl:variable name="RT_PAT_INF_To_WorkFlow" select="tctypes:ToolOutput/tctypes:Output/tctypes:DataToWorkFlow/tctypes:WorkFlowData[child::tctypes:WorkFlowID='PAT_INF']/tctypes:Data"/> 
  <!-- Duplicate addition of PAT_INF to runtime section as LWS looks into RunTimeInformation -->
  <xsl:variable name="RT_PAT_INF" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='PatInf']/tctypes:Location"/> 
</xsl:stylesheet>