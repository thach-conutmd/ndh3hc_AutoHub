<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt"/>

	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML"/>

	<xsl:output method="xml"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:variable name="RT_PIB_ENDADDRESS" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='PIB_ENDADDRESS_FOR_GUAM']/tctypes:Value"/>
 <xsl:variable name="RT_FSW_DPTR_CONFIG" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFile"/> 
	
</xsl:stylesheet>