 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolInput>
		<Mode>Read Merged Config-File</Mode>
		<Files>
			<ConfigFile>
				<Directory><xsl:call-template name="FileList_GetFileDirectory" >
					<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'"/>
					<xsl:with-param name="GetValue" select="'yes'"/>
					</xsl:call-template></Directory>
				<Name><xsl:call-template name="FileList_GetFileName" >
					<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'"/>
					<xsl:with-param name="GetValue" select="'yes'"/>
					</xsl:call-template></Name>
			</ConfigFile>
			<LogFile>
				<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
				<Name><xsl:value-of select="'MergedConfig.log'"/></Name>
			</LogFile>
		</Files>
		<XPATHS>
			<MergedConfig_ABMBlocks>
					<xsl:value-of select="'/CONF/CFGEXP/ALTERNATE_BOOT_MODE'"/>
			</MergedConfig_ABMBlocks>		
			<MergedConfig_ModeType>
					<xsl:value-of select="'/CONF/CFGEXP/CFGEXP_ENDIAN_TYPE'"/>
			</MergedConfig_ModeType>		
			<MergedConfig_SBBlock_Address>
					<xsl:value-of select="'/CONF/CFGEXP/CFGEXP_PRJ_START'"/>
			</MergedConfig_SBBlock_Address>
		</XPATHS>
		 <CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation></ToolLocation>
			<InputVerification></InputVerification>
		 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
