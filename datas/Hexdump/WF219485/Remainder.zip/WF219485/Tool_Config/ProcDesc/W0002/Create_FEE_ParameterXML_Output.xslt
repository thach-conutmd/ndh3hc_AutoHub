 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression Value"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

   <xsl:template match="/">
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<ResultingFiles>
				<File>		
						<FileClassID>FEE_Report_ParaSet_File</FileClassID>
						<FileClassName>FEE_Report_ParaSet_File</FileClassName>
						<Location>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'Output_FEE_Paraset.xml'"/></Name>
					</Location>
				</File>			
    		</ResultingFiles>    		
		</Output>
		
			<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
  </xsl:template>
</xsl:stylesheet>
