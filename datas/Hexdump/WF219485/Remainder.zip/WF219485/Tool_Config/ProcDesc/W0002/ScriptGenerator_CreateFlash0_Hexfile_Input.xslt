 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt"/>
	<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
	<xsl:preserve-space elements="*"/>

	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML"/>
	<xsl:param name="PUseCaseXML"/>

	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	 <!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
	 <xsl:variable name="ModeType">	 
		 
	 </xsl:variable>

	
	<xsl:template match="/">

		<ToolInput>
			<Mode>Generate HexmodX Script to Create Flash0 Hexfile</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"/>
				</WorkingDirectory>
				<Scripts>
					<Script>
						<Write2PSTLib>False</Write2PSTLib>
						<Key>SCRIPT_CREATE_FLASH_0_HEXFILE</Key>
						<Comment>Script for creation of Flash0 Hexfile </Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_HEXMODX_CREATE_FLASH_0_HEXFILE'"/>
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>
								<EndianType>
										<xsl:call-template name="CheckJDPOrInfineon">
											<xsl:with-param name="ModeType">
												<xsl:call-template name="GetEnvironmentValue">
													<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
												</xsl:call-template>			 
											</xsl:with-param>			
										</xsl:call-template>
								</EndianType>
								<Offset>
									<xsl:call-template name="GetEnvironmentValue">
													<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET'"/>
									</xsl:call-template>
								</Offset>
								<InputFile>
									<xsl:call-template name="RunTime_FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
								</InputFile>
								<!-- SB block start address from merged config xml.-->
								<IbChainStartAddr>
									<xsl:call-template name="GetEnvironmentValue">
										<xsl:with-param name="LookUpItem" select="'XADDRESS'"/>
									</xsl:call-template>
								</IbChainStartAddr>
								<Hsm0StartAddr>
									 <xsl:call-template name="GetHSM_STARTADDRESS">
										<xsl:with-param name="BlockName" select="'HSM0_FLASH0'"></xsl:with-param>
										<xsl:with-param name="File">
										 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										  <xsl:value-of select="'\'"/>
										 <xsl:value-of select="'FSW_AddressModel.xml'"/>
										</xsl:with-param>
								</xsl:call-template>		
								</Hsm0StartAddr>
								<Hsm0EndAddr>
									 <xsl:call-template name="GetHSM_ENDADDRESS">
									<xsl:with-param name="BlockName" select="'HSM0'"></xsl:with-param>
									<xsl:with-param name="File">
									 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									  <xsl:value-of select="'\'"/>
									 <xsl:value-of select="'FSW_AddressModel.xml'"/>
									</xsl:with-param>
								</xsl:call-template>
								</Hsm0EndAddr>
								<Hsm1StartAddr>
									 <xsl:call-template name="GetHSM_STARTADDRESS">
										<xsl:with-param name="BlockName" select="'HSM1_FLASH0'"></xsl:with-param>
										<xsl:with-param name="File">
										 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										  <xsl:value-of select="'\'"/>
										 <xsl:value-of select="'FSW_AddressModel.xml'"/>
										</xsl:with-param>
								</xsl:call-template>	
								</Hsm1StartAddr>
								<Hsm1EndAddr>
									 <xsl:call-template name="GetHSM_ENDADDRESS">
								<xsl:with-param name="BlockName" select="'HSM1_FLASH0'"></xsl:with-param>
								<xsl:with-param name="File">
								 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								  <xsl:value-of select="'\'"/>
								 <xsl:value-of select="'FSW_AddressModel.xml'"/>
								</xsl:with-param>
								</xsl:call-template>
								</Hsm1EndAddr>								
								<Asw0BlockId>
									<xsl:call-template name="GetASW0BLOCK_BLOCKID">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>	
								</Asw0BlockId>
								<TpBlockId>
									<xsl:call-template name="GetTPBLOCK_BLOCKID">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>
								</TpBlockId>
								<OutputFileFull>
									<xsl:value-of select="'Flash0_FullHexWithModASW0.hex'"/>
								</OutputFileFull>
								<OutputFileASW0>
									<xsl:value-of select="'Flash0_OnlyModASW0.hex'"/>
								</OutputFileASW0>
								<LogFile>									
									<xsl:value-of select="'HexmodX_Flash0.log'"/>
								</LogFile>
								<DetailedLogFull>									
									<xsl:value-of select="'Detailelog_FLASH0_FullHex.xml'"/>
								</DetailedLogFull>
								<DetailedLogASW>									
									<xsl:value-of select="'Detailelog_FLASH0.xml'"/>
								</DetailedLogASW>
								<FLASH_0_AdrMod>									
									<xsl:value-of select="'FLASH_0_AdrMod.xml'"/>
								</FLASH_0_AdrMod>
							</Datas>				
						</DataBase>
					</Script>
				</Scripts>
				<PST_Library>
				</PST_Library>
			</Input>  
			<CallInformation>
				<ToolName/>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>     	
	</xsl:template>
</xsl:stylesheet>
