<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

<!-- Parameter for Usecase-xml file -->
<xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
  <xsl:variable name="RT_UpdateOTP_Ref_InUseCase_Data" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:OTP_Ref"/>
  <xsl:variable name="RT_UpdateOTP_Ref_ToWorkFlow" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:OTP_Ref"/>
  <xsl:variable name="RT_Update_OTP_Ref_Code_To_UseCase" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:OTP_Ref_Code"/>
  <xsl:variable name="RT_Update_OTP_Ref_Code_To_WorkFlow" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:OTP_Ref_Code"/>
  <xsl:variable name="RT_OTP_Key" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:OTP_Key"/>
	
</xsl:stylesheet>