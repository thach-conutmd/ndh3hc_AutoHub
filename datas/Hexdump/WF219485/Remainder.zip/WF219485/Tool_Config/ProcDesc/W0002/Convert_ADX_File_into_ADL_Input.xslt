<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>Convert ADX File</Mode>
   <Input>
     	<SourceFile>
			<Directory>
				<xsl:call-template name="FileList_GetFileDirectory">
				<xsl:with-param name="FileClassID" select="'ADDRESSLIST'"/>
				<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Directory>
			<Name>
				<xsl:call-template name="FileList_GetFileName">
				<xsl:with-param name="FileClassID" select="'ADDRESSLIST'"/>
				<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Name>
		</SourceFile>
		<TargetFile>
				<Directory>
          <xsl:call-template name="FileList_GetFileDirectory" >
            <xsl:with-param name="FileClassID" select="'ADDRESSLIST'"/>
            <xsl:with-param name="GetValue" select="'yes'"/>
          </xsl:call-template>
				</Directory>
				<Name>
          <xsl:call-template name="FileList_GetFileName" >
            <xsl:with-param name="FileClassID" select="'ADDRESSLIST'"/>
            <xsl:with-param name="GetValue" select="'yes'"/>
            <xsl:with-param name="GetExtension" select="'no'"/>
          </xsl:call-template>
					<xsl:value-of select="'.adl'" />						
				</Name>
			<OverwriteTarget>1</OverwriteTarget>
			<DeleteSource>0</DeleteSource>
		</TargetFile>
		<Input_XML_Looping_XPath>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'MASTER_ELEMENT_XML'"/>
			</xsl:call-template>
		</Input_XML_Looping_XPath>
		<Input_XML_Data>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'ELEMENT_LIST'"/>
			</xsl:call-template>
		</Input_XML_Data>	
    </Input>  
    </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>