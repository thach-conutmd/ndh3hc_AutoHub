<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_HexMod_SignedHexfile_Complete"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='HexMod17_SignedHexfile_Complete']/tctypes:Location"/>
  <xsl:variable name="RT_RELEASEPST"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='RELEASEPST']/tctypes:Location"/>
<!-- <xsl:variable name="RT_A2L_FILE_CUST_ToUsecase"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='A2L_FILE_CUST']/tctypes:Location"/> -->
 
</xsl:stylesheet>