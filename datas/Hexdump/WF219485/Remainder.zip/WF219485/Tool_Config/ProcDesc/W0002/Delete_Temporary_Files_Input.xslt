 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <Input>
		<Mode>Delete temporary files</Mode>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
   		<Files>  
   		
				<!--other files-->
			<File><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'SGIDB1_PatchcheckInfo.xml'"/></File>			
					<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HexMod_Main_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.XML'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HexMod_Input_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.XML'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HexMod_Infoblock_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.XML'"/>
				</File>
				
				
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HexMod_PatchNCheck_Input_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.XML'"/>
				</File>
				
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HexModX_PatchNcheck_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.XML'"/>
				</File>
				
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HEXMOD_LOG_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.LOG'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HEXMODX_LOG_'"/>
					<xsl:call-template name="GetWorkFlowID"/>
					<xsl:value-of select="'.LOG'"/>
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'AddressModelInfo.xml'"/>										
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'NonBootBlocks.xml'"/>										
				</File>
				<File>
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'HSMBlocks.xml'"/>										
				</File>
		</Files>  
		<CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>
     </Input>     	
   </xsl:template>
</xsl:stylesheet>
