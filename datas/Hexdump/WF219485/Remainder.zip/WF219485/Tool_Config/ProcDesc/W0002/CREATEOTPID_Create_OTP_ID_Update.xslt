<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
 <xsl:variable name="RT_OTP_Key" select="tctypes:ToolOutput/tctypes:Output/tctypes:Result/tctypes:OTP_Key"/>
 <xsl:variable name="RT_OTP_Overview" select="tctypes:ToolOutput/tctypes:Output/tctypes:Result/tctypes:OTP_Overview"/> 
 
</xsl:stylesheet>