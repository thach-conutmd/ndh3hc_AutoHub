<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<!-- <xsl:param name="PRecentLoopCount"/> -->
	<!-- <xsl:variable name="CurrentIndex" select="$PRecentLoopCount"/> -->

	<xsl:template match="/">
		<ToolInput>
			<Mode>HexmodX - Seperate ASW0 and DS0</Mode>
			<HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>			
			<Module>OutputXML</Module>
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_SEPERATE_ASW0_DS0_BLOCK_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
  				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>

			</Variables>
     	</MainXML>
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_SEPERATE_ASW0_DS0_BLOCK_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE_NAME</Name>
						<Value>
								
								<!-- <xsl:call-template name="GetSoftwareName"/>   -->
								<!-- </xsl:call-template><xsl:value-of select="'_EOL'"/> -->
								<xsl:call-template name="RunTime_FileList_GetFileName" >
									<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
									<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
								</Value>
				</Variable>     			
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>		

	
	 <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_SEPERATE_ASW0_DS0_BLOCK_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>ASW0_OUTPUT_NAME</Name>
					<Value>
						<xsl:call-template name="GetSoftwareName"/>
						<xsl:value-of select="'_ASW0'" />
					</Value>
				</Variable>
				<Variable>
					<Name>ASW0_STARTADDRESS</Name>
					<Value>
						<xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>ASW0_LEN</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'ASW0_LENGTH'" />
					</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>DS0_OUTPUT_NAME</Name>
					<Value>
						<xsl:call-template name="GetSoftwareName"/>
						<xsl:value-of select="'_DS0'" />
					</Value>
				</Variable>
				<Variable>
					<Name>DS0_STARTADDRESS</Name>
					<Value>
						<xsl:call-template name="GetDS0BLOCK_STARTADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>DS0_LEN</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'DS0_LENGTH'" />
					</xsl:call-template>
					</Value>
				</Variable>
			</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
			</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput> 
	</xsl:template>
</xsl:stylesheet>
