 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
	 <xsl:variable name="ModeType">
		 <xsl:call-template name="CheckJDPOrInfineon">
			 <xsl:with-param name="ModeType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
				 </xsl:call-template>			 
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	 <!-- for  DEV5 = 1 and other dev will have value 0 -->
	 <xsl:variable name="DeviceType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE'"/>
				 </xsl:call-template>
	 </xsl:variable>

 <xsl:template match="/">

  <ToolInput>
    
    <Mode>Run_HexMod17 for Variant coding</Mode>

    <HexModeInput>
    
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		
		<Modules>
			<Module>MainXML</Module>
			<Module>Input</Module>
			<Module>Infoblock</Module>
			<xsl:if test="$ModeType='0'">
<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
				<Module>ABMXML</Module>

			</xsl:if>
			<Module>Output</Module>
			
		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_VC_MAIN_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
 				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.log'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
				  <Variable>
									<Name>HEXMOD_INFOBLOCK_XML_NAME</Name>
									<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
												</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
				<Variable>
													<Name>HEXMOD_ABM_XML_NAME</Name>
													<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_VC_ABM_'"/><xsl:call-template name="GetWorkFlowID">
																</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
			  	 
	   		</Variables>
       	</MainXML>
    	
     	<!-- Input Config-->
     	<Input>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_VC_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_INPUT_XML'"/></xsl:call-template></Script>
				
     		<Variables>
       			<Variable>
					<Name>INPUT_FILELIST</Name>
					<Value><xsl:call-template name="RunTime_Data_Value">
					<xsl:with-param name="DataClassID" select="'VDS_FILESLIST'"/>
					</xsl:call-template>
					</Value>
				</Variable>							
     		</Variables>     		   	
		</Input>

     	<Infoblock>
     	<TemplateFile>
	     			<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
	     			<Name><xsl:value-of select="'HEXMOD_VC_INFOBLOCK_'"/>
									<xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
	     		</TemplateFile>
	     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML'"/></xsl:call-template></Script>
     		<Variables>
  			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
      			<Variable>
					<Name>INFOBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INFOBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
    			<Variable>
					<Name>COMPATIBILITY_POINTER_LIST</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_IBAFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_IBAFTER_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_CHKFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_CHKFTER_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
    		</Variables>
     	</Infoblock>
     	
     	<!-- Output Config-->
		<Output>
		
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_VC_OUTPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_VARIANT_CODING_OUTPUT_XML'"/></xsl:call-template></Script>
				
     		<Variables>
     			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
								<xsl:value-of select="'_Variant.hex'"/>
							</Value>
				</Variable>
			</Variables>	
         </Output>
    
	
	
	
	<xsl:if test="$ModeType='0'">
	   	<!-- ABM Config-->
		<ABMXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_VC_ABM_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>ABMBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ABMBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>BMIBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BMI_BLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>				
				<Variable>
					<Name>DEVICE_TYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE_ABM'"/>
				 </xsl:call-template></Value>
				</Variable>
			</Variables>	
		</ABMXML>	
	</xsl:if>
		<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-FillGAP-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.log'"/></Name>
				</File>
			</Files>
		</LogFileAnalyser>
		<PST_Library>
		</PST_Library>
    </HexModeInput>  
    <CallInformation>
		<ToolName>HEXMOD17</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
			        <xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
      </xsl:call-template>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
