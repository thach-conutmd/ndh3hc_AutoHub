<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Read MERGED_CONFIG to GUAM informations</Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime> <!-- 10 Minutes-->
				<DateTimeInterval>1</DateTimeInterval> <!-- 1 = Minutes  / 0 = Seconds-->
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:call-template name="FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Name>
				</SourceTemplateFile>
				<ReadVaraibeList>
					<Variables>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_CBLITE_COMPILED_ADDRESS_START</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_CBLITE_COMPILED_ADDRESS_START</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_CBLITE_IN_REPROGCONTAINER_START</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_CBLITE_IN_REPROGCONTAINER_START</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_NEW_SECUMGR_SOURCE_START</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_NEW_SECUMGR_SOURCE_START</Xpath>
						</Variable>					
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_NEW_SECUMGR_SOURCE_END</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_NEW_SECUMGR_SOURCE_END</Xpath>
						</Variable>					
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_SECUMGR_SECSWUPDCORE/CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>HSM_PIB_ADDRESS</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_HSM/BLOCK[BLOCK_NAME='HSM_PIB']/BLOCK_ADR</Xpath>
						</Variable>				
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>HSM_PIB_LENGTH</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_HSM/BLOCK[BLOCK_NAME='HSM_PIB']/BLOCK_LEN</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>HSM_FDB_START</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_HSM/BLOCK[BLOCK_NAME='HSM_FACTORY_DATA']/BLOCK_ADR</Xpath>
						</Variable>		
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>HSM_FDB_OFFSET</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_HSM/BLOCK[BLOCK_NAME='HSM_FACTORY_DATA']/BLOCK_LEN</Xpath>
						</Variable>
					</Variables>
				</ReadVaraibeList>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
