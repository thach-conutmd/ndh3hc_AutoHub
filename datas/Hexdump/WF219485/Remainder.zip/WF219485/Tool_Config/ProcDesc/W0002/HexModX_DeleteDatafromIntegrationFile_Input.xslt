 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:template match="/">

    <ToolInput>
    <Mode>HexModX- Delete Data-IBs from IntegrationFile</Mode>

    <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>InfoBlockXML</Module>
			<Module>OutputXML</Module>
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_MAIN_XML'"/></xsl:call-template></Script>
     		<Variables>
 				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INFOBLOCK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Value>
				</Variable>
						<Variable>
							<Name>HEXMOD_OUTPUT_XML_NAME</Name>
							<Value>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								<xsl:value-of select="'\HEXMOD_OUTPUT_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>
								<xsl:value-of select="'.xml'" />
							</Value>
						</Variable>
			</Variables>
       	</MainXML>
     	<!-- InfoBlock - Config -->
     	<InfoBlockXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_InfoBlock_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_INFOBLOCK_XML'"/></xsl:call-template></Script>
     		<Variables>
			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
       			<Variable>
					<Name>XADDRESS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'XADDRESS'"/></xsl:call-template></Value>
							<Mandatory>True</Mandatory>	
				</Variable>
				<Variable>
					<Name>INFOBLOCK_DELETE_IB</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'INFOBLOCK_DELETE_DATA_IB'"/></xsl:call-template></Value>
							<Mandatory>True</Mandatory>	
				</Variable>

			</Variables>
      			
		</InfoBlockXML>
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
						<Name>MODETYPE</Name>
						<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
 			</Variables>     		   	
		</InputXML>
 		<!-- Output Config-->
		<OutputXML>
					<TemplateFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'HexMod_Output_'" />
								<xsl:call-template name="GetWorkFlowID"></xsl:call-template>.xml</Name>
					</TemplateFile>
					<Script>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMODX_DELETE_IB_OUTPUT_XML'" />
						</xsl:call-template>
					</Script>
					<Variables>
						<Variable>
							<Name>FILETYPE</Name>
							<Value>
								<xsl:call-template name="GetEnvironmentValue">
									<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'" />
								</xsl:call-template>
							</Value>
						</Variable>
						<Variable>
							<Name>HEXFILE</Name>
							<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\'" />
								<xsl:call-template name="GetSoftwareName"/>
								<xsl:value-of select="'_withoutData.hex'" />
							</Value>
						</Variable>
					</Variables>
				</OutputXML>
	<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
				<File>
				<Classification>HexMod17-Infoblock-Logfile</Classification>
				<Key>HEXMOD17_INFOBLOCK_DELETEBLOCKS_NORELINK_IGNORE_ERROR</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
			</Files>
		</LogFileAnalyser>	
		<PST_Library>
		</PST_Library>	
    </HexModeInput>  
    <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
			        <xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			      </xsl:call-template>
      
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
