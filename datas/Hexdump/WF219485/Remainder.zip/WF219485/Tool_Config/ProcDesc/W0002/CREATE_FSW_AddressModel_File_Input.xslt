 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


<xsl:variable name="Boot_Flag" select="/tctypes:UseCase/tctypes:Data/tctypes:BootContainerFlag" />

    <xsl:template match="/">
    <ToolInput>
		<Mode>FSW ADDRESSMODEL file creation</Mode>
		<Input>
	     	<SourceTemplateFile>
				<Directory></Directory>
				<Name></Name>
			</SourceTemplateFile>
			<TargetTemplateFile>
				<Directory></Directory>
				<Name></Name>
			</TargetTemplateFile>
			<Script>
			</Script>
			<ScriptMandatory>0</ScriptMandatory>
			<Variables></Variables>
			<CommandLine>								
					<xsl:value-of select="'&quot;'"/>
					<xsl:value-of select="'|'"/>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template> 
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'AddressModel.xml'"/>
					<xsl:value-of select="'|'"/>
					<xsl:call-template name="FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'FSW_DPTRCONFIG'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:call-template name="FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'FSW_DPTRCONFIG'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>			
					<xsl:value-of select="'|'"/>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template> 
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'FSW_AddressModel.xml'"/>
					
					<!-- Boot_Flag = 1 Exclude block list -->
					<xsl:if test="$Boot_Flag='1'">
						<xsl:value-of select="'|'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template> 
						<xsl:value-of select="'\'"/>
						<xsl:value-of select="'NonBootBlocks.xml'"/>
					</xsl:if>
					
					<xsl:value-of select="'|'"/>
					<xsl:value-of select="'&quot;'"/>					
			</CommandLine>
			<LogFileAnalyser>
				<Files>
					<File>
						<Classification></Classification>
						<Key></Key>
						<Directory></Directory>
						<Name></Name>
					</File>
				</Files>
			</LogFileAnalyser>	
		</Input>  
		<CallInformation>
			<ToolName>FSW_ADDRESSMODEL</ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
        <xsl:call-template name="RunTime_Tool_Path">
          <xsl:with-param name="ToolName" select="'FSW_ADDRESSMODEL'"/>
        </xsl:call-template>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
