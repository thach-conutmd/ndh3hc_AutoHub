<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
		 
	<xsl:template match="/">
		<ToolInput>
			<Mode>Run_SignTool17 from local GUAM </Mode>
			<SignToolRemoteInput>
				<InputFile>
					<Directory>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'HexMod_Flash0_GUAM_HashValue'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'HexMod_Flash0_GUAM_HashValue'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Name>
				</InputFile>
				<AdditionalInfo>
					<MODE Level="$Level1">ONLINE</MODE>
					<PINPATH Level="$Level1">./</PINPATH>
					<LASTRUN Level="$Level1">0</LASTRUN>
					<OID Level="$Level2">
						<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'MEMLAY_OID'"/>
						</xsl:call-template>
					</OID>
					<KEYPATH Level="$Level2">
						 <xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'MEMLAY_KEYPATH'"/>
						</xsl:call-template>
					</KEYPATH>
					<OID_PUB Level="$Level2">
						<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'MEMLAY_OID_PUB'"/>
						</xsl:call-template>
					</OID_PUB>
					<!-- Aditional info can be added if required -->					
				</AdditionalInfo>
				<WTS>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'TSAppCompat'" />
					</xsl:call-template>
				</WTS>
				<WorkFlowID><xsl:call-template name="GetWorkFlowID"></xsl:call-template></WorkFlowID>
			</SignToolRemoteInput>
			<CallInformation>
				<ToolName>SIGNTOOL</ToolName>
				<CallType></CallType>
				<ToolVersion>2v40</ToolVersion>
				<ToolLocation>              
					<Directory><xsl:value-of select="'C:\MDG1\Tprotpackage\HexmodX\bin\'"/></Directory>
					<Name><xsl:value-of select="'HexmodX.cmd'"/></Name>
				</ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>