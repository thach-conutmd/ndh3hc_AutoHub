 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="AddressModelFile" select="concat($WorkingDir, '\AddressModel_Release.xml')" />

<xsl:template match="/">

    <ToolInput>
    <Mode>Generate variant coding input file list</Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>

				<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>VARIANT_CODING_FILESLIST</Key>
				<Comment>Script for Linking Infoblocks of Hexfile</Comment>
				<ScriptTemplate>
				<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_VARIANT_CODING_INPUTS'" />
				</xsl:call-template>
				</ScriptTemplate>
				<DataBase>
					<LoopCount>
					<xsl:call-template name="Data_Value">
									<xsl:with-param name="ID" select="'NumberOfVariants'"/>
								</xsl:call-template>
					</LoopCount>
					<FileType>	
					<xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template>
					</FileType>
					<FileList>
					<xsl:call-template name="GetFileList"></xsl:call-template>
  					</FileList>
  					<VDS_BlockAddress>					
						<xsl:call-template name="Data_Value">
									<xsl:with-param name="ID" select="'VDS_STARTADDRESS'"/>
								</xsl:call-template>
					</VDS_BlockAddress>
					<MODETYPE>
						<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template>
					</MODETYPE>
			</DataBase>
			</Script>
          </Scripts>
			<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
