<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
  <xsl:output method="xml" indent="yes"
  cdata-section-elements="Key SearchExpression"/>
  <xsl:preserve-space elements="*"/>

  <!-- Parameter for Usecase-xml and PST-Libray -->
  <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

  <!-- Variables for UsecaseData and Libraryfile -->
  <xsl:variable name="LibraryXML" select="$PLibraryXML"/>
  <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
  <xsl:variable name="BuildMode" select="/tctypes:UseCase/tctypes:Data/tctypes:BuildMode"/>

  <xsl:template match="/">
    <ToolInput>
      <Mode>Analyse Log files from Tools</Mode>
      <Input>
        <WorkingDirectory>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
        </WorkingDirectory>
		<PatchinfoFile>
			<xsl:call-template name="Data_Value">
				<xsl:with-param name="ID" select="'PATCHINFO_FILE_PATH'"/>
			</xsl:call-template>
		</PatchinfoFile>
        <ConfigFile>
          <Directory>
            <xsl:call-template name="GetWrapperPath"></xsl:call-template>
          </Directory>
          <Name>BuildlogfileAnalyzerConfig.XML</Name>
        </ConfigFile>

        <ReferenceFiles>
          <File>
            <FileClassID>AddressList</FileClassID>
            <FileClassName>AddressList</FileClassName>
            <Location>
              <Directory>
                <xsl:call-template name="FileList_GetFileDirectory" >
                  <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
              </Directory>
              <Name>
                <xsl:call-template name="FileList_GetFileName" >
                  <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                  <xsl:with-param name="GetExtension" select="'no'"/>
                </xsl:call-template>
                <xsl:value-of select="'.adl'" />
              </Name>
            </Location>
          </File>
          <File>
            <FileClassID>A2L_FILE</FileClassID>
            <FileClassName>A2L_FILE</FileClassName>
            <Location>
              <Directory>
                <xsl:call-template name="FileList_GetFileDirectory" >
                  <xsl:with-param name="FileClassID" select="'A2L_FILE'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
              </Directory>
              <Name>
                <xsl:call-template name="FileList_GetFileName" >
                  <xsl:with-param name="FileClassID" select="'A2L_FILE'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
              </Name>
            </Location>
          </File>
        </ReferenceFiles>
        <List>
          <!-- Entry for Input Log files. -->        
          <Entry>
            <LogFile>
              <ApplicationName>HEXMOD17</ApplicationName>
              <Directory>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
              </Directory>
              <Name>
                 <xsl:value-of select="'HEXMODX_LOG_'" />
			   <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
			   <xsl:value-of select="'.LOG'" />
              </Name>
            </LogFile>
          </Entry>
         
	<Entry>
	            <LogFile>
	              <ApplicationName>HEXMOD17</ApplicationName>
	              <Directory>
	                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
	              </Directory>
	              <Name>
	                 <xsl:value-of select="'Patch_G_'" />
				   <xsl:call-template name="GetWorkFlowID"></xsl:call-template>
				   <xsl:value-of select="'.xml'" />
	              </Name>
	            </LogFile>
          </Entry>

          <LogFileAnalyser>
            <Files>
              <File>
                <Classification>BC Log Analyser</Classification>
                <Key></Key>
                <Directory>
                  <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                </Directory>
                <Name>
                  <xsl:value-of select="'BC_GENlog.log'" />
                </Name>
              </File>
              <File>
                <Classification>BC Log Analyser</Classification>
                <Key></Key>
                <Directory>
                  <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                </Directory>
                <Name>
                  <xsl:value-of select="'BC_GENOutput.txt'" />
                </Name>
              </File>
            </Files>
          </LogFileAnalyser>

        </List>
      </Input>
    </ToolInput>
  </xsl:template>
</xsl:stylesheet>