 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>
<xsl:param name="PPatchFSWID"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="PatchFSWID" select="$PPatchFSWID"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Run Patch SWTTNR </Mode>
     <HexModeInput>
	 
	 
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>SWTTNRInfoBlockXML</Module>			
			<Module>HSM0InfoBlockXML</Module>
			<Module>HSM1InfoBlockXML</Module>
			<Module>OutputXML</Module>
			
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
     		<Script>
				<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_MAIN_XML'"/></xsl:call-template>
			</Script>
				
     		<Variables>
  				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_PATCH_INFOBLOCK_WITH_SWTTNR_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INFOBLOCK_WITH_SWTTNR_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>				
				<Variable>
					<Name>HEXMODX_PATCH_INFOBLOCK_WITH_HSM1_AND_SWTTNR_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexModx_InfoBlock_For_HSM0_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_PATCH_INFOBLOCK_WITH_HSM2_AND_SWTTNR_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexModx_InfoBlock_For_HSM1_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>

			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config  for HEXMODX_PATCH_INFOBLOCK_WITH_SWTTNR_XML -->
     	<SWTTNRInfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_WITH_SWTTNR_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_SWTTNR_XML'"/></xsl:call-template></Script>
     		<Variables>
 			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
     			<Variable>
					<Name>INFOBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue"><xsl:with-param name="LookUpItem" select="'INFOBLOCKS'"/></xsl:call-template></Value>
					<Mandatory>True</Mandatory>	
			</Variable>
    			<Variable>
					<Name>SOFTWAREPARTNUMBER</Name>
					<Value><xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template></Value> 
					<Mandatory>True</Mandatory>	
			</Variable>					
			 <Variable>
				    <Name>COMPATIBILITY_POINTER_LIST</Name>
			            <Value><xsl:call-template name="GetEnvironmentValue">
				    <xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
			</Variable>			
			</Variables>
      	</SWTTNRInfoBlockXML>
				
		<!-- InfoBlock - Config  for HEXMODX_PATCH_INFOBLOCK_WITH_HSM1_AND_SWTTNR_XML -->
     	<HSM0InfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_For_HSM0_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_HSM1_AND_SWTTNR_XML'"/></xsl:call-template></Script>
     		<Variables>
 			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
     			<Variable>
					<Name>HSM0_STARTADDRESS</Name>
					<Value>					
						<xsl:call-template name="GetHSM_STARTADDRESS">
						<xsl:with-param name="BlockName" select="'HSM0'"></xsl:with-param>
						<xsl:with-param name="File">
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:value-of select="'FSW_AddressModel.xml'"/>
						</xsl:with-param>
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>	
				</Variable>				
    			<Variable>
					<Name>SOFTWAREPARTNUMBER</Name>
					<Value><xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template></Value> 
					<Mandatory>True</Mandatory>	
				</Variable>					
				<Variable>
				    <Name>COMPATIBILITY_POINTER_LIST</Name>
			            <Value><xsl:call-template name="GetEnvironmentValue">
				    <xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
				</Variable>			
			</Variables>
      	</HSM0InfoBlockXML>
		
		<!-- InfoBlock - Config  for HEXMODX_PATCH_INFOBLOCK_WITH_HSM2_AND_SWTTNR_XML -->
     	<HSM1InfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_For_HSM1_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INFOBLOCK_WITH_HSM2_AND_SWTTNR_XML'"/></xsl:call-template></Script>
     		<Variables>
 			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
     			<Variable>
					<Name>HSM1_STARTADDRESS</Name>
					<Value>					
						<xsl:call-template name="GetHSM_STARTADDRESS">
										<xsl:with-param name="BlockName" select="'HSM1'"></xsl:with-param>
										<xsl:with-param name="File">
										 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										  <xsl:value-of select="'\'"/>
										 <xsl:value-of select="'FSW_AddressModel.xml'"/>
										</xsl:with-param>
						</xsl:call-template>					
					</Value>
					<Mandatory>True</Mandatory>	
				</Variable>			
    			<Variable>
					<Name>SOFTWAREPARTNUMBER</Name>
					<Value><xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template></Value> 
					<Mandatory>True</Mandatory>	
				</Variable>					
				<Variable>
				    <Name>COMPATIBILITY_POINTER_LIST</Name>
			            <Value><xsl:call-template name="GetEnvironmentValue">
				    <xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
				</Variable>			
			</Variables>
      	</HSM1InfoBlockXML>
		
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Hexfile_Infotable_Patched'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Hexfile_Infotable_Patched'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
						<Mandatory>True</Mandatory>	
				</Variable>
     			<Variable>
					<Name>WORKING_DIRECTORY</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Value>
					<Mandatory>True</Mandatory>	
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>		

     <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_PATCH_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
						<Mandatory>True</Mandatory>	
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								<xsl:with-param name="GetExtension" select="'no'"/> 
								</xsl:call-template><xsl:value-of select="'_SWTTNR_patch.hex'"/></Value>
				</Variable>
			</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>
			<File>
				<Classification>HexMod17-Infoblock-Logfile</Classification>
				<Key>HEXMOD17_INFOBLOCK</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
