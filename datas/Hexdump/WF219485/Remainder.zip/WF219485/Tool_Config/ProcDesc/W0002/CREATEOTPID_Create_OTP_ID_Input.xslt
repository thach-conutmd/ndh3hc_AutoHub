 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="Flash0Required">
		<xsl:call-template name="GetFlash0_Required"></xsl:call-template>
</xsl:variable>
<xsl:variable name="Devicetype_flag">
		<xsl:call-template name="Data_Value">
			<xsl:with-param name="ID" select="'Devicetype_flag'" />
		</xsl:call-template>
</xsl:variable>
    <xsl:template match="/">
    <ToolInput>
		<Mode>Creation Of OTP String</Mode>
		<Input>
			<OTPInputFiles>
				<OTPInputFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory"> </xsl:call-template> 
					</Directory>
					<Name>
						<xsl:value-of select="'ibafter_case1.xml'"/>
					</Name>
				</OTPInputFile>
				<xsl:if test="$Devicetype_flag='1'">
				<OTPInputFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory"> </xsl:call-template> 
					</Directory>
					<Name>
						<xsl:value-of select="'ibafter_case1_HSM0.xml'"/>
					</Name>
				</OTPInputFile>
				<OTPInputFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory"> </xsl:call-template> 
					</Directory>
					<Name>
						<xsl:value-of select="'ibafter_case1_HSM1.xml'"/>
					</Name>
				</OTPInputFile>
				</xsl:if>
			</OTPInputFiles>
		</Input>
		    <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>	
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
		
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
