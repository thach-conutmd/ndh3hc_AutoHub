<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Hexmodx - Create Flash_0 GUAM Hexfile </Mode>
			<Input>
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="GetWrapperPath">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'CreateFlash0GUAM.bsh'" />
					</Name>
				</SourceTemplateFile>
				<TargetTemplateFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'CreateFlash0GUAM.bsh'"/>
					</Name>
				</TargetTemplateFile>
				<Script>
					
				</Script>
				<ScriptMandatory>1</ScriptMandatory>
				<Variables/>
				<CommandLine>
					<xsl:value-of select="'/'" />
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					<xsl:value-of select="'\CreateFlash0GUAM.bsh'"/>
					<xsl:value-of select="' -args '" />
					<xsl:value-of select="'&quot;'" />
					
					<!-- 1 cbLiteHexFile -->
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'CBLite_Signed'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'CBLite_Signed'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 2 Value CFGEXP_CBLITE_COMPILED_ADDRESS_START -->					
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_CBLITE_COMPILED_ADDRESS_START'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 3 input hex file path -->		
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 4 final output Trojan hex file path -->		
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'Flash0_GUAM.hex'"/>
					<xsl:value-of select="';'" />
					
					<!-- 5 Value CFGEXP_CBLITE_IN_REPROGCONTAINER_START -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_CBLITE_IN_REPROGCONTAINER_START'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 6 Value CFGEXP_NEW_SECUMGR_SOURCE_START -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_NEW_SECUMGR_SOURCE_START'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 7 Value CFGEXP_NEW_SECUMGR_SOURCE_END -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_NEW_SECUMGR_SOURCE_END'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 8 Value CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_NEW_SECUMGR_IN_REPROGCONTAINER_START'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 9 Value CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1 -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG1'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 10 Value CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2 -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG2'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />					
					
					<!-- 11 Value CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3 -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG3'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 12 Value CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4 -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'CFGEXP_SECUMGR_SECSWUPDCORE_CONFIG4'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
							
					<!-- 13 Value BOOTCTRL XADDRESS-->	
					 <xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'XADDRESS'"/>
					</xsl:call-template>
					<xsl:value-of select="';'" />
								
					<!-- 14 Value Log file -->	
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'LOG_CreateFlash0.txt'"/>		
					
					<xsl:value-of select="'&quot;'" />
					
				</CommandLine>
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
			<CallInformation>
				<ToolName>HEXMODX</ToolName>
				<CallType></CallType>
				<ToolVersion/>
				<ToolLocation>
				<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
