<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Read datas from AddressModelInfo file</Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime> <!-- 10 Minutes-->
				<DateTimeInterval>1</DateTimeInterval> <!-- 1 = Minutes  / 0 = Seconds-->
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory"/>
					</Directory>
					<Name>
						<xsl:value-of select="'AddressModelInfo.xml'"/>		
					</Name>
				</SourceTemplateFile>
				<ReadVaraibeList>
					<Variables>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>SB_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;SB&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>SB_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;SB&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>EcuSecuSrv0_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;EcuSecuSrv0&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>EcuSecuSrv0_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;EcuSecuSrv0&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CTP_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CTP&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CTP_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CTP&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CB_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CB&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CB_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CB&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW0_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW0&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW0_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW0&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW1_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW1&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW1_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW1&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW2_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW2&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW2_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW2&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW3_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW3&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>ASW3_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;ASW3&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>DS0_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;DS0&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>DS0_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;DS0&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>DS1_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;DS1&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>DS1_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;DS1&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>VDS_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;VDS&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>VDS_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;VDS&#39;]/END_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CUST0_STARTADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CUST0&#39;]/START_ADDRESS</Xpath>
						</Variable>
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CUST0_ENDADDRESS</ID>
							<Xpath>//ADDRESSMODEL_BLOCKS/BLOCK[NAME=&#39;CUST0&#39;]/END_ADDRESS</Xpath>
						</Variable>
					</Variables>
				</ReadVaraibeList>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
