<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt"/>

	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML"/>

	<xsl:output method="xml"/>
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

	<xsl:variable name="RT_RawFileUpdated" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='RawFileUpdated']/tctypes:Location"/>
	<xsl:variable name="RT_RawFileNameUpdated" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='RawFileUpdated']/tctypes:Location/tctypes:Name"/>
	<xsl:variable name="RT_NrDatapointers" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='SCRIPT_INCLUDE_SECTIONS_IN_RAW_FILE']/tctypes:Value"/>
	<xsl:variable name="RT_BSW_RELEASE_VALUE" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='BSW_RELEASE_VALUE']/tctypes:Value"/>

</xsl:stylesheet>