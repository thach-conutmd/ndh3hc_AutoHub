 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<RunHexMod17Output>
		<ResultingFile> 
     		   <Directory><xsl:call-template name="GetWorkingDirectory">
					</xsl:call-template></Directory>
			   <Name>
				     <xsl:call-template name="GetSoftwarePartNumber">
					</xsl:call-template><xsl:value-of select="'_Complete'"/><xsl:value-of select="'.hex'"/>
			   </Name>				
    		</ResultingFile>
    		<DataToWorkFlow>
				 		<WorkFlowData>
				    		<WorkFlowID>RELEASEPST</WorkFlowID>
				    		<WorkFlowName>RELEASEPST</WorkFlowName>
				    		<Data>
							<DataClassID>FileName</DataClassID>
							<DataClassName>RELEASEPST</DataClassName>				
							<DataValue><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:call-template name="GetSoftwarePartNumber">
							</xsl:call-template><xsl:value-of select="'_Complete'"/><xsl:value-of select="'.hex'"/></DataValue>
							<DataType>String</DataType>
						</Data>
						</WorkFlowData>
		</DataToWorkFlow>
    		
		</RunHexMod17Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
 
    </xsl:template>
</xsl:stylesheet>
