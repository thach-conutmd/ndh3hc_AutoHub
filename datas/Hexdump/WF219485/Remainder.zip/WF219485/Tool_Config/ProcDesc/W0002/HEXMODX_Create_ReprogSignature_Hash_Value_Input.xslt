 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
<xsl:variable name="GUAM_FLAG_Value">
	<xsl:call-template name="GetEnvironmentValue">
		<xsl:with-param name="LookUpItem" select="'GUAM_FLAG'"/>
	</xsl:call-template>
</xsl:variable>
<xsl:variable name="SECUMGR_HSM_FLAG" select="/tctypes:UseCase/tctypes:Data/tctypes:SECUMGR_HSM_FLAG" />

    <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Create Reprogramming Signature Hash Value</Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>Tprot</Module>			
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
  				<Variable>
					<Name>TPROT_JAR_FILE_PATH</Name>
					<Value>
						<xsl:value-of select="'mdg1tprot.jar'"/>						
					</Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_TPROT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_Reprog_TPROT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>		 

			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
		 <Tprot>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMODX_Reprog_TPROT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_REPROG_SIGNATURE_HASH_TPROTCONF_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
						</xsl:call-template>
						<xsl:value-of select="'&quot;'"/>
					<xsl:value-of select="' OID_PUB='"/>
					<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MEMLAY_OID_PUB'"/>
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<Name>HEXFILE_1</Name>
				<Value>					
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						<xsl:with-param name="GetExtension" select="'yes'"/>					
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<Name>HEXFILE_2</Name>
				<xsl:if test="$GUAM_FLAG_Value = '1'">
				<Value>					
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_AdjustChksum'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_AdjustChksum'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					</Value>
				</xsl:if>
				<xsl:if test="$GUAM_FLAG_Value = '2'">
					<xsl:if test="$SECUMGR_HSM_FLAG = '1'">
						<Value>					
							<xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
								<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
								<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/>					
							</xsl:call-template>
						</Value>
					</xsl:if>
					<xsl:if test="$SECUMGR_HSM_FLAG = '2'">
						<Value>					
							<xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Flash0_HEX'"/>
								<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Flash0_HEX'"/>
								<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/>					
							</xsl:call-template>
						</Value>
					</xsl:if>
				</xsl:if>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<!-- <Variable>
					<Name>XADDRESS</Name>
					<Value>
							<xsl:call-template name="GetEnvironmentValue">
										<xsl:with-param name="LookUpItem" select="'XADDRESS'"/>
							</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>HSM0_STARTADDRESS</Name>
					<Value>
							 <xsl:call-template name="GetHSM_STARTADDRESS">
								<xsl:with-param name="BlockName" select="'HSM0'"></xsl:with-param>
								<xsl:with-param name="File">
								 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
								  <xsl:value-of select="'\'"/>
								 <xsl:value-of select="'FSW_AddressModel.xml'"/>
								</xsl:with-param>
					</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>HSM1_STARTADDRESS</Name>
					<Value>
							 <xsl:call-template name="GetHSM_STARTADDRESS">
									<xsl:with-param name="BlockName" select="'HSM1'"></xsl:with-param>
									<xsl:with-param name="File">
									 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									  <xsl:value-of select="'\'"/>
									 <xsl:value-of select="'FSW_AddressModel.xml'"/>
									</xsl:with-param>
					</xsl:call-template>
					</Value>
				</Variable>
				<Variable>
					<Name>ASW0_START_ADDRESS</Name>
					<Value><xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
							<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AddressModelInfo.xml'" />
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable> -->
				<Variable>
					<Name>REPROG_HASHVALUE_FILE</Name>
					<Value>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\HEXMOD_Reprog_HASHOUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.TXT'"/>
					</Value>
				</Variable>
				<Variable>
					<Name>REPROG_RANGES</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
						                 <xsl:with-param name="DataClassID" select="'REPROG_DATABLOCKS_TEMPLATE'"/>
                				</xsl:call-template>
					</Value>
				</Variable>
				<!-- <Variable>
					<Name>REPROG_RANGES_FLASH0</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
					                 <xsl:with-param name="DataClassID" select="'REPROG_DATABLOCKS_TEMPLATE_Flash0'"/>
				           	</xsl:call-template>
					</Value>
				</Variable> -->
			</Variables>
      	</Tprot>
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
			</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
