<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:variable name="RT_ADDRESSMODEL_IBCHAIN" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='ADDRESSMODEL_IBCHAIN']/tctypes:Location" />
<xsl:variable name="RT_ADDRESSMODEL_HSM0" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='ADDRESSMODEL_HSM0']/tctypes:Location" />
<xsl:variable name="RT_ADDRESSMODEL_HSM1" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='ADDRESSMODEL_HSM1']/tctypes:Location" />
<xsl:variable name="RT_OTP_OUTPUTFILE_IBCHAIN" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='OTP_OUTPUTFILE_IBCHAIN']/tctypes:Location" />
<xsl:variable name="RT_OTP_OUTPUTFILE_HSM0" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='OTP_OUTPUTFILE_HSM0']/tctypes:Location" />
<xsl:variable name="RT_OTP_OUTPUTFILE_HSM1" select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='OTP_OUTPUTFILE_HSM1']/tctypes:Location" />
 
 
</xsl:stylesheet>