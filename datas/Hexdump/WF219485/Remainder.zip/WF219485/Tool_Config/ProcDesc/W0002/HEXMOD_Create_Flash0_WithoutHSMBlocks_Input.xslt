<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<xsl:variable name="OutputType" select="/tctypes:UseCase/tctypes:Data/tctypes:Output" />
	<xsl:variable name="ModeType">
		 <xsl:call-template name="CheckJDPOrInfineon">
			 <xsl:with-param name="ModeType">
				 <xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
				 </xsl:call-template>		 
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Create Flash0 Files</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="GetWrapperPath">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'\CreateFlash0_Dev2.bsh'" />
					</Name>
				</SourceTemplateFile>
				<TargetTemplateFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'\CreateFlash0Files.bsh'"/>
					</Name>
				</TargetTemplateFile>
				<Script>
					
				</Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				<CommandLine>
					<xsl:value-of select="'/'" />
					<xsl:call-template name="GetWrapperPath"></xsl:call-template>
					<xsl:value-of select="'\CreateFlash0_Dev2.bsh'"/>
					<xsl:value-of select="' -args '" />
					<xsl:value-of select="'&quot;'" />
					<!--1 Value Output -->
					<xsl:value-of select="'3;'" />
					<!--2 Value SB_BLOCK_ID -->					
					<xsl:call-template name="GetSBBLOCK_BLOCKID">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--3 Value TP_BLOCK_ID -->		
					<xsl:call-template name="GetTPBLOCK_BLOCKID">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--4 Value ASW0_BLOCK_ID -->		
					<xsl:call-template name="GetASW0BLOCK_BLOCKID">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--5 Value Prj_Start -->		
					<xsl:call-template name="GetSBBLOCK_STARTADDRESS">
										<xsl:with-param name="File">
										<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
										<xsl:value-of select="'\AddressModelInfo.xml'" />
										</xsl:with-param>
									</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--6 Value Input Hex -->		
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'HexMod17_SignedHexfile_Complete'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--7 Value FlashHex -->		
					<xsl:call-template name="FileList_GetFileDirectory">
										<xsl:with-param name="FileClassID" select="'FLASH_DRIVER_HEX_DEV2'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:call-template name="FileList_GetFileName">
										<xsl:with-param name="FileClassID" select="'FLASH_DRIVER_HEX_DEV2'"/>
										<xsl:with-param name="GetValue" select="'yes'"/> 
									</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!--8 Value Detailed log -->		
						<xsl:call-template name="GetWorkingDirectory"/>
							<xsl:value-of select="'\Detailelog_Flash0_Factory_TEMP.xml'"/>
					
					<!--9 Value Detailed log Ena -->	
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\Detailelog_Flash0_Factory_TEMP_Ena.xml'"/>
					
					<!--10 Value FLASH0_AddressModel -->	
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\FLASH0_AddressModel.xml'"/>
						
					<!--11 Value FLASH0_AddressModel Ena -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\FLASH0_AddressModelEna.xml'"/>
					
					<!--12 Value Logfile -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'LOG_CreateFlash0.txt'"/>
					
					<!--13 Value Logfile Ena -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
					<xsl:value-of select="'\'"/>
					<xsl:value-of select="'LOG_CreateFlash0Ena.txt'"/>
					
					<!--14 Value offset -->
					<xsl:value-of select="';'" />					
					<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET'"/>
						</xsl:call-template>									
					
					<!--15 Value offset1 -->					
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET_1'"/>
						</xsl:call-template>
					
					<!--16 Value offset Factory -->	
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'FLASH0_OFFSET_FACTORY'"/>
						</xsl:call-template>
					
					<!-- 17  Value Output file  -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\ASW0Trojan_Factory_Temp.hex'"/>
										
					<!-- 18  Value Output file Ena -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\ASW0Trojan_Factory_Ena_Temp.hex'"/>
					
					<!-- 19 - ABM section start address for boot header -->
					<xsl:value-of select="';'" /> 
					<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'ABM_START_ADDRESS'"/>
						</xsl:call-template>
					
					<!-- 20 - ABM section end address for boot header  -->
					<xsl:value-of select="';'" />
					<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'ABM_END_ADDRESS'"/>
						</xsl:call-template>
						
					<!-- 21 - ModeType  -->
					<xsl:value-of select="';'" />							
					<xsl:value-of select="$ModeType" />
						
					<xsl:value-of select="'&quot;'" /> 
				</CommandLine>
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
			<CallInformation>
				<ToolName>HEXMODX</ToolName>
				<CallType></CallType>
				<ToolVersion>3v42</ToolVersion>
				<ToolLocation>
					<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
					</xsl:call-template>
				</ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
