 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>Concatenation of HexCode Logistic Data</Mode>
    <Input>
		<!-- Source data Type 1- Binary Data 2- Ascii Data 3 -Unicode Data-->
		<SourceDataType><xsl:value-of select="'2'"/></SourceDataType>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<List>
			<!-- Entry for Source Input files. Order should be same as Merge order -->										
								
			<Entry>
					<SourceFile>
								<Directory></Directory>
								<Name></Name>
					</SourceFile>
					<SourceData>
						<xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'SCRIPT_HEX_COMPARE_LOGISTIC_LOG'" />
						</xsl:call-template>	
					</SourceData>				
			</Entry>			
			<Entry>
				<SourceFile>
					<Directory><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
						<xsl:with-param name="FileClassID" select="'BC_Gen_Log'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template></Directory>
					<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
						<xsl:with-param name="FileClassID" select="'BC_Gen_Log'"/>
						<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template></Name>
				</SourceFile>
				<SourceData></SourceData>				
			</Entry>
     <!-- <Entry>
        <SourceFile>
          <Directory>
            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          </Directory>
          <Name>PartailFlashAnalysis.txt</Name>
        </SourceFile>
        <SourceData></SourceData>
      </Entry>
      <Entry>
        <SourceFile>
          <Directory>
            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
          </Directory>
          <Name>Cb_BlockPatchAnalysis.txt</Name>
        </SourceFile>
        <SourceData></SourceData>
      </Entry>      
       <Entry>
              <SourceFile>
                <Directory>
                  <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                </Directory>
                <Name>DoserpatchPatchAnalysis.txt</Name>
              </SourceFile>
              <SourceData></SourceData>
      </Entry>	 -->
      
		</List>
    </Input>  
    </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>