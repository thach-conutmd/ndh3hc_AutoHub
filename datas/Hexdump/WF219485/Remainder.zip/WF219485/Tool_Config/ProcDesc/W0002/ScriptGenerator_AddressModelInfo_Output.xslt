 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<Results>
				<GUAM_FLAG>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'GUAM_FLAG'" />
					</xsl:call-template>
				</GUAM_FLAG>
			</Results>	
			<Scripts>			
			</Scripts>
			<PST_Library>
			</PST_Library>
					<ResultingFiles>
					<File>
						<FileClassID>LASTRUN_HEXMOD_HASHOUTPUT</FileClassID>
						<FileClassName>LASTRUN_HEXMOD_HASHOUTPUT</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
						<Name>
						<xsl:value-of select="'HEXMOD_HASHOUTPUT_'"/>
					<xsl:call-template name="GetWorkFlowID">	
					</xsl:call-template>
					<xsl:value-of select="'_LastRun'"/>
					<xsl:value-of select="'.TXT'"/></Name>
						</Location>
					</File>
					<File>
						<FileClassID>LASTRUN_WITHOUTHSM_HASHOUTPUT</FileClassID>
						<FileClassName>LASTRUN_WITHOUTHSM_HASHOUTPUT</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
						<Name>
						<xsl:value-of select="'HEXMOD_WITHOUTHSM_HASHOUTPUT_'"/>
					<xsl:call-template name="GetWorkFlowID">	
					</xsl:call-template>
					<xsl:value-of select="'_LastRun'"/>
					<xsl:value-of select="'.TXT'"/></Name>
						</Location>
					</File>
					<File>
						<FileClassID>LASTRUN_FALSH0_HASHOUTPUT</FileClassID>
						<FileClassName>LASTRUN_FALSH0_HASHOUTPUT</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
						<Name>
						<xsl:value-of select="'HEXMOD_FALSH0_HASHOUTPUT_'"/>
					<xsl:call-template name="GetWorkFlowID">		
					</xsl:call-template>
					<xsl:value-of select="'_LastRun'"/>
					<xsl:value-of select="'.TXT'"/></Name>
						</Location>
					</File>
					<File>
						<FileClassID>LASTRUN_Reprog_HASHOUTPUT</FileClassID>
						<FileClassName>LASTRUN_Reprog_HASHOUTPUT</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
						<Name>
						<xsl:value-of select="'HEXMOD_Reprog_HASHOUTPUT_'"/>
							<xsl:call-template name="GetWorkFlowID">
							</xsl:call-template>
						<xsl:value-of select="'_LastRun'"/>
						<xsl:value-of select="'.TXT'"/></Name>
						</Location>
					</File>
					<File>
						<FileClassID>LASTRUN_GUAM_HASHOUTPUT</FileClassID>
						<FileClassName>LASTRUN_GUAM_HASHOUTPUT</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
						<Name>
						<xsl:value-of select="'HEXMODX_New_GUAM_HASHOUTPUT'"/>
						<xsl:value-of select="'_LastRun'"/>
						<xsl:value-of select="'.TXT'"/></Name>
						</Location>
					</File>
				</ResultingFiles>
		</Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
 
    </xsl:template>
</xsl:stylesheet>
