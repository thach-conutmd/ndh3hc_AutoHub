 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/> 
 
    <xsl:template match="/">
    <ToolInput>
    <Mode>HexCode Logistic file Substute address</Mode>
   <Input>
     	<SourceTemplateFile>
			<Directory><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							    <xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'"/>
							    <xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Directory>
			<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template></Name>
		</SourceTemplateFile>
		<TargetTemplateFile>
			<Directory><xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							    <xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'"/>
							    <xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Directory>
			<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template></Name>
		</TargetTemplateFile>
		<Script>
		</Script>
		<List>
			<Entry>           			
				<ScriptPattern><![CDATA[\[[A-Za-z]*\,\s(?'Match1'([A-Za-z_0-9]*))\s*(?'Operand'([\+|-])?)\s*(?'Match2'(([A-Fa-f_0-9]*){2}))\]]]></ScriptPattern>				   
				<LookUpFile>
					<Directory>
            <xsl:call-template name="FileList_GetFileDirectory" >
              <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
              <xsl:with-param name="GetValue" select="'yes'"/>
            </xsl:call-template>
          </Directory>
          <Name>
            <xsl:value-of select="'\'"/>
            <xsl:call-template name="FileList_GetFileName" >
              <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
              <xsl:with-param name="GetValue" select="'yes'"/>
              <xsl:with-param name="GetExtension" select="'no'"/>
            </xsl:call-template>
            <xsl:value-of select="'.adl'" />
          </Name>
				</LookUpFile>
				<LookUpPattern><![CDATA[^<VARIABLE>\s(?'Match1'((([0-9]|[A-Fa-f])*){8}))]]></LookUpPattern>				
			</Entry>
		</List>
	
	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>HexCode Logistic Complete Log file</Classification>
				<Key></Key>
				<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
				<Name><xsl:call-template name="GetSoftwareName"></xsl:call-template>
						 <xsl:value-of select="'_Check_Complete.log'"/>
				</Name>
			</File>
		</Files>
	</LogFileAnalyser>	  
    </Input>  
    </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>