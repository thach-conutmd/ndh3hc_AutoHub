 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
	 <!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
	 <xsl:variable name="ModeType">
		 <xsl:call-template name="CheckJDPOrInfineon">
			 <xsl:with-param name="ModeType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
				 </xsl:call-template>			 
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>

   <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Adjust Checksum for Flash_0 hex</Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>InfoBlockXML</Module>			
			<Module>OutputXML</Module>
			<xsl:if test="$ModeType='0'">
<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
				<Module>ABMXML</Module>

			</xsl:if>

		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script>
				<xsl:if test="$ModeType='0'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_XML'"/>
					</xsl:call-template>
				</xsl:if>

				<xsl:if test="$ModeType='1'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_MAIN_WITHOUT_ABM_XML'"/>
					</xsl:call-template>
				</xsl:if>			
				
				
			
			</Script>
     		<Variables>
  				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_Flash0_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>			    
			    <Variable>
					<Name>HEXMOD_ABM_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_ABM_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				  <Variable>
					<Name>HEXMOD_INFOBLOCK_FLASH0_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexModx_InfoBlock_Falsh0_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>				  
			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
     	<InfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_Falsh0_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_FLASH0_INFOBLOCK_XML'"/></xsl:call-template></Script>
     		<Variables>
  			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
      			<Variable>
						<Name>ASW0_STARTADDRESS</Name>
						<Value>
							<xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
									<xsl:with-param name="File">
									<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									<xsl:value-of select="'\AddressModelInfo.xml'" />
									</xsl:with-param>
							</xsl:call-template>
						</Value>
						<Mandatory>True</Mandatory>	
					</Variable>	
    		</Variables>
      	</InfoBlockXML>
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_Signed'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_Signed'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
      			<Variable>
					<Name>FILETYPE</Name>
					<Type>Simple</Type>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>
		 <xsl:if test="$ModeType='0'">
			 
	   	<!-- ABM Config-->
     	<ABMXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_ABM_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>ABMBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ABMBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>BMIBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BMI_BLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>				
				<Variable>
					<Name>DEVICE_TYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE_ABM'"/>
				 </xsl:call-template></Value>
				</Variable>
			</Variables>	
   	</ABMXML>
		 </xsl:if>
     <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:value-of select="'Flash0_OnlyModASW0_AdjustChksum.hex'"/>
					</Value>
				</Variable> 
     		</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_Flash0_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>
			
		</Files>
	</LogFileAnalyser>
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
       <ToolLocation>
		   <xsl:call-template name="RunTime_Tool_Path">
			   <xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
		   </xsl:call-template>   
       </ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
