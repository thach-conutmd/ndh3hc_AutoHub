 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<ResultingFiles>  
				<File>
					<FileClassID>DATAPOINTER_Output</FileClassID>
					<FileClassName>DATAPOINTER_Output</FileClassName>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
						<Name><xsl:value-of select="'DataPtr.xml'"/></Name>						
					</Location>
				</File>
				<File>
					<FileClassID>HEXMODX_CHECKSUM_XML</FileClassID>
					<FileClassName>HEXMODX_CHECKSUM_XML</FileClassName>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
						<Name><xsl:value-of select="'Hexmodx_Checksum.xml'"/></Name>
					</Location>
				</File>
				<File>
					<FileClassID>REPROG_UNSIGNED_TXTFILE</FileClassID>
					<FileClassName>REPROG_UNSIGNED_TXTFILE</FileClassName>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
						<Name><xsl:value-of select="'Sign.txt'"/></Name>
					</Location>
				</File>				
        	</ResultingFiles>
		<PST_Library>		
		</PST_Library>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput>  
    </xsl:template>
</xsl:stylesheet>
