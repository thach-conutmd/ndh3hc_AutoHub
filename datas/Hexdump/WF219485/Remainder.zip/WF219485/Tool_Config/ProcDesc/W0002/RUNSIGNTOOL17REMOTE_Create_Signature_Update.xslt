<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

  <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


 <xsl:variable name="RT_SignTool_HashValue" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ResultingFile"/>
 <xsl:variable name="RT_UserName" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ClientSystemDetails/tctypes:UserName"/>
  <xsl:variable name="RT_StationName" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ClientSystemDetails/tctypes:StationName"/>
  <xsl:variable name="RT_DomainName" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ClientSystemDetails/tctypes:DomainName"/>
   <xsl:variable name="RT_ClientName" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ClientSystemDetails/tctypes:ClientName"/>
   <xsl:variable name="RT_ClientIP" select="tctypes:ToolOutput/tctypes:SignToolRemoteOutput/tctypes:ClientSystemDetails/tctypes:ClientIP"/>
 
</xsl:stylesheet>