<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Read HSM Block Start Address from HSMBlocks xml </Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime> <!-- 10 Minutes-->
				<DateTimeInterval>1</DateTimeInterval> <!-- 1 = Minutes  / 0 = Seconds-->
				<SourceTemplateFile>
					<Directory>
            					<xsl:call-template name="GetWorkingDirectory">
            					</xsl:call-template>            
          				</Directory>
					<Name>
            					<xsl:value-of select="'Sign_Info_Output.XML'"/>
          			</Name>
        			</SourceTemplateFile>
        			<ReadVaraibeList>
        				<xsl:call-template name="GetEnvironmentValue">
            				<xsl:with-param name="LookUpItem" select="'READ_SIGN_INFO_FROM_XML'"/>
          				</xsl:call-template>
					</ReadVaraibeList>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
