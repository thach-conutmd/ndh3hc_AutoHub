 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
   <xsl:variable name="AddressModelFile" select="concat($WorkingDir, '\AddressModel.xml')" />
   <xsl:variable name="ibafterFile" select="concat($WorkingDir, '\ibafter.xml')" />    

	<xsl:template match="/">
		<ToolInput>
			<Mode>Generate Scripts</Mode>
			<Input>
				<WorkingDirectory>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</WorkingDirectory>
				
				<Script>
					<Write2PSTLib>True</Write2PSTLib>
					<Key>SOFTWARE_BLOCK_INFORMATION_FOR_INTEGRATION_FILE_WEICHAI</Key>
					<Comment>Script for integration file</Comment>
					<ScriptTemplate>
					  <xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI'"/>
					  </xsl:call-template>
					</ScriptTemplate>
					<DataBase>
					  <Datas>
						<xsl:call-template name="GetXMLFromFile">
						  <xsl:with-param  name="File"  select="$AddressModelFile" />
						</xsl:call-template>
					  </Datas>
						<SW_BLOCKS_WEICHAI>						
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SW_BLOCKS_WEICHAI'" />
							</xsl:call-template>						
						</SW_BLOCKS_WEICHAI>					
					</DataBase>
				</Script>
				
				<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>SCRIPT_INFOBLOCK_DELETE_OEMHEXFFILE_WEICHAI</Key>
						<Comment>XML-Fragment for Infoblock-XML (Deletion of BootCtrl, EcuSecuSrv0, CB, HSM0, HSM1, ASW0, ASW2 and DS1 blocks from OEMHexfile)</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_OEMHEXFFILE_WEICHAI'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<ADDRESSLAYOUTMODEL>
								<ADDRESSMODEL>
									<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:value-of select="'AddressModel.xml'"/>
								</ADDRESSMODEL>								
							</ADDRESSLAYOUTMODEL>
				        </DataBase>
				</Script>
				
				<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>INFOBLOCK_DELETE_DATA_WEICHAI</Key>
						<Comment>XML-Fragment for Infoblock-XML (Deletion of ASW1 and DS0 blocks from BoschHexfile)</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_DATA_WEICHAI'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<ADDRESSLAYOUTMODEL>
								<ADDRESSMODEL>
									<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
									<xsl:value-of select="'\'"/>
									<xsl:value-of select="'AddressModel.xml'"/>
								</ADDRESSMODEL>								
							</ADDRESSLAYOUTMODEL>
				        </DataBase>
				</Script>
				<Script>
					<Write2PSTLib>True</Write2PSTLib>
					<Key>SOFTWARE_BLOCK_INFORMATION_FOR_INTEGRATION_FILE_WEICHAI</Key>
					<Comment>Script for integration file</Comment>
					<ScriptTemplate>
					  <xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION_WEICHAI'"/>
					  </xsl:call-template>
					</ScriptTemplate>
					<DataBase>
					  <Datas>
						<xsl:call-template name="GetXMLFromFile">
						  <xsl:with-param  name="File"  select="$AddressModelFile" />
						</xsl:call-template>
					  </Datas>
						<SW_BLOCKS_WEICHAI>						
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SW_BLOCKS_WEICHAI'" />
							</xsl:call-template>						
						</SW_BLOCKS_WEICHAI>					
					</DataBase>
				</Script>
				
				<!--NBN1HC, Updating 23/06/2022 -->
				
				<Scripts>
					<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>INFOBLOCK_DELETE_DATA_IB</Key>
						<Comment>XML-Fragment for Infoblock-XML (Deletion of all DSx and VDS from Hexfile)</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_DATA_IB'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
						 <xsl:call-template name="GetXMLFromFile">
			            <xsl:with-param  name="File"  select="$AddressModelFile" />
			          </xsl:call-template>
						</DataBase>
				</Script>
				<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>INFOBLOCK_DELETE_PROG_IB</Key>
						<Comment>XML-Fragment for Infoblock-XML (Deletion of all blocks except DSx and VDS from Hexfile)</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_INFOBLOCK_DELETE_PROG_IB'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
						 <xsl:call-template name="GetXMLFromFile">
			            <xsl:with-param  name="File"  select="$AddressModelFile" />
			          </xsl:call-template>
						</DataBase>
				</Script>
				<Script>
					<Write2PSTLib>True</Write2PSTLib>
					<Key>ERASE_RANGE</Key>
					<Comment>Script for Erase Boot blocks of Hexfile</Comment>
					<ScriptTemplate>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_ERASE_RANGE'" />
						</xsl:call-template>
					</ScriptTemplate>
					<DataBase>
					<Datas>
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  select="$AddressModelFile" />
						</xsl:call-template>
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  >
						<xsl:call-template name="GetWrapperPath" />
							<xsl:value-of select="'\BOOT_BLOCKS.xml'"/>				 
								</xsl:with-param>
							</xsl:call-template>
						<HexFormat>
							<xsl:call-template name="CheckJDPOrInfineon">
								<xsl:with-param name="ModeType">
								<xsl:call-template name="GetEnvironmentValue">
									<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
								</xsl:call-template>			 
								</xsl:with-param>			
							</xsl:call-template>
						</HexFormat>
					</Datas>
					</DataBase>
				</Script>
				
				<Script>
					<Write2PSTLib>True</Write2PSTLib>
					<Key>E_NR_IB_FOR_BSW</Key>
					<Comment>Script for Erase Boot blocks of Hexfile</Comment>
					<ScriptTemplate>
						<xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_E_NR_IB_FOR_BSW'" />
						</xsl:call-template>
					</ScriptTemplate>
					<DataBase>
					 <Datas>
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  select="$AddressModelFile" />
						</xsl:call-template>	
						<xsl:call-template name="GetXMLFromFile">
							<xsl:with-param  name="File"  >
						<xsl:call-template name="GetWrapperPath" />
							<xsl:value-of select="'\BOOT_BLOCKS.xml'"/>				 
								</xsl:with-param>
							</xsl:call-template>						
					  </Datas>
					</DataBase>
			</Script>
				
				
				
				<Script>
		      		<Write2PSTLib>True</Write2PSTLib>
		      		<Key>E_NR_IB</Key>
		      		<Comment>Script for generating container parameter E_NR_IB</Comment>
		      		<ScriptTemplate><xsl:call-template name="GetEnvironmentValue">
		      		<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_E_NR_IB'"/></xsl:call-template></ScriptTemplate>
		      		<DataBase>
		      			 <Datas>
		      				<xsl:call-template name="GetXMLFromFile">
						            <xsl:with-param  name="File"  select="$AddressModelFile" />
		          			</xsl:call-template>
		      			</Datas>
		      		</DataBase>
		</Script>
		<Script>
		  										<Write2PSTLib>False</Write2PSTLib>
		  										<Key>ADDRESS_MODEL_INFO</Key>
		  										<Comment>Script Prepare Non boot blocks </Comment>
		  										<ScriptTemplate>
		  											<xsl:call-template name="GetEnvironmentValue">
		  												<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_ADDRESS_MODEL_INFO'" />
		  											</xsl:call-template>
		  										</ScriptTemplate>
		  										<DataBase>
		  										 <Datas>
		  											<xsl:call-template name="GetXMLFromFile">
		  												<xsl:with-param  name="File"  select="$AddressModelFile" />
		  											</xsl:call-template>												
		  											<AddressModel_Info_XML>
		  												<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>									
		  												<xsl:value-of select="'\'"/>						
		  												<xsl:value-of select="'AddressModelInfo.xml'"/>
		  											</AddressModel_Info_XML>
		  										  </Datas>
		  										</DataBase>
			</Script>
							<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>MDG1_DEVICE_TYPE</Key>
						<Comment>Device type value derived from merged_corecfg_export.xml</Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_MDG1_DEVICE_TYPE'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>
							<CFGEXP_MACHINE_DEV>
									<xsl:call-template name="RunTime_Data_Value">	
										<xsl:with-param name="DataClassID" select="'CFGEXP_MACHINE_DEV'" />								
									</xsl:call-template>
							</CFGEXP_MACHINE_DEV>	
							<CFGEXP_MACHINE_TYPE>
									<xsl:call-template name="RunTime_Data_Value">	
										<xsl:with-param name="DataClassID" select="'CFGEXP_MACHINE_TYPE'" />								
									</xsl:call-template>
							</CFGEXP_MACHINE_TYPE>	
							</Datas>
						</DataBase>
				</Script>				
				<Script>
				  		<Write2PSTLib>True</Write2PSTLib>
				  		<Key>BMI_BLOCKS</Key>
				  		<Comment>Deriving BootModeIndex nodes in MDG Dev5</Comment>
				  		<ScriptTemplate><xsl:call-template name="GetEnvironmentValue">
				  		<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_BOOT_MODE_INDEX_MDGDEV5'"/></xsl:call-template></ScriptTemplate>						
							<DataBase>
							<BMI>
									<xsl:call-template name="RunTime_Data_Value_Node">	
										<xsl:with-param name="DataClassID" select="'BOOT_MODE_INDEX_NODE'" />								
									</xsl:call-template>
							</BMI>
				        </DataBase>
				</Script>	
				<Script>
						<Write2PSTLib>True</Write2PSTLib>
						<Key>MDG1_DEVICE_TYPE_ABM</Key>
						<Comment>Device type value derived from merged_corecfg_export.xml for abm checksum correction </Comment>
						<ScriptTemplate>
							<xsl:call-template name="GetEnvironmentValue">
								<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_MDG1_DEVICE_TYPE_ABM_CHECKSUM'" />
							</xsl:call-template>
						</ScriptTemplate>
						<DataBase>
							<Datas>
							<CFGEXP_MACHINE_DEV>
									<xsl:call-template name="RunTime_Data_Value">	
										<xsl:with-param name="DataClassID" select="'CFGEXP_MACHINE_DEV'" />								
									</xsl:call-template>
							</CFGEXP_MACHINE_DEV>	
							<CFGEXP_MACHINE_TYPE>
									<xsl:call-template name="RunTime_Data_Value">	
										<xsl:with-param name="DataClassID" select="'CFGEXP_MACHINE_TYPE'" />								
									</xsl:call-template>
							</CFGEXP_MACHINE_TYPE>	
							</Datas>
						</DataBase>
				</Script>
				<Script>
        <Write2PSTLib>True</Write2PSTLib>
        <Key>HEXMOD_DERIVE_INFOBLOCKADDR</Key>
        <Comment>Script for deriving INFOBLOCKADDR</Comment>
        <ScriptTemplate>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_INFOBLOCKADDRESS'" />
          </xsl:call-template>
        </ScriptTemplate>
        <DataBase>
		<WorkingDirectory>
			<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>                                                                                                 
		</WorkingDirectory>
          <xsl:call-template name="GetXMLFromFile">
            <xsl:with-param  name="File"  select="$AddressModelFile" />
          </xsl:call-template>
		    <BLOCKLIST><xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'SIGN_TOOL_BLOCKS'"/>
              </xsl:call-template></BLOCKLIST>
        </DataBase>	
	</Script>	
<Script>
        <Write2PSTLib>True</Write2PSTLib>
        <Key>SOFTWARE_BLOCK_INFORMATION_FOR_INTEGRATION_FILE</Key>
        <Comment>Script for integration file</Comment>
        <ScriptTemplate>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'SCRIPT_PREPARE_SOFTWARE_BLOCK_INFORMATION'"/>
          </xsl:call-template>
        </ScriptTemplate>
        <DataBase>
          <Datas>
            <xsl:call-template name="GetXMLFromFile">
              <xsl:with-param  name="File"  select="$AddressModelFile" />
            </xsl:call-template>
          </Datas>
		  <SW_BLOCKLIST><xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'SW_BLOCKS'"/>
              </xsl:call-template></SW_BLOCKLIST>
        
        </DataBase>
      </Script>
	  <Script>
        <Write2PSTLib>True</Write2PSTLib>
        <Key>HEXMOD_DERIVE_TPROT_INFOBLOCKADDR</Key>
        <Comment>Script for deriving Tprot INFOBLOCKADDR</Comment>
        <ScriptTemplate>
          <xsl:call-template name="GetEnvironmentValue">
            <xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_TPROT_INFOBLOCKADDRESS'" />
          </xsl:call-template>
        </ScriptTemplate>
        <DataBase>
		
          <xsl:call-template name="GetXMLFromFile">
            <xsl:with-param  name="File"  select="$AddressModelFile" />
          </xsl:call-template>
		    <BLOCKS><xsl:call-template name="RunTime_Data_Value">
                <xsl:with-param name="DataClassID" select="'SIGN_TOOL_BLOCKS'"/>
              </xsl:call-template></BLOCKS>
        </DataBase>	
	</Script>
		
			</Scripts>
				<PST_Library></PST_Library>
			</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
