<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes"
xmlns:tcenv="http://de.bosch.com/gs/ToolChainEnvironment">
 <xsl:output method="xml" omit-xml-declaration='yes' 
 cdata-section-elements="Script Value CDATAValue ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- variables for Library-File and Usecase-File  - these values will be set by calling stylesheet -->
<xsl:variable name="LibraryXML" select="''"/>
<xsl:variable name="UseCaseXML" select="''"/> 
 
 <!-- variables for branching-methods -->
 <xsl:variable name="System" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:System"/>
 <xsl:variable name="CustomerCodeNumber" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:CustomerCodeNumber"/>
 <xsl:variable name="FlashLayout" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:FlashLayout"/>
 <xsl:variable name="CustomerGroup" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:CustomerGroup"/>
 <xsl:variable name="SelectCustomerPD" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:SelectCustomerPD"/>
 <xsl:variable name="PartialFLSystemConst" select="document($UseCaseXML)/tctypes:UseCase//tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='PART_PROG_SY']/tctypes:Value"/>
  <xsl:variable name="CMBTYP_SY" select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:CMBTYP_SY"/>
 
 <!-- central template for getting environment-values -->
 <xsl:template name="GetEnvironmentValue">
	<xsl:param name="LookUpItem"/>
		<xsl:variable name="VarLookUpItem" select="$LookUpItem"/>

	<xsl:if test="$LookUpItem=''">
		<xsl:message terminate="yes">Error: <xsl:value-of select="$LookUpItem"/> No LookUpItem provided in GetEnvironmentValue"/></xsl:message>
	</xsl:if>
   
     <xsl:call-template name="GetItem">
		<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
		
    </xsl:call-template>
 </xsl:template>


  <xsl:template name="GetItem">
	<xsl:param name="LookUpItem"/>
	<xsl:param name="Level" select="1"/>
	
		<xsl:variable name="PSTLibResult" select="document($LibraryXML)/tcenv:Environment/tcenv:PSTLibCreation/tcenv:ResultList/tcenv:Result[child::tcenv:LookUpItem/@ItemID=$LookUpItem]"/>

	<xsl:choose>
		
		<xsl:when test="$PSTLibResult">

			<xsl:variable name="XChildCount" select="count($PSTLibResult/tcenv:LookUpResult/child::tcenv:*)"/>
			<xsl:choose>
				<xsl:when test="$XChildCount=0">
					<xsl:value-of select="$PSTLibResult/tcenv:LookUpResult" disable-output-escaping="yes"/>
				</xsl:when>
				<xsl:when test="$XChildCount>0">
					<xsl:apply-templates select="$PSTLibResult/tcenv:LookUpResult/*|$PSTLibResult/tcenv:LookUpResult/@*|$PSTLibResult/tcenv:LookUpResult/text()" mode="rebuild"/>

			 		<!--<xsl:copy-of select="$PSTLibResult/tcenv:LookUpResult/*"/>-->
				</xsl:when>
			</xsl:choose>

		</xsl:when>
		
		<xsl:otherwise>
		    <xsl:call-template name="TreeSearchDown">
				<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
				<xsl:with-param name="SubTree" select="document($LibraryXML)/tcenv:Environment/tcenv:LookUpTree[child::tcenv:Scope/tcenv:LookUpItem/@ItemID=$LookUpItem]"/>
			</xsl:call-template>
		</xsl:otherwise>

	</xsl:choose>
	
  </xsl:template>


  <xsl:template name="TreeSearchDown">
	<xsl:param name="LookUpItem"/>
	<xsl:param name="SubTree"/>
	<xsl:param name="Level" select="1"/>


	<xsl:variable name="BranchMethod" select="$SubTree/tcenv:Branching/tcenv:BranchMethod"/>
			<!-- 
				TreeSearchDown goes down the tree and its branches until there are no further branches available
				Once this node is reached TreeSearchUp will be called to go back to the neares result node for
				the given LookUpItem
			 -->
		<xsl:choose>
			<!-- 
				We use as nested choose. 
				
				The outer choose tries to find a known branching method. 
				If there is no further Branch at all we have reached the final node in the current branch.
				If there is a branch but an unknown method we have an unknown branching method which is an error

				The inner choose steps checks whether there is a branch matching the current data or not.
				If such a branch exists, the template is calles recursively with that branch.
				If none of the branches matches the current data, we have no feasible branch. 
				
				The tree has to be searched until we have reached a final node or a node without a feasible branch.
				In both cases we go back to the neares result node.	
			-->
			<xsl:when test="$BranchMethod='SelectCustomerPD'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$SelectCustomerPD">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$SelectCustomerPD]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>					
				</xsl:choose>
			</xsl:when>

			<xsl:when test="$BranchMethod='ECU_Designation'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$System">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$System]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>					
				</xsl:choose>
			</xsl:when>
	   		<xsl:when test="$BranchMethod='CustomerCodeNumber'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$CustomerCodeNumber">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$CustomerCodeNumber]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>				
				</xsl:choose>
			</xsl:when>
			
			<xsl:when test="$BranchMethod='FlashLayout'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$FlashLayout">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$FlashLayout]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>				
				</xsl:choose>
			</xsl:when>			
			
			<xsl:when test="$BranchMethod='CustomerGroup'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$CustomerGroup">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$CustomerGroup]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>				
				</xsl:choose>
			</xsl:when>	
			
			<xsl:when test="$BranchMethod='PartialFLSystemConst'"> 
				<xsl:choose>
					<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$PartialFLSystemConst">
						<xsl:call-template name="TreeSearchDown">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$PartialFLSystemConst]"/>
							<xsl:with-param name="Level" select="$Level+1"/>
						</xsl:call-template>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name="TreeSearchUp">
							<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
							<xsl:with-param name="SubTree" select="$SubTree"/>
							<xsl:with-param name="Level" select="$Level"/>
						</xsl:call-template>
					</xsl:otherwise>					
				</xsl:choose>
			</xsl:when>
			
			<xsl:when test="$BranchMethod='CMBTYP_SY'">
							<xsl:choose>
								<xsl:when test="$SubTree/tcenv:Branching/tcenv:Branch/@Value=$CMBTYP_SY">
									<xsl:call-template name="TreeSearchDown">
										<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
										<xsl:with-param name="SubTree" select="$SubTree/tcenv:Branching/tcenv:Branch[@Value=$CMBTYP_SY]"/>
										<xsl:with-param name="Level" select="$Level+1"/>
									</xsl:call-template>
								</xsl:when>
								<xsl:otherwise>
									<xsl:call-template name="TreeSearchUp">
										<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
										<xsl:with-param name="SubTree" select="$SubTree"/>
										<xsl:with-param name="Level" select="$Level"/>
									</xsl:call-template>
								</xsl:otherwise>
							</xsl:choose>
			</xsl:when>
					
			<xsl:when test="string($SubTree/tcenv:Branching)=''">
					<xsl:call-template name="TreeSearchUp">
						<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
						<xsl:with-param name="SubTree" select="$SubTree"/>
						<xsl:with-param name="Level" select="$Level"/>
					</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
					<xsl:message terminate="yes">
						Unknown Branching method <xsl:value-of select="$BranchMethod"/>
					</xsl:message>
			</xsl:otherwise>				
		</xsl:choose>
	</xsl:template>
	<xsl:template name="TreeSearchUp">
		<xsl:param name="LookUpItem"/>
		<xsl:param name="SubTree"/>
		<xsl:param name="Level" />
		<xsl:variable name="CurrentResult" select="$SubTree/tcenv:ResultList/tcenv:Result[child::tcenv:LookUpItem/@ItemID=$LookUpItem]"/>
		<xsl:variable name="ChildCount" select="count($CurrentResult/tcenv:LookUpResult/child::*)"/>
		<xsl:choose>
			<xsl:when test="$CurrentResult">
				<xsl:choose>
					<xsl:when test="$ChildCount=0">
				 		<xsl:value-of select="$CurrentResult/tcenv:LookUpResult" disable-output-escaping="yes"/>
					</xsl:when>
					<xsl:when test="$ChildCount>0">
						<xsl:apply-templates select="$CurrentResult/tcenv:LookUpResult/*|$CurrentResult/tcenv:LookUpResult/@*|$CurrentResult/tcenv:LookUpResult/text()" mode="rebuild"/>
			 			<!--xsl:copy-of select="$CurrentResult/tcenv:LookUpResult/*"/-->
					</xsl:when>
				</xsl:choose>
			</xsl:when>
			<xsl:when test="not($CurrentResult) and $Level>1">
				<xsl:call-template name="TreeSearchUp">
					<xsl:with-param name="LookUpItem" select="$LookUpItem"/>
					<xsl:with-param name="SubTree" select="$SubTree/../.."/>
					<xsl:with-param name="Level" select="$Level - 1"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:message>No Result found</xsl:message>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

    <xsl:template match="*" mode="rebuild">
   		<xsl:variable name="NamespaceCount" select="count(namespace::*)"/>
   		<xsl:variable name="NamespaceParentCount" select="count(../namespace::*)"/>
		<xsl:choose>
			<xsl:when test="$NamespaceParentCount>=$NamespaceCount">
					<xsl:element name="{name(.)}">
						<xsl:apply-templates select="./*|@*|text()" mode="rebuild"/>
					</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<xsl:copy-of select="."></xsl:copy-of>
			</xsl:otherwise>
		</xsl:choose>
    </xsl:template>
    
    <xsl:template match="@*" mode="rebuild">
      <xsl:attribute name="{name(.)}" ><xsl:apply-templates select="."/></xsl:attribute>
    </xsl:template>

</xsl:stylesheet>
