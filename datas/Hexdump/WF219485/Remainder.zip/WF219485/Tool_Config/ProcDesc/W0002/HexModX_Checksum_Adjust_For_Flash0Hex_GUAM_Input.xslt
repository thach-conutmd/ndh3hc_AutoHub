 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
	 <!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
	 <xsl:variable name="ModeType">
		 <xsl:call-template name="CheckJDPOrInfineon">
			 <xsl:with-param name="ModeType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
				 </xsl:call-template>			 
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	 <!-- 40NM or 65NM - derived from merged_corecfg -->
	 <xsl:variable name="DeviceType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE_ABM'"/>
				 </xsl:call-template>
	 </xsl:variable>

	 
   <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Adjust Checksum for Flash_0 GUAM hex </Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>InfoBlockXML</Module>			
			<Module>OutputXML</Module>
			<xsl:if test="$ModeType='0'">
<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
				<Module>ABMXML</Module>
			</xsl:if>

		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main.xml'"/></Name>
     		</TemplateFile>
     		<Script>
				<xsl:if test="$ModeType='0'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_WITHOUTHSMBLOCKS_MAIN_XML'"/>
					</xsl:call-template>
				</xsl:if>

				<xsl:if test="$ModeType='1'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUTHSMBLOCKS_WITHOUT_ABM_XML'"/>
					</xsl:call-template>
				</xsl:if>			
				
				
			
			</Script>
     		<Variables>
  				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INFOBLOCK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexModx_InfoBlock_Flash0.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_ABM_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_ABM.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT.XML'"/></Value>
				</Variable>		  
			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
     	<InfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_Flash0.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML'"/></xsl:call-template></Script>
     		<Variables>
  			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INFOBLOCK_LOG.LOG'"/></Value>
				</Variable>
      			<Variable>
					<Name>INFOBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INFOBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
    			<Variable>
					<Name>COMPATIBILITY_POINTER_LIST</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_IBAFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_IBAFTER_LOG.LOG'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_CHKFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_CHKFTER_LOG.LOG'"/></Value>
				</Variable>
    		</Variables>
      	</InfoBlockXML>
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_Signed'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0_Signed'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
      			<Variable>
					<Name>FILETYPE</Name>
					<Type>Simple</Type>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>
		<xsl:if test="$ModeType='0'">
			 
	   	<!-- ABM Config-->
		<ABMXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMODX_ABM.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>ABMBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ABMBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>BMIBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BMI_BLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>				
				<Variable>
					<Name>DEVICE_TYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE_ABM'"/>
				 </xsl:call-template></Value>
				</Variable>
			</Variables>	
		</ABMXML>
		 </xsl:if>
     <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:value-of select="'Flash0_OnlyModASW0_AdjustChksum.hex'"/>
					</Value>
				</Variable> 
     		</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>HexmodX-Main-Logfile</Classification>
				<Key>HEXMODX_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_Flash0_LOG.LOG'"/></Name>
			</File>
      <File>
        <Classification>HexmodX-InfoBlock-Logfile</Classification>
        <Key>HEXMODX_MAIN</Key>
        <Directory>
          <xsl:call-template name="GetWorkingDirectory">
          </xsl:call-template>
        </Directory>
        <Name>
          <xsl:value-of select="'HEXMODX_INFOBLOCK_LOG.LOG'"/>
        </Name>
      </File>
		</Files>
	</LogFileAnalyser>
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
       <ToolLocation>
       <xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
       </ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
