 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Create Flash_0 Signature Hex file </Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>Tprot</Module>
			<Module>InfoBlockXML</Module>
			
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_MAIN_XML'"/></xsl:call-template></Script>
				
     		<Variables>
				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
  				<Variable>
					<Name>TPROT_JAR_FILE_PATH</Name>
					<Value>						
						<xsl:value-of select="'mdg1tprot.jar'"/>		
						
					</Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_TPROT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_Flash0_TPROT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				 <Variable>
					<Name>HEXMOD_INFOBLOCK_ASW0_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_Flash0_INNFLOBCK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>	

			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
		 <Tprot>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMODX_Flash0_TPROT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_FLASH0_SIGNED_HEXFILE_TPROTCONF_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template>
						
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<!-- Input hexfile -->
				<Name>HEXFILE</Name>
				<Value>					
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'Flash0_OnlyModASW0'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>											
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
				<!-- Sign.txt -->
				<Name>SIGNATURE_OUTPUT_FILE</Name>
				<Value>					
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'HexModX_Flash0_SignedValues'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'HexModX_Flash0_SignedValues'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>				
						</xsl:call-template>
					</Value>
					<Mandatory>True</Mandatory>
				</Variable>
				<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				
				<!-- Output signed hexfile -->
				<Variable>
					<Name>OUTPUT_HEXFILE</Name>
					<Value>				
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:value-of select="'Flash0_OnlyModASW0_Signed.hex'"/>
					</Value>
				</Variable>
				
				<Variable>
						<Name>ASW0_START_ADDRESS</Name>
					<Value>
						<xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
							<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AddressModelInfo.xml'" />
							</xsl:with-param>
						</xsl:call-template>
					</Value>
				</Variable>
				
				
				
			</Variables>
      	</Tprot>
      	
      	<InfoBlockXML>
	     	    <TemplateFile>
	     			<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
	     			<Name><xsl:value-of select="'HEXMODX_Flash0_INNFLOBCK_'"/>
									<xsl:call-template name="GetWorkFlowID">
									</xsl:call-template>.xml</Name>
	     		</TemplateFile>
	     		<Script><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CREATE_SIGNATURE_HASH_FLAHS0_INFOBLOCK_XML'"/></xsl:call-template></Script>
	     		<Variables>
	 			    <Variable>
						<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
						<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
					</Variable>
	     			<Variable>
						<Name>ASW0_STARTADDRESS</Name>
						<Value><xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
							<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AddressModelInfo.xml'" />
							</xsl:with-param>
						</xsl:call-template>
						</Value>
				</Variable>
	     			
				</Variables>
      	</InfoBlockXML>
      	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>			
		</Files>
	</LogFileAnalyser>	
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion>3v42</ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
			</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
