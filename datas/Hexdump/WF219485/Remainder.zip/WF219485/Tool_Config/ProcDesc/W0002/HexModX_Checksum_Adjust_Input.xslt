 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
	 <!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
	 <xsl:variable name="ModeType">
		 <xsl:call-template name="CheckJDPOrInfineon">
			 <xsl:with-param name="ModeType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/>
				 </xsl:call-template>			 
			 </xsl:with-param>			
		 </xsl:call-template>
	 </xsl:variable>
	  <!-- for  DEV5 = 1 and other dev will have value 0 -->
	 <xsl:variable name="DeviceType">
				 <xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE'"/>
				 </xsl:call-template>
	 </xsl:variable>
   <xsl:template match="/">
    <ToolInput>
    <Mode>HexModX - Adjust Checksum for MDG</Mode>
     <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>InfoBlockXML</Module>
			<Module>HSM0InfoBlockXML</Module>
			<Module>HSM1InfoBlockXML</Module>
			<Module>OutputXML</Module>
			<xsl:if test="$ModeType='0'">
<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
				<Module>ABMXML</Module>

			</xsl:if>

		</Modules>
		
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script>
				<xsl:if test="$ModeType='0'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_XML'"/>
					</xsl:call-template>
				</xsl:if>

				<xsl:if test="$ModeType='1'">
					<!-- ModeType = 0 is Little Indian and only in LittleIndian we have abm block-->
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_MAIN_WITHOUT_ABM_XML'"/>
					</xsl:call-template>
				</xsl:if>			
				
				
			
			</Script>
     		<Variables>
  				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INFOBLOCK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INFOBLOCK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_ABM_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_ABM_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_OUTPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				  <Variable>
					<Name>HEXMOD_INFOBLOCK_HSM0_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INFOBLOCK_HSM0_'"/><xsl:call-template name="GetWorkFlowID">
						</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				  <Variable>
						<Name>HEXMOD_INFOBLOCK_HSM1_XML_NAME</Name>
						<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_INFOBLOCK_HSM1_'"/><xsl:call-template name="GetWorkFlowID">
							</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			</Variables>
     	</MainXML>
     	<!-- InfoBlock - Config -->
     	<InfoBlockXML>
     	    <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_InfoBlock_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_XML'"/></xsl:call-template></Script>
     		<Variables>
  			    <Variable>
					<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
      			<Variable>
					<Name>INFOBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'INFOBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
    			<Variable>
					<Name>COMPATIBILITY_POINTER_LIST</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'COMPATIBILITY_POINTER_LIST'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_IBAFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_IBAFTER_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_CHKFTER_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_CHKFTER_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
    		</Variables>
      	</InfoBlockXML>
      	
      	
      			<!-- InfoBlock - Config  for Checkusm adjustment for HSM0  -->
	     	<HSM0InfoBlockXML>
	     	    <TemplateFile>
	     			<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
	     			<Name><xsl:value-of select="'HEXMODX_INFOBLOCK_HSM0_'"/>
									<xsl:call-template name="GetWorkFlowID">
									</xsl:call-template>.xml</Name>
	     		</TemplateFile>
	     		<Script><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM0_XML'"/></xsl:call-template></Script>
	     		<Variables>
	 			    <Variable>
						<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
						<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
					</Variable>
	     			<Variable>
						<Name>HSM0_STARTADDRESS</Name>
						<Value>
						
						 <xsl:call-template name="GetHSM_STARTADDRESS">
						<xsl:with-param name="BlockName" select="'HSM0'"></xsl:with-param>
						<xsl:with-param name="File">
						 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						  <xsl:value-of select="'\'"/>
						 <xsl:value-of select="'FSW_AddressModel.xml'"/>
						</xsl:with-param>
						</xsl:call-template>
						
						
						</Value>
						<Mandatory>True</Mandatory>	
					</Variable>			
	    						
				</Variables>
	      	</HSM0InfoBlockXML>
			
			<!-- InfoBlock - Config  for Checksum adjustment of HSM1  -->
	     	<HSM1InfoBlockXML>
	     	    <TemplateFile>
	     			<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
	     			<Name><xsl:value-of select="'HEXMODX_INFOBLOCK_HSM1_'"/>
									<xsl:call-template name="GetWorkFlowID">
									</xsl:call-template>.xml</Name>
	     		</TemplateFile>
	     		<Script><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INFOBLOCK_HSM1_XML'"/></xsl:call-template></Script>
	     		<Variables>
	 			    <Variable>
						<Name>HEXMOD_INFOBLOCK_LOGFILE</Name>
						<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_INFOBLOCK_LOG_'"/><xsl:call-template name="GetWorkFlowID">
									</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
					</Variable>
	     			<Variable>
						<Name>HSM1_STARTADDRESS</Name>
						<Value>
						
						 <xsl:call-template name="GetHSM_STARTADDRESS">
											<xsl:with-param name="BlockName" select="'HSM1'"></xsl:with-param>
											<xsl:with-param name="File">
											 <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
											  <xsl:value-of select="'\'"/>
											 <xsl:value-of select="'FSW_AddressModel.xml'"/>
											</xsl:with-param>
						</xsl:call-template>
						
						</Value>
						<Mandatory>True</Mandatory>	
					</Variable>							
				</Variables>
      	</HSM1InfoBlockXML>
      	
  
       	<!-- Input Config-->
     	<InputXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Signed_Hexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Signed_Hexfile'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
      			<Variable>
					<Name>FILETYPE</Name>
					<Type>Simple</Type>
					<Value><xsl:call-template name="GetEnvironmentValue">
							<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>
    		</Variables>
		</InputXML>
	<xsl:if test="$ModeType='0'">
			 <xsl:if test="$DeviceType='1'">
	   	<!-- ABM Config-->
		<ABMXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_ABM_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_DEV5_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>ABMBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ABMBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>BMIBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BMI_BLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>				
			</Variables>	
		</ABMXML>
	
		 </xsl:if>
		 
		<xsl:if test="$DeviceType='0'">
     	<ABMXML>
         	 <TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_ABM_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_ABM_XML'"/></xsl:call-template></Script>
     		<Variables>
     			<Variable>
					<Name>ABMBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'ABMBLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>BMIBLOCKS</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BMI_BLOCKS'"/>
					</xsl:call-template></Value>
				</Variable>				
				<Variable>
					<Name>DEVICE_TYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					 <xsl:with-param name="LookUpItem" select="'MDG1_DEVICE_TYPE_ABM'"/>
				 </xsl:call-template></Value>
				</Variable>
			</Variables>	
		</ABMXML>
		 </xsl:if>
	</xsl:if>
     <!-- Output Config-->
    <OutputXML>
	    	<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModx_Output_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.xml'"/></Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_CHECKSUM_ADJUST_OUTPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
      			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
     			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\'"/>
							<xsl:call-template name="GetSoftwarePartNumber">
							</xsl:call-template><xsl:value-of select="'_Complete'"/><xsl:value-of select="'.hex'"/>
					</Value>
				</Variable> 
     		</Variables>
	</OutputXML>
	
  	<LogFileAnalyser>
		<Files>
			<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File>
			<!-- <File>
				<Classification>HexMod17-Infoblock-Logfile</Classification>
				<Key>HEXMOD17_INFOBLOCK</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_INFOBLOCK_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
			</File> -->
		</Files>
	</LogFileAnalyser>
	<PST_Library>
	</PST_Library>
	</HexModeInput>  
     <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
       <ToolLocation>
		   <xsl:call-template name="RunTime_Tool_Path">
			   <xsl:with-param name="ToolName" select="'HEXMODXVERSION_SIGN'"/>
		   </xsl:call-template>   
       </ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
