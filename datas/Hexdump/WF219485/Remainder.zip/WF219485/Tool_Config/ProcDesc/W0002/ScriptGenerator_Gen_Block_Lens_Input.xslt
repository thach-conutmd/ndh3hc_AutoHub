 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="AddressModelFile"  select="concat($WorkingDir, '\AddressModel.xml')" />
<xsl:variable name="InfotableLogFile"  select="concat($WorkingDir, '\InfotableLog.xml')" />

<xsl:template match="/">

    <ToolInput>
    <Mode> Prepare ADDRESS_MODEL_INFO file</Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>
				
			<Script>
										<Write2PSTLib>False</Write2PSTLib>
										<Key>ASW0_LENGTH</Key>
										<Comment>Script derive ASW0 length </Comment>
										<ScriptTemplate>
											<xsl:call-template name="GetEnvironmentValue">
												<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_BLOCK_LENGTH'" />
											</xsl:call-template>
										</ScriptTemplate>
										<DataBase>
										 <Datas>
											<STARTADDRESS>
												<xsl:call-template name="GetASW0BLOCK_STARTADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
											</STARTADDRESS>
											<ENDADDRESS>
												<xsl:call-template name="GetASW0BLOCK_ENDADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
											</ENDADDRESS>
										  </Datas>
										</DataBase>
			</Script>
			<Script>
										<Write2PSTLib>False</Write2PSTLib>
										<Key>DS0_LENGTH</Key>
										<Comment>Script derive DS0 length </Comment>
										<ScriptTemplate>
											<xsl:call-template name="GetEnvironmentValue">
												<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_BLOCK_LENGTH'" />
											</xsl:call-template>
										</ScriptTemplate>
										<DataBase>
										 <Datas>
											<STARTADDRESS>
												<xsl:call-template name="GetDS0BLOCK_STARTADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
											</STARTADDRESS>
											<ENDADDRESS>
												<xsl:call-template name="GetDS0BLOCK_ENDADDRESS">
													<xsl:with-param name="File">
													<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
													<xsl:value-of select="'\AddressModelInfo.xml'" />
													</xsl:with-param>
											</xsl:call-template>
											</ENDADDRESS>
										  </Datas>
										</DataBase>
			</Script>
		
		</Scripts>
		<PST_Library>
		</PST_Library>
		
    </Input>  
	
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
