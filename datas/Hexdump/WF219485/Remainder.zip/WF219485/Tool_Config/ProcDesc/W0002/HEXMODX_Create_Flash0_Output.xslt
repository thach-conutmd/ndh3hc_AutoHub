<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				<ResultingFiles>
					<File>
						<FileClassID>Flash0_HexFile_Full</FileClassID>
						<FileClassName>Flash0_HexFile_Full</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'Flash0_FullHexWithModASW0.hex'"/>
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>Flash0</FileClassID>
						<FileClassName>Flash0</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'Flash0_OnlyModASW0.hex'"/>
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>Flash0_Log</FileClassID>
						<FileClassName>Flash0_Log</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'HexmodX_Flash0.log'"/>
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>Detailelog_FLASH0_FullHex</FileClassID>
						<FileClassName>Detailelog_FLASH0_FullHex</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'Detailelog_FLASH0_FullHex.xml'"/>
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>Detailelog_FLASH0</FileClassID>
						<FileClassName>Detailelog_FLASH0</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'Detailelog_FLASH0.xml'"/>
							</Name>
						</Location>
					</File>
					<File>
						<FileClassID>FLASH_0_AdrMod</FileClassID>
						<FileClassName>FLASH_0_AdrMod</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'FLASH_0_AdrMod.xml'"/>
							</Name>
						</Location>
					</File>
				</ResultingFiles>
			</Output>
			<ReturnInformation>
				<ReturnCode/>
				<TimeStart/>
				<TimeFinish/>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
