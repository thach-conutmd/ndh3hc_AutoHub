<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
  <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
  cdata-section-elements="Key SearchExpression"/>
  <xsl:preserve-space elements="*"/>

  <!-- Parameter for Usecase-xml and PST-Libray -->
  <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>
  <xsl:param name="PRecentLoopCount"/>
 
  <!-- Variables for UsecaseData and Libraryfile -->
  <xsl:variable name="LibraryXML" select="$PLibraryXML"/>
  <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
  <xsl:variable name="CurrentIndex" select="$PRecentLoopCount"/>
  <xsl:variable name="NumberOfVariants" select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants" />


  <xsl:template match="/">

    <ToolInput>

      <Mode>Run_HexMod17 Patch and check</Mode>

      <HexModeInput>
        <WorkingDirectory>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
        </WorkingDirectory>

        <Modules>
          <Module>MainXML</Module>
          <Module>Input</Module>
          <!-- <Module>PatchCheck</Module> -->
          <!-- <Module>Infoblock</Module> -->
          <Module>Output</Module>

        </Modules>

        <!-- Main - Config -->
        <MainXML>
          <TemplateFile>
            <Directory>
              <xsl:call-template name="GetWorkingDirectory">
              </xsl:call-template>
            </Directory>
            <Name><xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_Main_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.xml'"/>
            </Name>
          </TemplateFile>

          <Script>
            <xsl:call-template name="GetEnvironmentValue">
              <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_MAIN_XML'"/>
            </xsl:call-template>
          </Script>

          <Variables>
            <Variable>
              <Name>HEXMOD_MAIN_LOGFILE</Name>
              <Value>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\HEXMOD_LOG_'"/>
                <xsl:call-template name="GetWorkFlowID">
                </xsl:call-template>
                <xsl:value-of select="'.log'"/>
              </Value>
            </Variable>
            <Variable>
              <Name>HEXMOD_INPUT_XML_NAME</Name>
              <Value>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\HEXMOD_PATCH_AND_CHECK_INPUT_'"/><xsl:call-template name="GetWorkFlowID"></xsl:call-template><xsl:value-of select="'.xml'"/>
              </Value>
            </Variable>
            <Variable>
              <Name>HEXMOD_OUTPUT_XML_NAME</Name>
              <Value>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\HEXMOD_PATCH_AND_CHECK_OUTPUT_'"/>
                <xsl:call-template name="GetWorkFlowID">
                </xsl:call-template>
                <xsl:value-of select="'.xml'"/>
              </Value>
            </Variable>
            
            <Variable>
              <Name>HEXMOD_PATCH_XML_NAME</Name>
              <Value>
                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                <xsl:value-of select="'\HEXMOD_EXECUTE_PATCH_'"/>
                <xsl:call-template name="GetWorkFlowID">
                </xsl:call-template>
                <xsl:value-of select="'.xml'"/>
              </Value>
            </Variable>
           

          </Variables>
        </MainXML>

        <!-- Input Config-->
        <Input>
          <TemplateFile>
            <Directory>
              <xsl:call-template name="GetWorkingDirectory">
              </xsl:call-template>
            </Directory>
            <Name>
              <xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_INPUT_'"/>
              <xsl:call-template name="GetWorkFlowID">
              </xsl:call-template>
              <xsl:value-of select="'.xml'"/>
            </Name>
          </TemplateFile>

          <Script>
            <xsl:call-template name="GetEnvironmentValue">
              <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_INPUT_XML'"/>
            </xsl:call-template>
          </Script>

          <Variables>
            <Variable>
              <Name>FILETYPE</Name>
              <Value>
                <xsl:call-template name="GetEnvironmentValue">
                  <xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/>
                </xsl:call-template>
              </Value>
            </Variable>
            <Variable>
              <Name>HEXFILE</Name>
              <Value>
			  <xsl:choose>
			  <xsl:when test="$NumberOfVariants='0'">
                <xsl:call-template name="FileList_GetFileDirectory">
                <xsl:with-param name="FileClassID">
                  <xsl:value-of select="'INTEGRATIONFILE'"/>
                </xsl:with-param>
                <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
              <!--   <xsl:value-of select="'\'"/> -->
                <xsl:call-template name="FileList_GetFileName">
                <xsl:with-param name="FileClassID">
                  <xsl:value-of select="'INTEGRATIONFILE'"/>
                </xsl:with-param>
                <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
				</xsl:when>
				<xsl:otherwise>
				<xsl:call-template name="FileList_GetFileDirectory">
                <xsl:with-param name="FileClassID">
                  <xsl:value-of select="'AppliedFile_'"/>
                  <xsl:value-of select="$CurrentIndex"/>
                </xsl:with-param>
                <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
              <!--   <xsl:value-of select="'\'"/> -->
                <xsl:call-template name="FileList_GetFileName">
                <xsl:with-param name="FileClassID">
                  <xsl:value-of select="'AppliedFile_'"/>
                  <xsl:value-of select="$CurrentIndex"/>
                </xsl:with-param>
                <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>
				
				</xsl:otherwise>
				</xsl:choose>
              </Value>
            </Variable>
			<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'MODE_TYPE'"/></xsl:call-template></Value>
				</Variable>


          </Variables>
        </Input>

        <Output>

          <TemplateFile>
            <Directory>
              <xsl:call-template name="GetWorkingDirectory">
              </xsl:call-template>
            </Directory>
            <Name>
              <xsl:value-of select="'HEXMOD_PATCH_AND_CHECK_OUTPUT_'"/>
              <xsl:call-template name="GetWorkFlowID">
              </xsl:call-template>
              <xsl:value-of select="'.xml'"/>
            </Name>
          </TemplateFile>

          <Script>
            <xsl:call-template name="GetEnvironmentValue">
              <xsl:with-param name="LookUpItem" select="'HEXMOD_PATCHCHECK_OUTPUT_XML'"/>
            </xsl:call-template>
          </Script>

          <Variables>
            <Variable>
              <Name>FILETYPE</Name>
              <Value>
                <xsl:call-template name="GetEnvironmentValue">
                  <xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/>
                </xsl:call-template>
              </Value>
            </Variable>
            <Variable>
              <Name>HEXFILE</Name>
              <Value>
			  <xsl:choose>
				<xsl:when test="$NumberOfVariants='0'">
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
					<xsl:value-of select="'_Patched.hex'"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					<xsl:value-of select="'\'"/>
					<xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template>
					<xsl:value-of select="'_Patched_'"/>
					<xsl:value-of select="$CurrentIndex"/>
					<xsl:value-of select="'.hex'"/>
				</xsl:otherwise>
			  </xsl:choose>
              </Value>
            </Variable>
          </Variables>
        </Output>

        <LogFileAnalyser>
          <Files>
            <File>
              <Classification>Hexmod17-Patched-Main-Logfile</Classification>
              <Key>HEXMOD17_MAIN</Key>
              <Directory>
                <xsl:call-template name="GetWorkingDirectory">
                </xsl:call-template>
              </Directory>
              <Name>
                <xsl:value-of select="'HEXMOD_LOG_'"/>
                <xsl:call-template name="GetWorkFlowID">
                </xsl:call-template>
                <xsl:value-of select="'.log'"/>
              </Name>
            </File>
          </Files>
        </LogFileAnalyser>
        <PST_Library>
        </PST_Library>
      </HexModeInput>
      <CallInformation>
        <ToolName>HEXMODVERSION</ToolName>
        <CallType></CallType>
        <ToolVersion></ToolVersion>
        <ToolLocation>
          <xsl:call-template name="RunTime_Tool_Path">
	          <xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
      </xsl:call-template>
        </ToolLocation>
        <InputVerification></InputVerification>
      </CallInformation>
    </ToolInput>
  </xsl:template>
</xsl:stylesheet>
