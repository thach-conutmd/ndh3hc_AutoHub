<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 
 <xsl:variable name="RT_FEE_EMULATION_TYPE_HSM" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='FEE_EMULATION_TYPE_HSM']/tctypes:Value"/>
<xsl:variable name="RT_FEE_EMULATION_TYPE_HOST" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='FEE_EMULATION_TYPE_HOST']/tctypes:Value"/>

 <xsl:variable name="RT_BOOT_MODE_INDEX" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='BOOT_MODE_INDEX']"/>
<xsl:variable name="RT_CFGEXP_MACHINE_DEV" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_MACHINE_DEV']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_MACHINE_TYPE']/tctypes:Value"/>
<xsl:variable name="RT_SECURITY_VARIANT" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='SECURITY_VARIANT']/tctypes:Value"/>
<xsl:variable name="RT_GUAM_FLAG" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='GUAM_FLAG']/tctypes:Value"/>			


</xsl:stylesheet>