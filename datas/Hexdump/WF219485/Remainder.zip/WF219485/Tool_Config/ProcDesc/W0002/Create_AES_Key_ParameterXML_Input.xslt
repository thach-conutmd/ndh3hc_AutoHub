	<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


    <xsl:template match="/">
    <ToolInput>
		<Mode>Extract AES key Parameters for Container </Mode>
       <Input>
           
		<!-- Init-Values for Progress-Display -->
		<EstimatedRunTime>10</EstimatedRunTime>	<!-- 10 Minutes-->
		<DateTimeInterval>1</DateTimeInterval>	<!-- 1 = Minutes  / 0 = Seconds-->			
		
			
	<Files>
		<Valid_Template_File>		
			<Directory>
				<xsl:call-template name="path_from_pathfile">
					<xsl:with-param name="pathfile">
					<xsl:call-template name="GetAESTemplateFile_ConfigPath"></xsl:call-template>
					</xsl:with-param>					
				</xsl:call-template>
			</Directory>
			<Name>
				<xsl:call-template name="file_from_pathfile">
					<xsl:with-param name="pathfile">
					<xsl:call-template name="GetAESTemplateFile_ConfigPath"></xsl:call-template>
					</xsl:with-param>					
				</xsl:call-template>
			</Name>
		</Valid_Template_File>
		
		<FSW_AES_ConfigFile>
			<Directory>
				<xsl:call-template name="FileList_GetFileDirectory">
					<xsl:with-param name="FileClassID" select="'FSW_AESKEY_BLOCK'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Directory>
			<Name>
				<xsl:call-template name="FileList_GetFileName">
					<xsl:with-param name="FileClassID" select="'FSW_AESKEY_BLOCK'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Name>	
		</FSW_AES_ConfigFile>
		
		<AES_Key_ConfigFile>
			<Directory>
				<xsl:call-template name="FileList_GetFileDirectory">
					<xsl:with-param name="FileClassID" select="'ECUSECU_AESKEYS_ARXML'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Directory>
			<Name>
				<xsl:call-template name="FileList_GetFileName">
					<xsl:with-param name="FileClassID" select="'ECUSECU_AESKEYS_ARXML'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
				</xsl:call-template>
			</Name>
		</AES_Key_ConfigFile>	
		
		<Log_File>
			<Directory>
				<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
			</Directory>
			<Name><xsl:value-of select="'AES_Keys.log'"/></Name>
		</Log_File>
	</Files>
					   	
	    <ReadVaraibeList>
	       <Variables>
	        <Variable>
	         <ID></ID> 
	         <Xpath></Xpath> 
	         </Variable>
	         </Variables>
		</ReadVaraibeList>		

		<LogFileAnalyser>
			<Files>
				</Files>
		</LogFileAnalyser>	
    </Input>      
   	</ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
