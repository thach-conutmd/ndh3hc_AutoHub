<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Create Signature from Signed hash text file</Mode>
			<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
			<InputFile>
				<Directory>
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
						<xsl:with-param name="FileClassID" select="'SignTool17_Reprog_HashValue'" />
						<xsl:with-param name="GetValue" select="'yes'" />
					</xsl:call-template>
				</Directory>
				<Name>
					<xsl:call-template name="RunTime_FileList_GetFileName">
						<xsl:with-param name="FileClassID" select="'SignTool17_Reprog_HashValue'" />
						<xsl:with-param name="GetValue" select="'yes'" />
					</xsl:call-template>
				</Name>
			</InputFile>
			<InputData>
				<ByteBlockLength>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BYTE_BLOCK_LENGTH'" />
					</xsl:call-template>
				</ByteBlockLength>
				<Pattern>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'PATTERN_CREATE_BINFILE_FROM_HASHFILE'" />
					</xsl:call-template>
				</Pattern>
				<CertificatePattern>
					<![CDATA[\["[^"]*", 0x.., \((?'Bytes'0x[0-9|A-F][0-9|A-F](, )?)*\)]]]>
				</CertificatePattern>
				<DataLength><![CDATA[16]]></DataLength>
				<Address_Offset><![CDATA[0000]]></Address_Offset>
				<FileEndFormat><![CDATA[:00000001FF]]></FileEndFormat>
				<FileStartFormat><!--<![CDATA[:020000040000]]>--></FileStartFormat>
				<ModeType>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'MODE_TYPE'" />
					</xsl:call-template>
				</ModeType>
			</InputData>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
