<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Derive Blocks for Sign tool</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Default Blocks for Sign tool Value</DefaultValueMessage>
     	<ConfigFile>
			<Name><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'SIGN_TOOL_BLOCK_DERIVATION_MATRIX_NAME'"/></xsl:call-template></Name>
				
			<Directory>	
			<!-- <xsl:call-template name="GetSignTool_MatrixPath"></xsl:call-template> -->
				<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'MATRIX_PATH'"/>
				</xsl:call-template>
			</Directory>						
		</ConfigFile>	
		<Variables>		
			<Variable>
				<Name>CustomerGroup</Name>
				<Value>
                <xsl:call-template name="GetCustomerGroup"></xsl:call-template>
         			</Value>
			</Variable>
			<Variable>
				<Name>ECU_Designation</Name>
				<Value>
                <xsl:call-template name="GetECUDesignation"></xsl:call-template>
         			</Value>
			</Variable>
			<Variable>
				<Name>Brand</Name>
				<Value>
                <xsl:call-template name="GetBrand"></xsl:call-template>
         			</Value>
			</Variable>
				<Variable>
				<Name>PVERNAME</Name>
				<Value>
                <xsl:call-template name="GetPSTNAME"></xsl:call-template>
         			</Value>
			</Variable>
			<Variable>
				<Name>WorkingMode</Name>
				<Value>
                <xsl:call-template name="GetWorkingMode"></xsl:call-template>
         			</Value>
			</Variable>			
		</Variables> 
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
