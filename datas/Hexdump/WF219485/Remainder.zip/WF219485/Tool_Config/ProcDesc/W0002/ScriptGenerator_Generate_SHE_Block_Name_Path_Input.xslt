<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
  <xsl:import href="ToolChainExtractionLib.xslt" />
  <xsl:import href="ToolChainEnvironmentExtraction.xslt" />
  <xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
  <xsl:preserve-space elements="*" />
  <!-- Parameter for Usecase-xml and PST-Libray -->
  <xsl:param name="PLibraryXML" />
  <xsl:param name="PUseCaseXML" />
  <!-- Variables for UsecaseData and Libraryfile -->
  <xsl:variable name="LibraryXML" select="$PLibraryXML" />
  <xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
   <xsl:variable name="AddressModelFile" select="concat($WorkingDir, '\AddressModel.xml')" />

  <xsl:template match="/">
    <ToolInput>
      <Mode>Script Generator : Generate XPATH for Label and Context</Mode>
      <Input>
        <WorkingDirectory>
          <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
        </WorkingDirectory>
        <Scripts>
          <Script>
            <Write2PSTLib>False</Write2PSTLib>
            <Key>KDF_SLOTNAME</Key>
            <Comment>SCRIPT_REPLACE_XPATH_SHE_KEY</Comment>
            <ScriptTemplate>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_REPLACE_XPATH_SHE_KEY'" />
              </xsl:call-template>
			 
            </ScriptTemplate>
            <DataBase>
                <SHE_Block>
					<!-- From TUT -->
					<xsl:call-template name="GetSHE_Block"></xsl:call-template>
				</SHE_Block>
				<SHE_Parameter>
					<xsl:value-of select="'SHE_NEW_KEY'" />
				</SHE_Parameter>
            </DataBase>
          </Script>
		  <Script>
            <Write2PSTLib>False</Write2PSTLib>
            <Key>KDF_LABEL</Key>
            <Comment>SCRIPT_REPLACE_XPATH_SHE_KEY</Comment>
            <ScriptTemplate>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_REPLACE_XPATH_SHE_KEY'" />
              </xsl:call-template>
			 
            </ScriptTemplate>
            <DataBase>
                <SHE_Block>
					<!-- From TUT -->
					<xsl:call-template name="GetSHE_Block"></xsl:call-template>
				</SHE_Block>
				<SHE_Parameter>
					<xsl:value-of select="'SHE_NEW_KEY_CONTEXT'" />
				</SHE_Parameter>
            </DataBase>
          </Script>
        </Scripts>
      </Input>
      <CallInformation>
        <ToolName></ToolName>
        <CallType></CallType>
        <ToolVersion></ToolVersion>
        <ToolLocation></ToolLocation>
        <InputVerification></InputVerification>
      </CallInformation>
    </ToolInput>
  </xsl:template>
</xsl:stylesheet>
