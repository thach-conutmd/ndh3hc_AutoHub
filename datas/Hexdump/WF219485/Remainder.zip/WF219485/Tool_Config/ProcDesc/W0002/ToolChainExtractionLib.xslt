<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:output method="xml" omit-xml-declaration='yes' 
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

	<xsl:template name="GetFlashBlockCount">		
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:FlashBlocks/tctypes:FlashBlockCount"/>		
	</xsl:template>
	
		<xsl:template name="GetIgnore_Blocks">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Ignore_Blocks" />
	</xsl:template>
	
	<xsl:template name="GetConfigFolder">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PDT_Config"/>
	</xsl:template>
	
	<xsl:template name="GetAdditionalUseCaseDataFile">
		<xsl:choose>
			<xsl:when test="/tctypes:UseCase/tctypes:Data/tctypes:WorkFlowID[@WorkFlowSystem='Flow5']">
				<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkFlowID"/>.xml</xsl:when>
		</xsl:choose>
	</xsl:template>
	
	<xsl:template name="GetUNC_T_Drive">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:UNC_T_Drive"/>		
	</xsl:template>
	
	<xsl:template name="GetGUAM_FLAG">
		<xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:GUAM_FLAG"/>
		<xsl:choose>
			<xsl:when test="$FlagValue = '2'">
				<xsl:value-of select="'2'"/>						
			</xsl:when>	 
			<xsl:otherwise>	
				<xsl:value-of select="'1'"/> 
			</xsl:otherwise>				
		</xsl:choose> 
  </xsl:template>
  <!-- Kv -->
  <xsl:template name="UpdateGUAM_FLAG">
		 <xsl:param name="Flag" />
		<xsl:variable name="FlagValue" select="$Flag"/>
		<xsl:choose>
			<xsl:when test="$FlagValue = '2'">
				<xsl:value-of select="'2'"/>						
			</xsl:when>	 
			<xsl:otherwise>	
				<xsl:value-of select="'1'"/> 
			</xsl:otherwise>				
		</xsl:choose> 
  </xsl:template>
  
  	<xsl:template name="GetPSTNAME">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PSTName" />
	</xsl:template>
		<xsl:template name="GetWorkingMode">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingMode" />
	</xsl:template>
  
	<xsl:template name="GetEOLProgramming">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:EOL_ProgrammingOEM" />
	</xsl:template>
	
	<xsl:template name="GetRawMcsVersionPath">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:RAW_MCS_VERSION_PATH" />
	</xsl:template>
	
	<xsl:template name="GetTBHandlingFlag">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:TB_HANDLING_FLAG" />
	</xsl:template>
	
	<xsl:template name="GetSecumgrHSMFlag">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SECUMGR_HSM_FLAG" />
	</xsl:template>
	
	<xsl:template name="GetSignTool_MatrixPath">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SignTool_MatrixPath" />
	</xsl:template>
	
	<xsl:template name="GetMatrixPath">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:MATRIX_PATH" />
	</xsl:template>
	
	<xsl:template name="GetOTPKeyRefLog_FilePath">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:OTP_KEY_REF_LOG_FILEPATH" />
	</xsl:template>
	
	<xsl:template name="GetOTPEnvTypeNumber">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:OTP_ENV_TYPE_NUMBER" />
	</xsl:template>
	
	<xsl:template name="GetVariableListDoserPatchesFile">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VARIABLELIST_DOSERPATCH_PATCHES_FILE" />
	</xsl:template>
	
	<xsl:template name="GetFillRange">			
		<xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:InfoConfigRanges"/>			
	</xsl:template>
	
	<xsl:template name="GetCustomerGroup">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerGroup"/>		
	</xsl:template>
	
	<xsl:template name="GetOTPCONDITIONCHECKFILE">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:OTP_CONDITIONCHECK_FILE"/>		
	</xsl:template>
	
	<xsl:template name="GetTP_Mask">
			 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:TP_Mask"/>
	</xsl:template>
	
	<xsl:template name="GetSignFlagValue">
			  <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Sign_Flag"/>
	</xsl:template>
	
	<xsl:template name="GetAddressLayoutModel">
	    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel"/>
	</xsl:template>
	
	<xsl:template name="GetCustomerIndentityIndex_Dec">
	    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:OTP_CUSTOMERIDENTITY_INDEX_DEC"/>
	</xsl:template>
	
	<xsl:template name="GetCustomerIndentityIndex_Hex">
	    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:OTP_CUSTOMERIDENTITY_INDEX_HEX"/>
	</xsl:template>
	
	<xsl:template name="GetFlashLevel">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FLASH_SIGNED"/>
	</xsl:template>	
	
	<xsl:template name="GetReleaseClass">
		    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ReleaseClass"/>
	</xsl:template>	
	
	<xsl:template name="GetHSMLevel">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HSM_SIGNED"/>
	</xsl:template>	
	
	<xsl:template name="GetHSMAddFeature">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HSM_AddFeature"/>
	</xsl:template>	
	
	<xsl:template name="GetDebugLevel">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Debug_Level"/>
	</xsl:template>
	
	<xsl:template name="GetCMBTYP_SY">
		    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CMBTYP_SY"/>
	</xsl:template>
	
	<xsl:template name="GetFSWID">
	    <xsl:variable name="ProgramVersion" select="/tctypes:UseCase/tctypes:Data/tctypes:FSWID_ProgramVersion"/>
	    <xsl:variable name="ProjectVersion" select="/tctypes:UseCase/tctypes:Data/tctypes:FSWID_ProjectVersion"/>
	    <xsl:value-of select="concat($ProjectVersion,$ProgramVersion)"/>
	  </xsl:template>  
	
	<xsl:template name="GetSGIDB1">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SGIDB1"/>
	</xsl:template>
	
	<xsl:template name="GetSGIDB2">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SGIDB2"/>
	</xsl:template>
			
	<xsl:template name="GetSGIDB3">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SGIDB3"/>
	</xsl:template>
		
	<xsl:template name="GetSGIDB7">
	 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SGIDB7"/>
	</xsl:template>
	
	<xsl:template name="GetODXFileID">
		 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ODXFileID"/>
	</xsl:template>
	
	<xsl:template name="GetODXFileVersion">
			 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ODXFileVersion"/>
	</xsl:template>
	
	<xsl:template name="GetCustomerHardwarePartNumber">
		 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerHardwarePartNumber"/>
	</xsl:template>
	
	<xsl:template name="GetPatchKeyID">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PatchKeyID"/>		
	</xsl:template>
	
	<xsl:template name="GetWorking_Mode">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Working_Mode"/>		
	</xsl:template>
	
	<xsl:template name="GetContainerType">
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ContainerType"/>		
	</xsl:template>
	
	<xsl:template name="GetFlash0_Required">
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Flash0_Required"/>		
	</xsl:template>
	
	<xsl:template name="GetSHE_Block">
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SHE_Block"/>		
	</xsl:template>
	<xsl:template name="GetCoreMaster">
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CoreMaster"/>		
	</xsl:template>
	
	<xsl:template name="GetBuildMode">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:BuildMode"/>
  	</xsl:template>
  
	<xsl:template name="GetDatasToWorkFlow">
	    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ToWorkFlow"/>
	</xsl:template>

	<xsl:template name="GetProgramFilesDirectory">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ProgramFilesDirectory "/>
	</xsl:template>	
	<xsl:template name="GetECUDesignation">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECU_Designation"/>
	</xsl:template>
	<xsl:template name="Get_BootContainerFlag">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:BootContainerFlag"/>
	</xsl:template>
	<xsl:template name="GetComponentID_Flag">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ComponentID_Flag"/>
	</xsl:template>
	<xsl:template name="GetBrand">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Brand"/>
	</xsl:template>

	<xsl:template name="GetHardwarePartNumber">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:HardwarePartNumber"/>
	</xsl:template>
	
	<xsl:template name="GetReleaseScope">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ReleaseScope"/>
	</xsl:template>
	
	 <xsl:template name="GetSECURITY_VARIANT">
		<xsl:param name="SECURITY_VARIANT_Value"/>
		<xsl:choose>
			<xsl:when test="$SECURITY_VARIANT_Value = '2'">
				<xsl:value-of select="'2'"/>						
			</xsl:when>	 
			<xsl:otherwise>	
				<xsl:value-of select="'1'"/> 
			</xsl:otherwise>				
		</xsl:choose> 
	</xsl:template>
	
	<xsl:template name="GetSoftwareName">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SoftwareName"/>
	</xsl:template>

	<xsl:template name="GetWorkingDirectory">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory"/> 
	</xsl:template> 

	<xsl:template name="GetSoftwarePartNumber">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SoftwarePartNumber"/>
	</xsl:template> 

	<xsl:template name="GetRegularChangeNumber">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:RegularChangeNumber"/>
	</xsl:template>

	<xsl:template name="GetKWP2000VAG">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:KWP2000VAG"/>
	</xsl:template>
	
	<xsl:template name="GetWorkFlowID">
	<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkFlowID"/>		
	</xsl:template>
	
	<xsl:template name="GetSoftwareVersion">
	<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SW_Version"/>		
	</xsl:template>

	<xsl:template name="GetKundenKennzahl">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:ReadMatrixInfo/tctypes:KundenKennzahl/tctypes:Value"/>
	</xsl:template>
	
	<xsl:template name="GetIntegrationFileNameNEXT">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:IntegrationFileNameNEXT"/>
	</xsl:template>
	
	<xsl:template name="GetTPLevelValue">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:TP_Level"/>
	</xsl:template>
	
	<xsl:template name="GetAddressLayout">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayout"/>
	</xsl:template>

	<xsl:template name="GetFEOLOC_Flag">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FEOLOC_Flag"/>
	</xsl:template>
	
	<xsl:template name="GetFEOLOC_Select">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FEOLOC_Select"/>
	</xsl:template>
	
	
	<xsl:template name="GetECUMEM_Version">
		    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECUMEM_Version"/>
	</xsl:template>
	<xsl:template name="GetContainerType_ID">
			    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ContainerType_ID"/>
	</xsl:template>
	
	
<!-- Extraktionen auf Filelisten-->
	<xsl:template name="FileList_GetFileDirectory">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
		<xsl:choose>
			<xsl:when test="$GetValue='yes'">
		        <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
			</xsl:when>		
  		    <xsl:otherwise>
		        <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template name="FileList_GetFileName">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
        <xsl:param name="GetExtension" select="'yes'"/>
        <xsl:variable name="File" select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
        <xsl:choose>
 			<xsl:when test="$GetValue='yes'">
 				    <xsl:choose>
 						<xsl:when test="$GetExtension='yes'">
 							<xsl:value-of select="$File"/> 											 				
	 					</xsl:when>
  						<xsl:otherwise>
  							<xsl:value-of select="substring($File, 1, string-length($File) - 4)"/>
  						</xsl:otherwise>
  					</xsl:choose>
			</xsl:when>
  		    <xsl:otherwise>
 			    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

<!-- Extraction Runtime-Range	-->
<!-- FileLists -->
<!-- Extraktionen auf Filelisten-->
	<xsl:template name="RunTime_FileList_GetFileDirectory">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
		<xsl:choose>
			<xsl:when test="$GetValue='yes'">
		        <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>
			</xsl:when>		
  		    <xsl:otherwise>
		        <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	
	<xsl:template name="RunTime_FileList_GetFileName">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
        <xsl:param name="GetExtension" select="'yes'"/>
        <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>       
        <xsl:choose>
 			<xsl:when test="$GetValue='yes'">
 				    <xsl:choose>
 						<xsl:when test="$GetExtension='yes'">
 							<xsl:value-of select="$File_Runtime"/> 											 				
	 					</xsl:when>
  						<xsl:otherwise>
  							<xsl:value-of select="substring($File_Runtime, 1, string-length($File_Runtime) - 4)"/>
  						</xsl:otherwise>
  					</xsl:choose>
			</xsl:when>
  		    <xsl:otherwise>
 			    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	<xsl:template name="FileList_GetCheckSumValue" >
		<xsl:param name="FileClassID" />
		<xsl:param name="CheckSumClassID"/>
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/
	       tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:CheckSums/
	       tctypes:CheckSum[child::tctypes:CheckSumClassID=$CheckSumClassID]/
	       tctypes:CheckSumValue"/>
	</xsl:template>
	
	<xsl:template name="RunTime_Data_List_Variables" >
		<xsl:param name="DataClassID" />
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Variables/*"/>
	</xsl:template>
	<xsl:template name="RunTime_Data_Value_Variable" >
		<xsl:param name="DataClassID" />
		<xsl:param name="VariableName" />
		<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Variables/tctypes:Variable[child::tctypes:Name=$VariableName]/tctypes:Value"/>
	</xsl:template>
	<xsl:template name="RunTime_Data_ValueNode" >
		<xsl:param name="DataClassID" />
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value/*"/>
	</xsl:template>

	<xsl:template name="RunTime_Data_PreCondNode" >
		<xsl:param name="DataClassID" />
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:PRECOND/*"/>
	</xsl:template>

	<xsl:template name="RunTime_Data_Value" >
		<xsl:param name="DataClassID" />
		<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value"/>
	</xsl:template>

		

	<xsl:template name="GetPDTools">
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:PD_TOOLNAMES" />
	</xsl:template>
	<xsl:template name="GetRunMode">
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:RUN_MODE" />
	</xsl:template>

	<xsl:template name="RunTime_Tool_Path">
		<xsl:param name="ToolName" />
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/*" />
	</xsl:template>

	<xsl:template name="GetWrapperPath">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WrapperPath "/>
	</xsl:template>

	<xsl:template mode="myCopy" match="*">
		<xsl:element name="{name(.)}">
			<xsl:copy-of select="@*" />
			<xsl:apply-templates mode="myCopy" />
		</xsl:element>
	</xsl:template>
	
	<xsl:template name="GetXMLFile">
		<xsl:param name="File" />
		<xsl:apply-templates mode="myCopy" select="document($File)/*"/>	
	</xsl:template>
	
	<xsl:template name="GetXMLFromFile">
		<xsl:param name="File" />
		<xsl:copy-of select="document($File)/*"/>
	</xsl:template>

<xsl:template name="GetInfoblockCount">
			<xsl:param name="File" />
			<xsl:value-of select="document($File)/DATA/ADDRESSLAYOUTMODEL/INFOBLK_COUNT"/> 
	</xsl:template>
	
  <xsl:template name="GetSBBLOCK_STARTADDRESS">
    <xsl:param name="File" />
    <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='10']/START_ADDRESS"/>
  </xsl:template>
	
	 <xsl:template name="GetHSM_STARTADDRESS">
	    <xsl:param name="BlockName"/>
	    <xsl:param name="File" />
	    <xsl:value-of select="document($File)/ADDRESSMODEL/SOURCE[@ID='ECU_DATA']/ADRESS_RANGES/ADRESS_RANGE[@ID=$BlockName]/TARGET-ADDRESS/START"/>
	    
	  </xsl:template>
	
	  <xsl:template name="GetHSM_ENDADDRESS">
	    <xsl:param name="BlockName"/>
	    <xsl:param name="File" />    
	    <xsl:value-of select="document($File)/ADDRESSMODEL/SOURCE[@ID='ECU_DATA']/ADRESS_RANGES/ADRESS_RANGE[@ID=$BlockName]/TARGET-ADDRESS/END"/>	   
	    
 	 </xsl:template>
	
	<xsl:template name="GetToolVersion_ConfigHexmod">
				    <xsl:param name="pathfile"/>
				   <xsl:choose>
				            <xsl:when test="contains($pathfile,'\')">
				                <xsl:value-of select="substring-after($pathfile,'confighexmod\')" />		               
				            </xsl:when>
				            <xsl:otherwise />
				        </xsl:choose>
		  	</xsl:template>
		  	
		  	<xsl:template name="GetConfigHexmodTool_Path">
				       <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME='CONFIGHEXMODVERSION']/tctypes:Location/tctypes:Directory" />
  	</xsl:template>
  	
  	<xsl:template name="GetCONFDATA2CONF_FILE_Path">
		      <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME='CONFDATA2CONF_FILE']/tctypes:Location/tctypes:Directory" />
  	</xsl:template>
  <xsl:template name="ConvertToUpperCase">
    <xsl:param name="string" />
    <xsl:value-of select="translate($string, 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
  </xsl:template>
  
  <xsl:template name="RunTime_Tool_Directory">
  		<xsl:param name="ToolName" />
  		<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/tctypes:Directory" />
  	</xsl:template>
  
  	<xsl:template name="RunTime_Tool_Name">
  		<xsl:param name="ToolName" />
  		<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/tctypes:Name" />
	</xsl:template>
  	
  	<xsl:template name="CheckJDPOrInfineon">
			<xsl:param name="ModeType" />
			<xsl:variable name="ModeTypeToUpper">
				<xsl:call-template name="ConvertToUpperCase" >
					<xsl:with-param name="string" select ="$ModeType"/>
				</xsl:call-template>
			</xsl:variable>
			<xsl:choose>
				<xsl:when test="$ModeTypeToUpper = 'BIGENDIAN'">
					<xsl:value-of select="'1'"/>
				</xsl:when>
				<xsl:when test="$ModeTypeToUpper = 'LITTLEENDIAN'">
					<xsl:value-of select="'0'"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="''"/>
				</xsl:otherwise>
			</xsl:choose>
	</xsl:template>
	
			<xsl:template name="GetRAWMCSFilePath">		
						<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FSW_ConfigPath"/>		
					</xsl:template>
											
			<xsl:template name="GetVarilableListVersion">		
				<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VarilableListVersion"/>		
		</xsl:template>
	
	
	<!--Create a dynamic variable list -->
	  <xsl:template name="CreateVariableList">
	    <xsl:param name="File" />
	    <xsl:for-each select="document($File)/Config/Variables/Variable">
	      <xsl:variable name="SourceType" select="SourceType" />
	      <xsl:variable name="Source" select="Source" />
	      <xsl:element name="Variable">
	        <xsl:element name="Name">
	          <xsl:value-of select="Name" />
	        </xsl:element>
	        <xsl:element name="Value">
	          <xsl:choose>
	            <xsl:when test="$SourceType = 'HRD'">
	              <xsl:value-of select="$Source" disable-output-escaping="yes" />
	            </xsl:when>
	            <xsl:when test="$SourceType = 'DATA'">
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:*[name()=$Source]"/>
	            </xsl:when>
	            <xsl:when test="$SourceType = 'DATA_R'">
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$Source]/tctypes:Value"/>
	            </xsl:when>
	            <xsl:when test="$SourceType = 'FILE'">
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
	              <xsl:value-of select="'\'"/>
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
	            </xsl:when>
	            <xsl:when test="$SourceType = 'FILE_R'">
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
	              <xsl:value-of select="'\'"/>
	              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
	            </xsl:when>
	            <xsl:when test="$SourceType = 'LIB'">
	              <xsl:call-template name="GetEnvironmentValue">
	                <xsl:with-param name="LookUpItem" select="$Source" />
	              </xsl:call-template>
	            </xsl:when>
	            <xsl:otherwise></xsl:otherwise>
	          </xsl:choose>
	        </xsl:element>
	        <xsl:element name="Mandatory">
	          <xsl:value-of select="Mandatory" />
	        </xsl:element>
	      </xsl:element>
	    </xsl:for-each>
  </xsl:template>
  
  <xsl:template name="GetFEE_Block_ConfigPath">
  	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FEE_Block_Config"/>
	</xsl:template>	
	
  <xsl:template name="GetFSW_DPTR_ConfigPath">
      	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:FSW_DPTR_Config"/>
</xsl:template>	

     <xsl:template name="path_from_pathfile">
      <xsl:param name="pathfile"/>
     <xsl:choose>
              <xsl:when test="contains($pathfile,'\')">
                  <xsl:value-of select="substring-before($pathfile,'\')" />
                  <xsl:text>\</xsl:text>
                  <xsl:call-template name="path_from_pathfile">
                      <xsl:with-param name="pathfile" select="substring-after($pathfile,'\')" />
                  </xsl:call-template>
              </xsl:when>
              <xsl:otherwise />
          </xsl:choose>
    </xsl:template>
    
<xsl:template name="file_from_pathfile">
    <xsl:param name="pathfile"/>
   <xsl:choose>
            <xsl:when test="contains($pathfile,'\')">                
                <xsl:call-template name="file_from_pathfile">
                    <xsl:with-param name="pathfile" select="substring-after($pathfile,'\')" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$pathfile"/>
            </xsl:otherwise>
        </xsl:choose>
  </xsl:template>

  <xsl:template name="GetSignedParameter">
  	<xsl:param name="FlashSignedFlag"/>
  	<xsl:param name="HSMSignedFlag"/>  	    
  	    <xsl:value-of select="concat($FlashSignedFlag,$HSMSignedFlag)"/>
  </xsl:template>  
  
  <xsl:template name="GetTPBLOCK_STARTADDRESS">
      <xsl:param name="File" />
      <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='20']/START_ADDRESS"/>
  </xsl:template>
  
  <xsl:template name="GetTPBLOCK_BLOCKID">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='20']/BLOCKID"/>
  </xsl:template>
  
  <xsl:template name="ReplaceString">
    <xsl:param name="text" />
    <xsl:param name="replace" />
    <xsl:param name="by" />
    <xsl:choose>
      <xsl:when test="contains($text, $replace)">
        <xsl:value-of select="substring-before($text,$replace)" />
        <xsl:value-of select="$by" />
        <xsl:call-template name="ReplaceString">
          <xsl:with-param name="text" select="substring-after($text,$replace)" />
          <xsl:with-param name="replace" select="$replace" />
          <xsl:with-param name="by" select="$by" />
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$text" />
      </xsl:otherwise>
    </xsl:choose>
</xsl:template>

<xsl:template name="GetCustomerSWVersion_BSW">
	<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerSWVersion_BSW"/>		
</xsl:template>
<xsl:template name="RunTime_Data_Value_Node" >
		<xsl:param name="DataClassID" />
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value/tctypes:Value"/>
	</xsl:template>

<xsl:template name="GetCustomerHWIdentVersion_BSW">
	<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerHWIdentVersion_BSW"/>		
</xsl:template>

<xsl:template name="GetInfoBlockChecksum" >
		<xsl:param name="DataClassID" />	
		<xsl:for-each select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Variables/tctypes:Variable">
			<xsl:variable name="iCount" select="position()"/>
			<xsl:variable name="CKSChecksum" select="tctypes:Value"/>
			<xsl:choose>
		   			<xsl:when test="$iCount = 1">
						<xsl:value-of select="$CKSChecksum"/>	
					</xsl:when>	 
					<xsl:otherwise>
						<xsl:value-of select="concat(',',$CKSChecksum)"/>	
					</xsl:otherwise>				
			</xsl:choose> 															
		</xsl:for-each>			
	</xsl:template>
  
  <xsl:template name="GetLogisticNumber">
  		<xsl:param name="File" />
  		<xsl:value-of select="document($File)/LOG/PATCHCHECK/LABELS[child::NAME='LOGISTIC_NUMBERS']/OLD_VAL"/>
	</xsl:template>
  
   <xsl:template name="GetVCFileCount">
      <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VCFileCount "/>
    </xsl:template>
  
    <xsl:template name="GetFileList">
      <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files"/>
  </xsl:template>
  <xsl:template name="GetRAWkey">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/LOG/PATCHCHECK/LABELS/OLD_VAL"/>
    </xsl:template>
  <xsl:template name="GetASW0BLOCK_STARTADDRESS_ADDRESSMODEL">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/DATA/ADDRESSLAYOUTMODEL/BLOCK[NAME='ASW0']/CSO_ABSOLUTE/@START"/>
    </xsl:template>
	<xsl:template name="GetASW0BLOCK_LENGTH_ADDRESSMODEL">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/DATA/ADDRESSLAYOUTMODEL/BLOCK[NAME='ASW0']/CSO_ABSOLUTE/@LENGTH"/>
    </xsl:template>
	<xsl:template name="GetDS0BLOCK_STARTADDRESS_ADDRESSMODEL">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/DATA/ADDRESSLAYOUTMODEL/BLOCK[NAME='DS0']/CSO_ABSOLUTE/@START"/>
    </xsl:template>
	<xsl:template name="GetDS0BLOCK_LENGTH_ADDRESSMODEL">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/DATA/ADDRESSLAYOUTMODEL/BLOCK[NAME='DS0']/CSO_ABSOLUTE/@LENGTH"/>
    </xsl:template>
   <xsl:template name="GetASW0BLOCK_STARTADDRESS">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='60']/START_ADDRESS"/>
    </xsl:template>
	<xsl:template name="GetASW0BLOCK_ENDADDRESS">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='60']/END_ADDRESS"/>
    </xsl:template>
	<xsl:template name="GetDS0BLOCK_ENDADDRESS">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='70']/END_ADDRESS"/>
    </xsl:template>
	<xsl:template name="GetDS0BLOCK_STARTADDRESS">
        <xsl:param name="File" />
        <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='70']/START_ADDRESS"/>
    </xsl:template>
    
    <xsl:template name="GetASW0BLOCK_BLOCKID">
          <xsl:param name="File" />
          <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='60']/BLOCKID"/>
  </xsl:template>
  
   <xsl:template name="GetVDSBLOCK_STARTADDRESS">
           <xsl:param name="File" />
           <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='80']/START_ADDRESS"/>
    </xsl:template>
  
   <xsl:template name="GetCBBLOCK_STARTADDRESS">
      <xsl:param name="File" />
      <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='50']/START_ADDRESS"/>
  </xsl:template>

   <xsl:template name="GetSBBLOCK_BLOCKID">
          <xsl:param name="File" />
          <xsl:value-of select="document($File)/ADDRESSMODEL_BLOCKS/BLOCK[child::BLOCK_LAST_BYTE='10']/BLOCKID"/>
  </xsl:template>
  
  <xsl:template name="CheckNodeExistsorNot">
    <xsl:param name="FEE_NODE" />   
    <xsl:choose>
      <xsl:when test="$FEE_NODE = ''">
        <xsl:value-of select="'0'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'1'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
  <xsl:template name="GetAESTemplateFile_ConfigPath">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:AESKey_Block_Config"/>	
	</xsl:template>
	
	<xsl:template name="GetLastCharacter">
		<xsl:param name="StringValue"/> 
			<xsl:choose>
				<xsl:when test="$StringValue = ''">
					<xsl:value-of select="'1'"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="substring($StringValue, string-length($StringValue), string-length($StringValue))"/>
				</xsl:otherwise>
			</xsl:choose>					 
    </xsl:template>
	
	 <xsl:template name="Data_Value" >
		<xsl:param name="ID" />
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:*[name()=$ID]"/>
	</xsl:template>
</xsl:stylesheet>
