<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
 <xsl:variable name="RT_Ped_Script_HexCompare" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='PED_SCRIPT_HEX_COMPARE']/tctypes:Value"/>
 <xsl:variable name="RT_HEX_COMPARE_LOGISTIC_LOG" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='HEX_COMPARE_LOGISTIC_LOG']/tctypes:Value"/>
 
</xsl:stylesheet>