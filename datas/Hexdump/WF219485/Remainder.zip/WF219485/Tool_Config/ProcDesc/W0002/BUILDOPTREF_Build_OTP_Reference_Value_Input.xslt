 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
    <xsl:template match="/">
    <ToolInput>
		<Mode>Generate OTP_Ref and OTP_Ref_Code</Mode>
		<Input>
			<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
			<IsToolbaseToolchain>1</IsToolbaseToolchain>
			<Files>
				<ConditionCheckFile>
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
						<xsl:value-of select="'\'"/> 
					<xsl:call-template name="GetOTPCONDITIONCHECKFILE"></xsl:call-template>
					
				</ConditionCheckFile>
				<OTPKeyRefFilePath>
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
					<!-- <xsl:call-template name="GetOTPKeyRefLog_FilePath"></xsl:call-template> -->
				</OTPKeyRefFilePath>
				<CustomerLogFilePath>
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
					<!-- <xsl:call-template name="GetOTPKeyRefLog_FilePath"></xsl:call-template> -->
				</CustomerLogFilePath>
			</Files>	
			<Data>
				<FlowJobNumber><xsl:call-template name="GetWorkFlowID"></xsl:call-template></FlowJobNumber>
				<OTP_Key><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'OTP_Key'" />
					</xsl:call-template>
				</OTP_Key>
				<OTP_Overview><xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'OTP_Overview'" />
					</xsl:call-template>
				</OTP_Overview>
				<OTPEnvTypeNumber><xsl:call-template name="GetOTPEnvTypeNumber"></xsl:call-template>
				</OTPEnvTypeNumber>
				<CustomerIndentityIndex_Dec><xsl:call-template name="GetCustomerIndentityIndex_Dec"></xsl:call-template></CustomerIndentityIndex_Dec>
				<CustomerIndentityIndex_Hex><xsl:call-template name="GetCustomerIndentityIndex_Hex"></xsl:call-template></CustomerIndentityIndex_Hex>
				<HardwarePartNumber><xsl:call-template name="GetHardwarePartNumber"></xsl:call-template></HardwarePartNumber>
				<SoftwarePartNumber><xsl:call-template name="GetSoftwarePartNumber"></xsl:call-template></SoftwarePartNumber>
				<!-- Mention the condition numbers which all need to tested seperated by '|' -->
				<Condition_Numbers>1</Condition_Numbers>
				<!-- Test parameter name should match exactly with one defined Resource file --> 
				<TestParameter>TP_Mask</TestParameter>
				<TestParameter_Value>
					<xsl:call-template name="GetSignedParameter">
						<xsl:with-param name="FlashSignedFlag">
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'FLASH_OTP_FLAG'" />
							</xsl:call-template>
						</xsl:with-param>
						<xsl:with-param name="HSMSignedFlag">
							<xsl:call-template name="RunTime_Data_Value">
								<xsl:with-param name="DataClassID" select="'HSM_OTP_FLAG'" />
							</xsl:call-template>
						</xsl:with-param>						
					</xsl:call-template>
				</TestParameter_Value>
				<BuildMode>
				<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'BuildMode'"/></xsl:call-template>
				</BuildMode>
			</Data>
		</Input>
		
		<LogFileAnalyser>
				<Files>
					<File>
						<Classification>OTP_REFERENCE_DETAILS</Classification>
						<Key></Key>
						<Directory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></Directory>
						<Name><xsl:value-of select="'OTP_Ref.txt'"/></Name>
					</File>
				</Files>
		</LogFileAnalyser>
		
		<CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
		
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
