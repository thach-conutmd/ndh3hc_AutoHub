 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:template match="/">

    <ToolInput>
    <Mode>HexModX - Read Raw Key value from bin file </Mode>

    <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>PatchAndCheckXML</Module>
			
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_PatchNCheck_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_IV_KEY_MAIN_XML'"/></xsl:call-template></Script>
     		<Variables>
 				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMODX_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexMod_PatchNCheck_Input_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_PATCHANDCHECK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexModX_PatchNcheck_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
				<Variable>
					<Name>HEXMODX_OUTPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HexMod_PatchNCheck_Output_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>
			</Variables>
       	</MainXML>
     	<!-- PatchAndCheckXML - Config -->
     	<PatchAndCheckXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexModX_PatchNcheck_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_COMMON_KEY_PATCHANDCHECK_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>LABEL_NAME</Name>
					<Value><xsl:value-of select="'Common_KEY_For_Encryption'"/></Value>
				</Variable>
				<Variable>
					<Name>Common_KEY_ADDRESS</Name>
					<Value>
						<xsl:value-of select="'0x'"/>
						<xsl:value-of select="'00000000'"/>
					</Value>
				</Variable>      			
				<Variable>
					<Name>OUTPUTXML_FILE</Name>
						<Value><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:value-of select="'Raw_Key_PatchcheckInfo.xml'"/></Value>
				</Variable>
			</Variables>
      			
		</PatchAndCheckXML>
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_PatchNCheck_Input_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_COMMON_IV_KEY_PATCHANDCHECK_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'Raw_KEY_BIN_FILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'Raw_KEY_BIN_FILE'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:value-of select="'BIN'"/></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value><xsl:value-of select="'BigEndian'"/></Value>
				</Variable>
 			</Variables>     		   	
		</InputXML>		
 	<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMODX_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
				
			</Files>
		</LogFileAnalyser>	
		<PST_Library>
		</PST_Library>	
    </HexModeInput>  
    <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
