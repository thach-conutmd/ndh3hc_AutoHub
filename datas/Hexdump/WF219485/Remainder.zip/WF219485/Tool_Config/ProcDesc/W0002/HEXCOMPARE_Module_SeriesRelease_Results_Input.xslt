<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	 <xsl:variable name="DataHandling" select="/tctypes:UseCase/tctypes:Data/tctypes:Data_Handling" />
	 <xsl:variable name="NumberOfVariants" select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants" />
     <xsl:variable name="DH_NoOfVar_Concatenated"  select="concat($DataHandling,$NumberOfVariants )" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Hex Code Compare</Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime> <!-- 10 Minutes-->
				<DateTimeInterval>0</DateTimeInterval> <!-- 1 = Minutes  / 0 = Seconds-->
				<Files>
				<ConfigurationFile>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>											
						<xsl:value-of select="'\'" />
						<xsl:value-of select="'Config.csv'"/>
					</ConfigurationFile>
					
					<PEDCompareFile>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'Hex_Compare_File'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
						<xsl:value-of select="'\'" />
						<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'Hex_Compare_File'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>						
					</PEDCompareFile>
					
					<LogAnalyzerFile>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
						<xsl:value-of select="'\'" />
						<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'BC_Gen_Log_Complete'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>						
					</LogAnalyzerFile>
				</Files>
				<List>
					<Entry>
						<ScriptPattern><![CDATA[\n[\s]*(?'Label'([^\s\[\]]*))[\s]*(?'Address'8([A-Fa-f0-9]){7})]]></ScriptPattern>
						<LookUpFile>
							<Directory>
                <xsl:call-template name="FileList_GetFileDirectory" >
                  <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                </xsl:call-template>						
							</Directory>
							<Name>
                <xsl:call-template name="FileList_GetFileName" >
                  <xsl:with-param name="FileClassID" select="'ADDRESSLIST_INT'"/>
                  <xsl:with-param name="GetValue" select="'yes'"/>
                  <xsl:with-param name="GetExtension" select="'no'"/>
                </xsl:call-template>
                <xsl:value-of select="'.adl'" />
              </Name>
						</LookUpFile>
					</Entry>
				</List>
				<InfoSheet>
				<Release_File>
						 <xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'RELEASEPST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					</Release_File>
					<xsl:choose>
					<xsl:when test="$DH_NoOfVar_Concatenated='00'">
					<Application_File>
						<xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						 <xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
					</Application_File>
					</xsl:when>
					<xsl:otherwise>
					<Application_File>
						<xsl:call-template name="FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						 <xsl:call-template name="FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
					</Application_File>
					</xsl:otherwise>
					</xsl:choose>
					<Flow_Job_No>
						<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
					</Flow_Job_No>
				</InfoSheet>
				<Validations>
					<CMPFileMaxSizeLimit>10000000</CMPFileMaxSizeLimit>
				</Validations>
				<LogFileAnalyser>
					<Files>
						<File>
							<Classification>HEX Compare Logfile</Classification>
							<Key></Key>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							</Directory>
							<Name>
								<xsl:value-of select="'Hex_Compare.log'" />
							</Name>
						</File>
					</Files>
				</LogFileAnalyser>	
			</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion>1v19</ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>