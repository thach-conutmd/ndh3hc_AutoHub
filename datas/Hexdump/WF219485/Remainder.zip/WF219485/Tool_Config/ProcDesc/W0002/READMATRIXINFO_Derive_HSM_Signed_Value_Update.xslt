<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_ReadMatrixInfo_HSMSigned" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:HSM_SIGNED"/>
 <xsl:variable name="RT_ReadMatrixInfo_HSMSignedFlag" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:HSM_OTP_FLAG"/>
 
</xsl:stylesheet>