<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_ReadMatrixInfo_DFID_FLAG" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:DFID_FLAG"/>
  <xsl:variable name="RT_ReadMatrixInfo_COMPRESSION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:COMPRESSION"/>
  <xsl:variable name="RT_ReadMatrixInfo_ENCRYPTION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:ENCRYPTION"/>
   <xsl:variable name="RT_ReadMatrixInfo_DFID" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:MATRIX_DFID"/>
  <xsl:variable name="RT_ReadMatrixInfo_ODX_CREATE_COMPRESSION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:ODX_CREATE_COMPRESSION"/>
  <xsl:variable name="RT_ReadMatrixInfo_ODX_CREATE_ENCRYPTION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:ODX_CREATE_ENCRYPTION"/>
  <xsl:variable name="RT_ReadMatrixInfo_ODX_EXTRN_COMPRESSION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:ODX_EXTRN_COMPRESSION"/>
  <xsl:variable name="RT_ReadMatrixInfo_ODX_EXTRN_ENCRYPTION" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:ODX_EXTRN_ENCRYPTION"/>
</xsl:stylesheet>