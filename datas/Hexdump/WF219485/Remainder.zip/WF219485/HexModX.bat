call   C:\toolbase\hexmodx\13.1.0\bin\HexmodX.cmd   /chksum.bsh
