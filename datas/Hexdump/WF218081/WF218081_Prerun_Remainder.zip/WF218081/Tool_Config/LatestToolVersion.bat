rem tbexcmd -useEnv:dgs -command EnableTool %1/*
tbexcmd -useEnv:dgs -command EnableTool %1/latest

tbupdate -e

texec %1/latest >%2
