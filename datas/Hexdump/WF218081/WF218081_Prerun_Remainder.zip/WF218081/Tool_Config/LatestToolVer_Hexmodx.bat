rem tbexcmd -useEnv:dgs -command EnableTool %1/*
tbexcmd -useEnv:dgs -command EnableTool hexmodx/14.4.0
tbupdate -e

rem  texec %1/latest >%2
