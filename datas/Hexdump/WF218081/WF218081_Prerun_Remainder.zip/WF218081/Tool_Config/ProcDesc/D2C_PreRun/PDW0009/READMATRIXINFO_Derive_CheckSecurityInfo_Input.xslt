 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Check Security Info is Required?</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Check Security Info</DefaultValueMessage>
		<ConfigFile>
			<Name><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'TOOLRUN_FIND_SECURITY_INFO_MATRIX_NAME'"/></xsl:call-template></Name>
			<Directory>
			<!-- <xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'TOOLRUN_OPTION_MATRIX_PATH'"/></xsl:call-template> -->
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\'" />
				</Directory>
		</ConfigFile>
		<Variables>  			
			<Variable>
				<Name>BuildMode</Name>
				<Value>
					 <xsl:call-template name="GetBuildMode">
						<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param>
						</xsl:call-template>
						<xsl:call-template name="GetBuildMode_FRA">
						<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param>
						</xsl:call-template>
					<!-- <xsl:value-of select="'Mx9'"/> -->
				</Value>
			</Variable>
		</Variables>  
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
