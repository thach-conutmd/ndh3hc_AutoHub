<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>


<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


    <xsl:template match="/">
    <ToolInput>
		<Mode>Create BIN file and Block information</Mode>
	   	<Input>
				<!-- Source files  -->
				   <VBFENCRYPTED>1</VBFENCRYPTED>
					<SourceFile>
						<Directory><xsl:call-template name="GetWorkingDirectory" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template></Directory>
						<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template></Name>
					</SourceFile>
					<TargetFile>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
							<xsl:value-of select="'.bin'"/></Name>
					</TargetFile>
                     <DecyptedBINFile>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
							<xsl:value-of select="'_decrypted.bin'"/></Name>
					</DecyptedBINFile>					
		</Input>   		
   		<CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>			  
   	</ToolInput>     	  	
   </xsl:template>
</xsl:stylesheet>

