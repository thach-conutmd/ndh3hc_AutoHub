<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:xsenv="http://de.bosch.com/gs/ToolChainEnvironment" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainWriteBackLib.xslt" />
	<!-- Parameter for Usecase-xml file -->
	<xsl:param name="PUseCaseXML" />
	<xsl:output method="xml" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
  <xsl:variable name="RT_Tools" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:Tools" />
  
	
</xsl:stylesheet>