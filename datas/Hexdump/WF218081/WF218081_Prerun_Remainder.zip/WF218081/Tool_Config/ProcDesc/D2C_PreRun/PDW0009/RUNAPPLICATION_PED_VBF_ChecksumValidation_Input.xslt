 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Run PED VBF file checksum validation</Mode>
    <Input>
    
    	<!-- Init-Values for Progress-Display -->
		<EstimatedRunTime>10</EstimatedRunTime>	<!-- 10 Minutes-->
		<DateTimeInterval>0</DateTimeInterval>				<!-- 1 = Minutes  / 0 = Seconds-->
		
     	<SourceTemplateFile>
        <Directory>
          <xsl:call-template name="GetWorkingDirectory">
          </xsl:call-template>
        </Directory>
        <Name>
          <xsl:value-of select="'\Ped_CheckSum_Validation_temp.pcm'"/>
        </Name>
		</SourceTemplateFile>
		<TargetTemplateFile>
			<Directory><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template></Directory>
			<Name><xsl:value-of select="'\Ped_CheckSum_Validation.pcm'"/></Name>
		</TargetTemplateFile>
		<Script>
		</Script>
		<ScriptMandatory>1</ScriptMandatory>
		<Variables>			
		</Variables>
		<CommandLine><xsl:value-of select="' -l '"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\Ped_CheckSum_Validation.log'"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' -b '"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\Ped_CheckSum_Validation.pcm'"/>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>	
						
						<!-- p0 Bin file-->
						<xsl:value-of select="'&quot;'"/>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'BIN_File'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template><xsl:value-of select="'\'"/>						
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'BIN_File'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
						</xsl:call-template>
						<xsl:value-of select="'&quot;'"/>
						<xsl:value-of select="' '"/>				
						
		</CommandLine>
		<LogFileAnalyser>
			<Files>
					<File>
						<Classification>Ped-Common</Classification>
						<Key>PED_COMMON</Key>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:value-of select="'Ped_CheckSum_Validation.log'"/></Name>
					</File>
				</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<!-- <ToolName>PED</ToolName> -->
		<!-- <CallType></CallType> -->
		<!-- <ToolVersion>1v19</ToolVersion> -->
		<!-- <ToolLocation> -->
				<!-- <xsl:call-template name="RunTime_Tool_Path"> -->
					<!-- <xsl:with-param name="ToolName" select="'PEDVERSION'"/> -->
				<!-- </xsl:call-template> -->
		<!-- </ToolLocation> -->
		<!-- <InputVerification></InputVerification> -->
		<ToolName>PEDVersion</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation> 
		 <Directory>
			<xsl:call-template name="GetToolDirectoryFromConfig">
			<xsl:with-param name="File">
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\ToolListConfig.XML'" />
			</xsl:with-param>
			<xsl:with-param name="ToolNameValue">
				<xsl:value-of select="'PEDVersion'" />
			</xsl:with-param>
			</xsl:call-template>
          </Directory>
          <Name>
			<xsl:call-template name="GetToolNameFromConfig">
			<xsl:with-param name="File">
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\ToolListConfig.XML'" />
			</xsl:with-param>
			<xsl:with-param name="ToolNameValue">
				<xsl:value-of select="'PEDVersion'" />
			</xsl:with-param>
			</xsl:call-template>
          </Name>
    </ToolLocation>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
