CSCRIPT %1 %2 %3 %4 %5 %6
rem CSCRIPT I:\Programme\SEU_Test\Tools\ProcDesc\PreRun\PDW0004\GetArchivePath.vbs "https://rb-klaudia.bosch.com/KLAUDIA.svc/Archiver/ArchivedPath?ID_VALUE=MG1CA011N1/04C01_T1;0" "C:\Users\cul5kor\AppData\Local\Temp\WorkingDirectory\DST\WF006209\" "\\bosch.com\dfsrb\DfsDE\DIV\DGS\08\EC\57_ESM\PJ\181_SRL_DEV\Ref\Test_PST\MDG1C\KOR\Hyundai\MG1CA011N1_04C01_T1"
