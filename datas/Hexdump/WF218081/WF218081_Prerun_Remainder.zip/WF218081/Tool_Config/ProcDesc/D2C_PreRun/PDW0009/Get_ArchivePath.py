import cx_Oracle
import sys



dsn_tns = cx_Oracle.makedsn('rb0orarac20.de.bosch.com', '38000', service_name='CDGD2PP_rb0orarac20.de.bosch.com') #if needed, place an 'r' before any parameter in order to address any special character such as '\'.

#dsn_tns = cx_Oracle.makedsn(host1, Port1, service_name=service)
#dsn_tns = cx_Oracle.makedsn(sys.argv[1], sys.argv[2], service_name=sys.argv[3])

#conn = cx_Oracle.connect(user=sys.argv[4], password=sys.argv[5], dsn=dsn_tns)

conn = cx_Oracle.connect(user='CDG_ADMIN', password='Xdcminad_9', dsn=dsn_tns) 
print(conn)

c=conn.cursor()
c.execute(sys.argv[1])


file = open(sys.argv[2], "a+")
for row in c:
    file.write(str(row[0]))
    print(row[0])
 



file.close()
conn.close()