Set args = WScript.Arguments

If args.Count < 5 Then
    WScript.Echo "Error: Missing arguments. Provide all required inputs."
    WScript.Quit
End If

Dim xHttp, bStrm, fso, objFSO, objFile
Dim PSTname, PSTVariant, PSTRevision, PVERLabel
Dim url, username, password, filePath, path, output
Dim coded, temp, i, OutPutFile


Set xmlDoc = CreateObject("MSXML2.DOMDocument")
    If Not xmlDoc.Load(args(1)+"\AdapterParam.xml") Then 'args(1)- working directory
        MsgBox xmlDoc.parseError.reason
    Else
	
	
	strQuery = "/Fields/Field[@Name='PVER_Label']"
	Set colNodes = xmlDoc.selectNodes( strQuery )
	For Each objNode in colNodes
		WScript.Echo objNode.nodeName & ": " & objNode.text
		PVERLabel = objNode.text
	Next
	
	if PVERLabel = "" Then
	strQuery = "/Data/PVER_Label"
	Set colNodes1 = xmlDoc.selectNodes("/Data/PVER_Label")
	For Each objNode in colNodes1
		WScript.Echo objNode.nodeName & ": " & objNode.text
		PVERLabel = objNode.text
	Next
	End If
	
	if PVERLabel = "" Then
	WScript.Echo "came1"
	Set colNodesname = xmlDoc.selectNodes("/Fields/Field[@Name='PSTName']")
	For Each objNode in colNodesname
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTName = objNode.text
	Next
	Set colNodesvar = xmlDoc.selectNodes("/Fields/Field[@Name='PSTVariant']")
	For Each objNode in colNodesvar
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTVariant = objNode.text
	Next
	Set colNodesrev = xmlDoc.selectNodes("/Fields/Field[@Name='PSTRevision']")
	For Each objNode in colNodesrev
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTRevision = objNode.text
	PVERLabel = PSTName + "/"+ PSTVariant +";"+PSTRevision
	Next
	
	End If
	
	if PVERLabel = "" Then
	WScript.Echo "came"
	Set colNodesname = xmlDoc.selectNodes("/Data/PSTName")
	For Each objNode in colNodesname
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTName = objNode.text
	Next
	Set colNodesvar = xmlDoc.selectNodes("/Data/PSTVariant")
	For Each objNode in colNodesvar
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTVariant = objNode.text
	Next
	Set colNodesrev = xmlDoc.selectNodes("/Data/PSTRevision")
	For Each objNode in colNodesrev
		WScript.Echo objNode.nodeName & ": " & objNode.text
	PSTRevision = objNode.text
	PVERLabel = PSTName + "/"+ PSTVariant +";"+PSTRevision
	Next
	
	
	End If
	End If

' Initialize the HTTP request and Stream objects
Set xHttp = CreateObject("MSXML2.ServerXMLHTTP.6.0")
Set bStrm = CreateObject("Adodb.Stream")
Set fso = CreateObject("Scripting.FileSystemObject")

' Set API endpoint and credentials
url = "https://rb-archiver.bosch.com:8020/api/Prerun/GetArchivedPath?SWTTNR=" & args(0)
username = FindVal("lv5lzz_HG")
password = FindVal("9ChylkfudwgS")

WScript.Echo "Sending request to: " & url

' Open the request with Basic Authentication
xHttp.Open "GET", url, False, username, password

' Send the request
xHttp.Send

' Check response status and handle errors
If xHttp.Status = 200 Then
    ' Prepare to save the response to a file
    bStrm.Type = 1 ' Binary
    bStrm.Open
    bStrm.Write xHttp.responseBody
    bStrm.SaveToFile args(1) & "\KlaudiaArchivePath.txt", 2 ' Overwrite if exists
    bStrm.Close
    WScript.Echo "Response saved successfully."
Else
    WScript.Echo "Error: " & xHttp.Status & " - " & xHttp.StatusText
    WScript.Quit
End If

' Read the saved response and validate path
filePath = args(1) & "\KlaudiaArchivePath.txt"

If fso.FileExists(filePath) Then
    Set objFile = fso.OpenTextFile(filePath, 1) ' ForReading

    Do Until objFile.AtEndOfStream
        path = objFile.ReadLine
        WScript.Echo "Checking path: " & path

        If fso.FolderExists(path) Then
            output = "Archive path exists. Path:" & path
        Else
            output = "Archive path not found. Using PVER source path. Path:" & args(2)
        End If
    Loop
    objFile.Close
Else
    WScript.Echo "Error: File not found at " & filePath
    WScript.Quit
End If

' Save the results to PVERPath.log
Set OutPutFile = fso.OpenTextFile(args(1) & "\PVERPath.log", 2, True)
OutPutFile.WriteLine output

' Check if ECU security file exists
If fso.FileExists(args(3)) Then
    OutPutFile.WriteLine "ECU Secu file exists. Flag_ECU_Secu:1"
Else
    OutPutFile.WriteLine "ECU Secu file does not exist. Flag_ECU_Secu:0"
End If

' Delete reminder if exists
If fso.FileExists(args(4)) Then
    fso.DeleteFile args(4)
    OutPutFile.WriteLine "Reminder zip deleted."
Else
    OutPutFile.WriteLine "Reminder zip not found."
End If

' Delete hardcoded remainder.zip
If fso.FileExists(args(1) & "\Remainder.zip") Then
    fso.DeleteFile args(1) & "\Remainder.zip"
    OutPutFile.WriteLine "Remainder.zip deleted."
Else
    OutPutFile.WriteLine "Remainder.zip not found."
End If

OutPutFile.WriteLine "PVER Label: " & PVERLabel
OutPutFile.Close

' Clean up objects
Set xHttp = Nothing
Set bStrm = Nothing
Set fso = Nothing
Set OutPutFile = Nothing
Set objFSO = Nothing
Set objFile = Nothing

' Function to reverse and decode a string
Function FindVal(str)
    coded = ""
    str = StrReverse(str)
    For i = 1 To Len(str)
        temp = Asc(Mid(str, i, 1))
        temp = Chr(temp - 3)
        coded = coded & temp
    Next
    FindVal = coded
End Function

WScript.Echo "Script execution completed successfully!"
