<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<!-- To decide SCAN_LST_FLAG. 1 = TRUE, 0 = FALSE -->	
	<xsl:variable name="ScanLSTFlag">
		 <xsl:call-template name="GetSRVChecker_PVER_Scan"></xsl:call-template>
	 </xsl:variable>
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				 <ResultingFiles>  	  	  	  	  	 
				 <xsl:if test="$ScanLSTFlag='0'">
				<File>
					<FileClassID>CRITICAL_DATA_ACCESS_ULF</FileClassID>
					<FileClassName>CRITICAL_DATA_ACCESS_ULF</FileClassName>
					<Location>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\SRVCheckerOutput\'"/>							
						</Directory>
						<Name>
							<xsl:value-of select="'srvchecker_scan.ulf'"/>
						</Name>
					</Location>
				</File>
				<File>
					<FileClassID>CRITICAL_DATA_ACCESS_LST</FileClassID>
					<FileClassName>CRITICAL_DATA_ACCESS_LST</FileClassName>
					<Location>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\SRVCheckerOutput\'"/>								
						</Directory>
						<Name>
							<xsl:value-of select="'srvchecker_scan.lst'"/>
						</Name>
					</Location>
				</File>				
				</xsl:if>
				<File>
					<FileClassID>RESIZED_APPLIEDFILES</FileClassID>
					<FileClassName>RESIZED_APPLIEDFILES</FileClassName>
					<Location>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>						
						</Directory>
						<Name>
							<xsl:value-of select="'LST_Files.zip'"/>
						</Name>
					</Location>
				</File>
    		</ResultingFiles>
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
