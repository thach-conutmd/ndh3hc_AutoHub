Set args = Wscript.Arguments
dim xHttp: Set xHttp = createobject("Microsoft.XMLHTTP")
'dim xHttp: Set xHttp = createobject("MSXML2.XMLHTTP")
dim bStrm: Set bStrm = createobject("Adodb.Stream")
'xHttp.Open "GET", args(0), False
xHttp.Open "GET", args(0), False, FindVal("lv5lzz_HG"), FindVal("8ChylkfudwgS") 'args(0) - https://rb-klaudia.bosch.com/KLAUDIA.svc/Archiver/ArchivedPath?ID_VALUE=<PVERlabel>

xHttp.send ""

with bStrm
    .type = 1 '//binary
    .open
    .write xHttp.responseBody
    .savetofile args(1) + "\KlaudiaArchivePath.xml", 2 '//overwrite,  args(1)- working directory
end with

Set fso = CreateObject("Scripting.FileSystemObject")
Dim path 'path to folder    
Dim output

function FindVal(str)
Dim coded
str = StrReverse(str)
For i=1 to Len(str)
temp = Asc(Mid(str,i,1))
temp = Chr(temp - 3)
coded = coded + (temp)
Next
FindVal = coded
end function

Dim xmlDoc 
    Set xmlDoc = CreateObject("MSXML2.DOMDocument")
    If Not xmlDoc.Load(args(1) + "\KlaudiaArchivePath.xml") Then 'args(1)- working directory
        MsgBox xmlDoc.parseError.reason
    Else
	
	Set BlockNodes = xmlDoc.GetElementsByTagName("string")
	
	For Each Elem In BlockNodes 
     WScript.Echo Elem.text
     path = Elem.text  
	 
	 if fso.FolderExists(path) then 
         output = "Archive path Exists. Path:" + path
	Else
		 Output = "Archive path Not Exists. Hence refer PVER source path. Path:" + args(2) 'PVER path refered from adapater 	 
	end if
    Next
	
   End If
   
Dim FSO
Set FSO = CreateObject("Scripting.FileSystemObject")

Set OutPutFile = FSO.OpenTextFile(args(1) + "\PVERPath.log" ,2 , True)  '1 means for reading, 2 means for writing, and 8 means for appending
OutPutFile.WriteLine(Output)


'Check IF ECU secu file exists in working directory
If fso.FileExists(args(3)) then

OutPutFile.WriteLine("ECU Secu file exists in working directory. Flag_ECU_Secu:1")
else
OutPutFile.WriteLine("ECU Secu file not exists in working directory. Flag_ECU_Secu:0")

End if

'Delete reminder if exists in working directory
If fso.FileExists(args(4)) then

fso.DeleteFile(args(4))
OutPutFile.WriteLine("Reminder zip is deleted")
else
OutPutFile.WriteLine("Reminder does not exists in working directory")

End if


'Delete reminder if exists in working directory
If fso.FileExists(args(1)+"\Remainder.zip") then

fso.DeleteFile(args(1)+"\Remainder.zip")
OutPutFile.WriteLine("Remainder.zip is deleted")
else
OutPutFile.WriteLine("Remainder.zip not exists in working directory")

End if



set fso= Nothing
Set FSO= Nothing