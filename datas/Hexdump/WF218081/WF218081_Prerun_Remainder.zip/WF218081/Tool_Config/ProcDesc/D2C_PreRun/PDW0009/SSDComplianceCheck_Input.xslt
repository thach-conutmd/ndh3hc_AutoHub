<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	 <xsl:variable name="SSD_A2L_FILE_CLS_ID">
		 		<xsl:call-template name="GetSSDA2L"></xsl:call-template>
	 </xsl:variable>
	<xsl:template match="/">
			<ToolInput>
			<Mode>SSD Compliance Check started</Mode>
			<Input>
			<ContainerName><xsl:call-template name="GetWorkFlowID"/></ContainerName>
			<Database><xsl:call-template name="GetPDT_DB_Type"/></Database>
			<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"/></WorkingDirectory>
			<NumberOfVariants><xsl:call-template name="GetNoofVariants"/></NumberOfVariants>
			<PIDC_Value_Script><xsl:call-template name="GetWrapperPath"/><xsl:value-of select="'\GetPIDC.vbs'"/></PIDC_Value_Script>
			<Files>
			<A2L_File>
			<Name>
			<xsl:call-template name="RunTime_FileList_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="$SSD_A2L_FILE_CLS_ID"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template><xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="$SSD_A2L_FILE_CLS_ID"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template>
			</Name>
			</A2L_File>
			
			<ADAPTERPARAM>
			<Name>
			<xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\AdapterParam.xml'"/>
			</Name>
			</ADAPTERPARAM>
			</Files>

	</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>