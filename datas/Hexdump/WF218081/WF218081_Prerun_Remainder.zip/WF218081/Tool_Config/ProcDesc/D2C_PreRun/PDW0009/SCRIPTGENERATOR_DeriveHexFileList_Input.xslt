 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:template match="/">

    <ToolInput>
    <Mode>Generate Variant coding script</Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>

				<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>DERIVE_APPLICATION_FILES_LIST</Key>
				<Comment>Script for deriving list of Application hex files</Comment>
				<ScriptTemplate>
				<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_APPLICATION_FILES_LIST'" />
				</xsl:call-template>
				</ScriptTemplate>
				<DataBase>
					<LoopCount>
						<xsl:call-template name="GetNoofVariants"></xsl:call-template>
					</LoopCount>
					<WorkingDirectory>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					</WorkingDirectory>					
					<FileList>
            			<xsl:call-template name="GetFileList"></xsl:call-template>
  					</FileList>
					<LSTFileName>
						<xsl:value-of select="'ApplicationFileList.lst'" />
					</LSTFileName>
					<ControllerID><xsl:call-template name="GetControllerIDValue"></xsl:call-template></ControllerID>
					<INPUT_HEX_FILE_FILECLASSID>APPLIEDFILE</INPUT_HEX_FILE_FILECLASSID>
			</DataBase>
			</Script>
			<Script>
            <Write2PSTLib>False</Write2PSTLib>
            <Key>SCAN_LST_FLAG</Key>
            <Comment>Check if srvchecker_scan.lst exists. 1 = TRUE, 0 = FALSE </Comment>
            <ScriptTemplate>
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="'SCRIPT_CHECK_FILE_EXIST'" />
              </xsl:call-template>
            </ScriptTemplate>
            <DataBase>
				<FileToCheck>
					<xsl:call-template name="RunTime_FileList_GetFileDirectory">
					<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template><xsl:value-of select="'\'"/>
					<xsl:call-template name="RunTime_FileList_GetFileName">
					<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
					<xsl:with-param name="GetValue" select="'yes'"/> 
					</xsl:call-template>
				</FileToCheck>
            </DataBase>
          </Script>
		 
          </Scripts>
			<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
