<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:variable name="RT_GUAM_FLAG" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='GUAM_FLAG']/tctypes:Value"/>
<xsl:variable name="RT_CFGEXP_MACHINE_TYPE" select="tctypes:ToolOutput/tctypes:Output/tctypes:LookUpDatas/tctypes:LookUpData[child::tctypes:Name='CFGEXP_MACHINE_TYPE']/tctypes:Value"/>

</xsl:stylesheet>