<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
	<ToolInput>
	<Mode>Copy Files</Mode>
	<Input>
			
	<!-- CopyFile operation being done, hence Mode=3 --> 
	<!-- Operations supported: Check-in = 1, Checkout = 2, Copy = 3 -->
		<PDTDB_Mode>3</PDTDB_Mode>
		<Database>
			<xsl:call-template name="GetPDT_DB_Type"/>
		</Database>
		<ContainerName>
			<xsl:call-template name="GetContainerName_PST_Lib"/>
		</ContainerName>		
		<JobContainer>
			<xsl:call-template name="GetWorkFlowID"/>
		</JobContainer>
	    <InputFileList><xsl:call-template name="GetConfigFolder"/><xsl:value-of select="'\CopyFilesList_Configuration.xml'"/></InputFileList>
		<WorkingDirectory>
			<xsl:call-template name="GetWorkingDirectory"/>
		</WorkingDirectory>
		<Global_FileList><xsl:call-template name="GetConfigFolder"/><xsl:value-of select="'\Global_FileList.txt'"/></Global_FileList>
	
	</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>