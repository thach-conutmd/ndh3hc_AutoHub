<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>HexmodX - Derive Bootcntrl version</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="GetWrapperPath">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'BootCtrlInfo.bsh'"/>
					</Name>
				</SourceTemplateFile>
				<TargetTemplateFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'BootCtrlInfo.bsh'"/>
					</Name>
				</TargetTemplateFile>
				<Script/>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables>
					<!-- <Variable> -->
						<!-- <Name>HEXFILE_NAME</Name> -->
						<!-- <Value>				 -->
							<!-- <xsl:call-template name="FileList_GetFileName"> -->
							<!-- <xsl:with-param name="FileClassID" select="'INTEGRATIONFILE'"/> -->
							<!-- <xsl:with-param name="GetValue" select="'yes'"/> -->
							<!-- </xsl:call-template> -->
						<!-- </Value> -->
					<!-- </Variable> -->
					<!-- <Variable> -->
						<!-- <Name>XADDRESS</Name> -->
						<!-- <Value> -->
							<!-- <xsl:call-template name="GetEnvironmentValue"> -->
							<!-- <xsl:with-param name="LookUpItem" select="'XADDRESS_HEX'"/></xsl:call-template>						 -->
						<!-- </Value> -->
					<!-- </Variable> -->
				</Variables>
				<CommandLine>
					<!-- <xsl:value-of select="'&quot;'"/> -->
					<!-- <xsl:value-of select="'/'"/>					 -->
					<!-- <xsl:value-of select="'BootCtrlInfo.bsh'"/> -->
					<!-- <xsl:value-of select="'&quot;'" /> -->
					
					<xsl:value-of select="'/'" />
					<xsl:call-template name="GetWrapperPath"></xsl:call-template>
					<xsl:value-of select="'\BootCtrlInfo.bsh'"/>
					<xsl:value-of select="' -args '" />
					<xsl:value-of select="'&quot;'" />
					
					<!-- 1 Value Hex file -->					
					<xsl:call-template name="RunTime_FileListGeneral_GetFileName">
						<xsl:with-param name="FileClassID" select="'BOOTCTRL_HEX'"/>
						<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					<xsl:value-of select="';'" />
					
					<!-- 2 Value SB start -->		
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'XADDRESS'" />
					</xsl:call-template>   
					
					
					<xsl:value-of select="'&quot;'" />
					
				</CommandLine>
				<LogFileAnalyser>
					<Files>
							<File>
								<Classification>Hexmod17-Main-Logfile</Classification>
								<Key>HEXMOD17_MAIN</Key>
								<Directory><xsl:call-template name="GetWorkingDirectory">
											</xsl:call-template></Directory>
								<Name><xsl:value-of select="'hexmodx.log'"/></Name>
							</File>
					</Files>
				</LogFileAnalyser>
			</Input>
			<CallInformation>
				<ToolName>HEXMODX</ToolName>
				<CallType/>
				<ToolVersion/>
				<ToolLocation>
					<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
