 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:variable name="D2PContainerFiles">
	<xsl:call-template name="GetConfigFolder"/>
	<xsl:value-of select="'\CheckoutD2PContainerFiles_Configuration.xml'"/>	
</xsl:variable>
<xsl:variable name="FilesList">
	<xsl:call-template name="GetConfigFolder"/>
	<xsl:value-of select="'\CopyFilesList_Configuration.xml'"/>	
</xsl:variable>
<xsl:variable name="PST_LIbFiles">
	<xsl:call-template name="GetConfigFolder"/>
	<xsl:value-of select="'\CheckoutPST_LIbFiles_Configuration.xml'"/>	
</xsl:variable>
<xsl:variable name="ExcludeFiles">
	<xsl:call-template name="GetConfigFolder"/>
	<xsl:value-of select="'\ExcludeFileList.xml'"/>	
</xsl:variable>
			
<xsl:template match="/">

    <ToolInput>
    <Mode>Create FileList to exclude from Remainder.zip</Mode>

    <Input>
		<Scripts>
				<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>SCRIPT_CREATE_EXCLUDE_FILES_LIST</Key>
				<Comment>Script for deriving list of files to exclude from RemainderZip</Comment>
				<ScriptTemplate>
				<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'SCRIPT_CREATE_EXCLUDE_FILES_LIST'" />
				</xsl:call-template>
				</ScriptTemplate>
				<DataBase>
					<Datas>
					<OutputFilePath>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\'"/>
						  <xsl:call-template name="Data_Value">
							<xsl:with-param name="ID" select="'Remainder_ExcludeFilesListName'" />
						  </xsl:call-template>
					</OutputFilePath>
					 <Files_To_Exclude>
						<xsl:call-template name="GetFilesToExclude">
							<xsl:with-param name="FilePath" select="$D2PContainerFiles" />
						</xsl:call-template>
						<xsl:call-template name="GetFilesToExclude">
							<xsl:with-param name="FilePath" select="$FilesList" />
						</xsl:call-template>
						<xsl:call-template name="GetFilesToExclude">
							<xsl:with-param name="FilePath" select="$PST_LIbFiles" />
						</xsl:call-template>
						<xsl:call-template name="GetFilesToExclude">
							<xsl:with-param name="FilePath" select="$ExcludeFiles" />
						</xsl:call-template>
						<File><xsl:call-template name="RunTime_FileListGeneral_GetFileName">
							<xsl:with-param name="FileClassID" select="'A2L_FILE'" />
							<xsl:with-param name="GetValue" select="'yes'" />
							<xsl:with-param name="GetExtension" select="'no'"/>
							</xsl:call-template><xsl:value-of select="'.zip'"/></File>
					</Files_To_Exclude>
					<ExcludeFileBase>
					<xsl:call-template name="GetConfigFolder"></xsl:call-template>
						<xsl:value-of select="'\'"/>
						  <xsl:call-template name="Data_Value">
							<xsl:with-param name="ID" select="'Remainder_ExcludeFilesListName'" />
						  </xsl:call-template>
					</ExcludeFileBase>
					</Datas>
				</DataBase>
			</Script>
          </Scripts>
			<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
