<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
		<!-- To decide SCAN_LST_FLAG. 1 = TRUE, 0 = FALSE -->	
	<xsl:variable name="SRVCHECKER_PVER_LABEL_COUNT">
		 <xsl:call-template name="RunTime_Data_Value">
			 <xsl:with-param name="DataClassID" select="'SRVCHECKER_PVER_LABEL_COUNT'" />
		 </xsl:call-template>
	 </xsl:variable>
	<xsl:template match="/">
		<ToolInput>
			<Mode>Read SRVChecker Version from srvchecker_scan.lst</Mode>
			<Input>
				<LookUpFile>
				
				
			<xsl:if test="$SRVCHECKER_PVER_LABEL_COUNT !='-1'">
					
					<Directory>
				  <xsl:call-template name="RunTime_FileList_GetFileDirectory" >
					<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
					<xsl:with-param name="GetValue" select="'yes'"/>
				  </xsl:call-template>
				</Directory>
				<Name>				
				 <xsl:call-template name="RunTime_FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
			</xsl:call-template>
				</Name>				
					
			</xsl:if>
					 
					 
			<xsl:if test="$SRVCHECKER_PVER_LABEL_COUNT='-1'">
					 
					 <Directory>
				   <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
				</Directory>
				<Name>
				  <xsl:value-of select="'\SRVCheckerOutput\srvchecker.log'"/>	
				</Name>
					
		  </xsl:if>
				
					 
				</LookUpFile>
				<!-- this RegEx is used for a list of datas , like Checksum-Names and Values in a PED-Result-File -->
				<!-- Results will be stored in Variable-List of Output-XML -->
				<LookUpPattern_VariableList><![CDATA[(?'Name'(srvchecker)) v(?'Value'(\S*)) -->]]></LookUpPattern_VariableList>
				<!-- these RegEx are used for specific text-patterns in the LookUpFile -->
				<!-- Results will also be stored in Variable-List of Output-XML -->
				<!-- Functionality is not implemented yet -->
				<LookUpPattern_SingleValues>
					<Entry>
						<Name></Name>
						<Pattern></Pattern>
					</Entry>
				</LookUpPattern_SingleValues>
			</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
