Set args = Wscript.Arguments


Dim xmlDoc 
Dim PSTname
Dim PSTVariant
Dim PSTRevision
Dim PIDCvalue
dim xHttp: Set xHttp = createobject("MSXML2.ServerXMLHTTP.6.0")
'dim xHttp: Set xHttp = createobject("MSXML2.XMLHTTP")
dim bStrm: Set bStrm = createobject("Adodb.Stream")
'xHttp.Open "GET", args(0), False
xHttp.Open "GET", "https://rb-archiver.bosch.com:8020/api/Prerun/GetPIDCInfo?sJobNum="+args(0), False, FindVal("lv5lzz_HG"), FindVal("9ChylkfudwgS") 'args(0) - https://rb-klaudia.bosch.com/KLAUDIA.svc/Archiver/ArchivedPath?ID_VALUE=PVERLabel

xHttp.send ""

If xHttp.Status = 200 Then
    ' Prepare to save the response to a file
    bStrm.Type = 1 ' Binary
    bStrm.Open
    bStrm.Write xHttp.responseBody
    bStrm.SaveToFile args(1), 2 ' Overwrite if exists
    bStrm.Close
    WScript.Echo "Response saved successfully."
Else
    WScript.Echo "Error: " & xHttp.Status & " - " & xHttp.StatusText
    WScript.Quit
End If


' Create a FileSystemObject
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Specify the path to the text file you want to read
filePath = args(1)

' Check if the file exists
If objFSO.FileExists(filePath) Then
    ' Open the file for reading
    Set objFile = objFSO.OpenTextFile(filePath, 1) ' 1 = ForReading

    ' Read the contents of the file line by line
    Do Until objFile.AtEndOfStream
        strLine = objFile.ReadLine
        ' You can process the line here, for example, print it
        WScript.Echo strLine
		PIDCvalue = strLine
		'Set objFSO = Nothing
		
		
    Loop

    ' Close the file
    objFile.Close
Else
    ' File does not exist
    WScript.Echo "File does not exist: " & filePath
End If

' Release the FileSystemObject



If objFSO.FileExists(filePath) Then
    objFSO.DeleteFile filePath
    WScript.Echo "File deleted successfully."
Else
    WScript.Echo "File not found."
End If
Set objFSO = Nothing

Set xmlDoc = CreateObject("Microsoft.XMLDOM")
xmlDoc.async = False

' Create the root element
Set root = xmlDoc.createElement("string")
xmlDoc.appendChild root

' Set the value for the root element
root.appendChild xmlDoc.createTextNode(PIDCvalue)

' Save the XML to a file
xmlDoc.save args(1)

' Clean up
Set xmlDoc = Nothing



function FindVal(str)
Dim coded
str = StrReverse(str)
For i=1 to Len(str)
temp = Asc(Mid(str,i,1))
temp = Chr(temp - 3)
coded = coded + (temp)
Next
FindVal = coded
end function