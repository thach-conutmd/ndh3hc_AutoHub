<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
  <xsl:variable name="UseCaseXML" select="''"/>
 <xsl:output method="xml" omit-xml-declaration='yes' 
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
   <xsl:template name="GetController_ID_Suffix">
    <xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:ControllerID" />
    <xsl:variable name="Len" select="string-length($FlagValue)" />
    <xsl:choose>
      <xsl:when test="$Len = '0'">
        <xsl:value-of select="''" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="concat('_',$FlagValue)" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
  <xsl:template name="GetControllerIDValue">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ControllerID"/>
	</xsl:template>
  
	<xsl:template name="Data_Value" >
		<xsl:param name="ID" />
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:*[name()=$ID]"/>
	</xsl:template>
	
  <xsl:template name="GetMainWorkingDir">
    <xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:ControllerID" />
	 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
	  <xsl:variable name="WorkingDirMain" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory_Main" />
    <xsl:variable name="Len" select="string-length($FlagValue)" />
    <xsl:choose>
      <xsl:when test="$Len = '0'">
        <xsl:value-of select="$WorkingDir" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$WorkingDirMain" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
	<xsl:template name="GetFileList">
		<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files"/>
	</xsl:template>
	<xsl:template name="GetNoofVariants">
		<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:NumberOfVariants"/>
	</xsl:template>
	<xsl:template name="GetPDT_DB_Type">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PDT_DB_Type"/>
	</xsl:template>
	<xsl:template name="GetContainerName_PST_Lib">
		 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PST_Lib"/>
	</xsl:template>
	<xsl:template name="GetWorkFlowID">
		 <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Jobnumber"/>
	</xsl:template>
	<xsl:template name="GetWorkingDirectory">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory"/> 
	</xsl:template>
	<xsl:template name="GetVariants">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VCFileCount"/> 
	</xsl:template>
	
	<xsl:template name="GetBootCrl_VersionHex">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:BOOTCRL_VERSION_HEX"/> 
	</xsl:template>
	
	<xsl:template name="GetGUAM_FLAG">
		<xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:GUAM_FLAG"/>
		<xsl:choose>
			<xsl:when test="$FlagValue = '2'">
				<xsl:value-of select="'2'"/>						
			</xsl:when>	 
			<xsl:otherwise>	
				<xsl:value-of select="'1'"/> 
			</xsl:otherwise>				
		</xsl:choose> 
  </xsl:template>
  
	<xsl:template name="GetFilesToExclude">
	    <xsl:param name="FilePath" />
	    <xsl:for-each select="document($FilePath)/FileInformation/FileList/File">
		<xsl:element name="File">
	      <xsl:variable name="ConfFileClassId">
			<xsl:value-of select="FileClassID"  disable-output-escaping="yes" />
		  </xsl:variable>
			  <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$ConfFileClassId]/tctypes:Location/tctypes:Name"/>	    
        </xsl:element>
		</xsl:for-each>
	</xsl:template>
  
			<xsl:template name="GetSSDA2L">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SSD_A2L"/> 
	</xsl:template>
	
			<xsl:template name="GetSRVA2L">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SRV_A2L"/> 
	</xsl:template>
	
		<xsl:template name="GetSRVChecker_PVER_Scan">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:SRVChecker_PVER_Scan"/> 
	</xsl:template>
	
	
	<xsl:template name="GetPVER_Label">
		<xsl:param name="File" />
	    <xsl:value-of select="document($File)/Fields/Field[@Name='PVER_Label']"/>
	</xsl:template>
	
	<xsl:template name="GetPVER_Label_FRA">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Data/PVER_Label"/>
	</xsl:template>
	
	<xsl:template name="GetBuildMode_FRA">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Data/BuildMode"/>
	</xsl:template>
	
		<xsl:template name="GetBuildMode">
		<xsl:param name="File" />
	    <xsl:value-of select="document($File)/Fields/Field[@Name='BuildMode']"/>
	</xsl:template>
	
	<xsl:template name="GetPVER_Path">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PVER_PATH_FOR_TOOL_RUN"/> 
	</xsl:template>
	
	
	<xsl:template name="GetECUSECU_File_Directory">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Files/File/Location/Directory"/>
	</xsl:template> 
	<xsl:template name="GetECUSECU_FileName">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Files/File/Location/Name"/>
	</xsl:template>
	
	
	<xsl:template name="GetRoot_PST_Folder">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Fields/Field[@Name='Root_PST_Folder']"/>
	</xsl:template> 
	<xsl:template name="GetRoot_PST_Folder_FRA">
		<xsl:param name="File" />
		<xsl:value-of select="document($File)/Data/Root_PST_Folder"/>
	</xsl:template> 
	

	<xsl:template name="GetSecurityVersion">
			<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:PD_TOOLNAMES" />
	</xsl:template>

	<xsl:template name="GetPDTools">
			<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:PD_TOOLNAMES" />
	</xsl:template>
	<xsl:template name="GetRunMode">
			<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:RUN_MODE" />
	</xsl:template>
  
<xsl:template name="GetFSWID">
    <xsl:variable name="ProgramVersion" select="/tctypes:UseCase/tctypes:Data/tctypes:FSWID_ProgramVersion"/>
    <xsl:variable name="ProjectVersion" select="/tctypes:UseCase/tctypes:Data/tctypes:FSWID_ProjectVersion"/>
    <xsl:value-of select="concat($ProjectVersion,$ProgramVersion)"/>
  </xsl:template>

	<xsl:template name="GetTPLevelValue">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:TP_Level"/>
	</xsl:template>
	
	<xsl:template name="GetReleaseClass">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ReleaseClass"/>
	</xsl:template>
	<xsl:template name="GetLogDataVariable">
		    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:LogDataVariable"/>
	</xsl:template>

  <xsl:template name="GetWrapperPath">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WrapperPath "/>
  </xsl:template> 
  <xsl:template name="GetConfigFolder">
    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:PDT_Config"/>
  </xsl:template> 
  
  <xsl:template name="GetProgramVersion">
  	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ProgramVersion"/>
  	</xsl:template>
  	
  	<xsl:template name="GetDataVersion">
  	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:DataVersion"/>
	</xsl:template>
	
	
	<xsl:template name="RunTime_Data_Value" >
		<xsl:param name="DataClassID" />
		<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:Value"/>
	</xsl:template>
	

<xsl:template name="Removelastbackslash">
                        <xsl:param name="Path"/>
        <xsl:variable name="length" select="string-length($Path)"/>
        <xsl:choose>
                                   <xsl:when test="substring($Path,$length, 1) = '\'">
                                                            <xsl:value-of select="substring($Path, 1, string-length($Path) - 1)"/>
                                    </xsl:when>
                            <xsl:otherwise>
                                       <xsl:value-of select="$Path"/> 
                                    </xsl:otherwise>
                        </xsl:choose>
            </xsl:template>
			
	<xsl:template name="FileList_GetFileDirectory">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
		<xsl:choose>
			<xsl:when test="$GetValue='yes'">
		        <!-- <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/> -->
				<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
			</xsl:when>		
  		    <xsl:otherwise>
		        <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/> -->
				<xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	
	<xsl:template name="FileList_GetFileName">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
        <xsl:param name="GetExtension" select="'yes'"/>
      <xsl:variable name="File" select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
        <xsl:choose>
 			<xsl:when test="$GetValue='yes'">
 				    <xsl:choose>
 						<xsl:when test="$GetExtension='yes'">
 							<xsl:value-of select="$File"/> 											 				
	 					</xsl:when>
  						<xsl:otherwise>
  							<xsl:value-of select="substring($File, 1, string-length($File) - 4)"/>
  						</xsl:otherwise>
  					</xsl:choose>
			</xsl:when>
  		    <xsl:otherwise>
 			    <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/> -->
				<xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	<xsl:template name="GetAddressLayoutModel">
	    <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel"/>
	</xsl:template>

      <xsl:template name="RunTime_Tool_Path">
    <xsl:param name="ToolName" />
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='TOOL_LIST']/tctypes:Tools/tctypes:Tool[child::tctypes:NAME=$ToolName]/tctypes:Location/*" />
  </xsl:template>

 <xsl:template name="RunTime_Data_Blocks" >
    <xsl:param name="DataClassID" />
    <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$DataClassID]/tctypes:VBF/*"/>
  </xsl:template>
<xsl:template name="ConvertToUpperCase">
    <xsl:param name="string" />
    <xsl:value-of select="translate($string, 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
  </xsl:template>
  
	<xsl:template name="CheckFileExtension">
    <xsl:param name="EXTENSION" /> 
    <xsl:variable name="ExtensionToUpper">
				<xsl:call-template name="ConvertToUpperCase" >
					<xsl:with-param name="string" select ="$EXTENSION"/>
				</xsl:call-template>
			</xsl:variable>	
    <xsl:choose>
      <xsl:when test="$ExtensionToUpper = '.VBF'">
        <xsl:value-of select="'1'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="'0'"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
	<xsl:template name="GetFileExtension">
		<xsl:param name="FileClassID"/>
        <!-- <xsl:variable name="File" select="/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/> -->
		<xsl:variable name="File" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>
  							<xsl:value-of select="substring($File, string-length($File) - 3)"/>
	</xsl:template>

 
		<xsl:template name="GetECUDesignation">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECUType"/>		
		</xsl:template>
		
	
										
		<xsl:template name="GetVarilableListVersion">		
			<xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:VarilableListVersion"/>		
		</xsl:template>
	
		
	
	
<!-- Extraction Runtime-Range	-->
<!-- FileLists -->
<!-- Extraktionen auf Filelisten-->
	<xsl:template name="RunTime_FileList_GetFileDirectory">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
		<xsl:variable name="Final_FileClassId">
		  <xsl:call-template name="GetController_FileClassId"> 
			<xsl:with-param name="FileClassID" select="$FileClassID" />
		  </xsl:call-template>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="$GetValue='yes'">
		       <!-- <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>-->
				<xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($Final_FileClassId, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
			</xsl:when>		
  		    <xsl:otherwise>
		       <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory"/>-->
				<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($Final_FileClassId, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Directory"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

   <xsl:template name="GetController_FileClassId">
	<xsl:param name="FileClassID"/>
    <xsl:variable name="FlagValue" select="/tctypes:UseCase/tctypes:Data/tctypes:ControllerID" />
	<xsl:variable name="Suffix_FileClassId" select="concat('_CNT_',$FlagValue)" />
    <xsl:variable name="Len" select="string-length($FlagValue)" />
    <xsl:choose>
      <xsl:when test="$Len = '0'">
        <xsl:value-of select="$FileClassID" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="concat($FileClassID,$Suffix_FileClassId)" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

	<xsl:template name="RunTime_FileList_GetFileName">
		<xsl:param name="FileClassID"/>
        <xsl:param name="GetValue" select="'yes'"/>
        <xsl:param name="GetExtension" select="'yes'"/>
		<xsl:variable name="Final_FileClassId">
		  <xsl:call-template name="GetController_FileClassId"> 
			<xsl:with-param name="FileClassID" select="$FileClassID" />
		  </xsl:call-template>
		</xsl:variable>
        <!-- <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>        -->
        <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($Final_FileClassId, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
		<xsl:choose>
 			<xsl:when test="$GetValue='yes'">
 				    <xsl:choose>
 						<xsl:when test="$GetExtension='yes'">
 							<xsl:value-of select="$File_Runtime"/> 											 				
	 					</xsl:when>
  						<xsl:otherwise>
  							<xsl:value-of select="substring($File_Runtime, 1, string-length($File_Runtime) - 4)"/>
  						</xsl:otherwise>
  					</xsl:choose>
			</xsl:when>
  		    <xsl:otherwise>
 			    <!-- <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name"/>  -->
				<xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[translate(child::tctypes:FileClassID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = translate($Final_FileClassId,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]/tctypes:Location/tctypes:Name"/>
		  	</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	
	  <!-- For HCP1 FILECLASSIDs that do not need "_CNT_<controllerID>" (independent of toolchainusecase entry)-->
  <xsl:template name="RunTime_FileListGeneral_GetFileDirectory">
    <xsl:param name="FileClassID" />
    <xsl:param name="GetValue" select="'yes'" />
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <xsl:value-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory" />
      </xsl:when>
      <xsl:otherwise>
        <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Directory" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  <xsl:template name="RunTime_FileListGeneral_GetFileName">
    <xsl:param name="FileClassID" />
    <xsl:param name="GetValue" select="'yes'" />
    <xsl:param name="GetExtension" select="'yes'" />
    <xsl:variable name="File_Runtime" select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name" />
    <xsl:choose>
      <xsl:when test="$GetValue='yes'">
        <xsl:choose>
          <xsl:when test="$GetExtension='yes'">
            <xsl:value-of select="$File_Runtime" />
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="substring($File_Runtime, 1, string-length($File_Runtime) - 4)" />
          </xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:otherwise>
        <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$FileClassID]/tctypes:Location/tctypes:Name" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>	
	
      <xsl:template name="GetXMLFile">
             <xsl:param name="File" />
             <xsl:apply-templates mode="myCopy" select="document($File)/*"/>
      </xsl:template>
	
      <xsl:template name="GetXMLFromFile">
           <xsl:param name="File" />
           <xsl:copy-of select="document($File)/*"/>
      </xsl:template>

      <xsl:template name="GetCustomerGroup">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerGroup"/>
	</xsl:template>

      <xsl:template name="GetCustomerCodeNumber">
	    <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:CustomerCodeNumber"/>
	</xsl:template>

      <xsl:template name="GetECUGeneration">
           <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECUGeneration"/>
		   
      </xsl:template>
	  
	  <!-- <xsl:template name="GetECUDesignation"> -->
           <!-- <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:ECU_Designation"/> -->
      <!-- </xsl:template> -->
	  
	  <xsl:template name="GetBrand">
           <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:Brand"/>
      </xsl:template>
	  
	  <xsl:template name="GetWorkingMode">
           <xsl:value-of select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingMode"/>
      </xsl:template>
      
     <xsl:template name="GetABMBLOCKS">
       <xsl:copy-of select="/tctypes:UseCase/tctypes:Data/tctypes:AddressLayoutModel/tctypes:ABMBlocks/*"/>
    </xsl:template>

  <!--Create a dynamic variable list -->
  <xsl:template name="CreateVariableList">
    <xsl:param name="File" />
    <xsl:for-each select="document($File)/Config/Variables/Variable">
      <xsl:variable name="SourceType" select="SourceType" />
      <xsl:variable name="Source" select="Source" />
      <xsl:element name="Variable">
        <xsl:element name="Name">
          <xsl:value-of select="Name" />
        </xsl:element>
        <xsl:element name="Value">
          <xsl:choose>
            <xsl:when test="$SourceType = 'HRD'">
              <xsl:value-of select="$Source" disable-output-escaping="yes" />
            </xsl:when>
            <xsl:when test="$SourceType = 'DATA'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:*[name()=$Source]"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'DATA_R'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID=$Source]/tctypes:Value"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'FILE'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
              <xsl:value-of select="'\'"/>
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:Data/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'FILE_R'">
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Directory"/>
              <xsl:value-of select="'\'"/>
              <xsl:value-of select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files/tctypes:File[child::tctypes:FileClassID=$Source]/tctypes:Location/tctypes:Name"/>
            </xsl:when>
            <xsl:when test="$SourceType = 'LIB'">
              <xsl:call-template name="GetEnvironmentValue">
                <xsl:with-param name="LookUpItem" select="$Source" />
              </xsl:call-template>
            </xsl:when>
            <xsl:otherwise></xsl:otherwise>
          </xsl:choose>
        </xsl:element>
        <xsl:element name="Optional">
          <xsl:value-of select="Optional" />
        </xsl:element>
      </xsl:element>
    </xsl:for-each>
  </xsl:template>
  
  
  
  
  <xsl:template name="GetToolDirectoryFromConfig">
			<xsl:param name="File" />
			<xsl:param name="ToolNameValue" />
			<xsl:value-of select="document($File)/Tools/Tool[child::ToolName=$ToolNameValue]/ToolDirectory"/> 
	</xsl:template>
	
  <xsl:template name="GetToolNameFromConfig">
			<xsl:param name="File" />
			<xsl:param name="ToolNameValue" />
			<xsl:value-of select="document($File)/Tools/Tool[child::ToolName=$ToolNameValue]/Name"/> 
	</xsl:template>
	
	<xsl:template name="ReadPVERArchivePath">
		<xsl:param name="File" />
	    <xsl:value-of select="document($File)/*"/>
	</xsl:template>
	
	
	<xsl:template name="jsonescape">
 <xsl:param name="Path" select="."/>
  <xsl:choose>
    <xsl:when test="contains($Path, '\')">
      <xsl:value-of select="concat(substring-before($Path, '\'), '\\' )"/>
      <xsl:call-template name="jsonescape">
        <xsl:with-param name="Path" select="substring-after($Path, '\')"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:otherwise>
        <xsl:value-of select="$Path"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>
	
	<xsl:template name="GetWorkFlowList">
    <xsl:copy-of  select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/*"/>
  </xsl:template>

 <xsl:template mode="myCopy" match="*">
    <xsl:element name="{name(.)}">
      <xsl:copy-of select="@*" />
      <xsl:apply-templates mode="myCopy" />
    </xsl:element>
  </xsl:template>
  <xsl:template name="GetRunTimeFiles">
           <xsl:copy-of select="/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Files"/>
      </xsl:template>

</xsl:stylesheet>
