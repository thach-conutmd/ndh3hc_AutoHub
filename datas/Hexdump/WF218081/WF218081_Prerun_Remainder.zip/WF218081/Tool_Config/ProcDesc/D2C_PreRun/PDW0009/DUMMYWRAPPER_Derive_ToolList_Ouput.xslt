<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<!-- To decide SCAN_LST_FLAG. 1 = TRUE, 0 = FALSE -->	
	
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				
				
				<ResultingFiles>
				<File>
					<FileClassID>SRVCheckerTool</FileClassID>
					<FileClassName>SRVCheckerTool</FileClassName>
					<Location>
						<Directory>
							
							<xsl:value-of select="'C:\toolbase\srvchecker\'"/>	
							<xsl:call-template name="RunTime_Data_Value" >
						<xsl:with-param name="DataClassID" select="'SRVChecker_LatestToolVersion'"/>
					      </xsl:call-template>

																			
						</Directory>
						<Name><xsl:value-of select="'srvchecker.exe'"/></Name>
					</Location>
				</File>
    		</ResultingFiles>
				
    		
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
