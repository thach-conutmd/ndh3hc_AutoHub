<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
	 <xsl:variable name="BOOTCTRL_HEX_FILE_CLS_ID">
		<xsl:call-template name="GetBootCrl_VersionHex"></xsl:call-template>
	 </xsl:variable>
	 
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		   <Output>	
		   <ResultingFiles>  	  	  	  	  
				<File>
					<FileClassID>BOOTCTRL_HEX</FileClassID>
					<FileClassName>BOOTCTRL_HEX</FileClassName>
					<Location>
						<Directory>
							<xsl:call-template name="RunTime_FileListGeneral_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="$BOOTCTRL_HEX_FILE_CLS_ID"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>						
						</Directory>
						<Name>
						<xsl:call-template name="RunTime_FileListGeneral_GetFileName">
								<xsl:with-param name="FileClassID" select="$BOOTCTRL_HEX_FILE_CLS_ID"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template>
						</Name>
					</Location>
				</File>
		   </ResultingFiles> 
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber/>
					<ErrorMessage/>
				</ErrorInformation>
			</ReturnInformation>    		
	</ToolOutput> 
	</xsl:template>
</xsl:stylesheet>
