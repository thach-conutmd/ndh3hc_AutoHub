<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>ZIP LST Files</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
          <Directory/>
          <Name/>
        </TargetTemplateFile>
				<Script></Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				<CommandLine>
					<xsl:value-of select="' a -tzip '" />
					<xsl:value-of select="' '" />
					<xsl:value-of select="'&quot;'" />  
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
					<xsl:value-of select="'\LST_Files.zip'" />
					<xsl:value-of select="'&quot;'" />
					<xsl:value-of select="' '" />	
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>					
					<xsl:value-of select="'\SRVCheckerOutput\*_srvchecker_impact.lst'" />
					<xsl:value-of select="'&quot;'" />  
				</CommandLine>
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
			<CallInformation>
				<ToolName>
        </ToolName>
				<CallType></CallType>
				<ToolVersion/>
				<ToolLocation>
          <Directory>
            <xsl:value-of select="'C:\Program Files\7-Zip'"/>
          </Directory>
          <Name>
            <xsl:value-of select="'7z.exe'"/>
          </Name>
 				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
