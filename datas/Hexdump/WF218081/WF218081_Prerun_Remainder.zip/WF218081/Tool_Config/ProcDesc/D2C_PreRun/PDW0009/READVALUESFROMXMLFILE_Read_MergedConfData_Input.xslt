<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Read datas from Merged_Config file</Mode>
			<Input>
				<!-- Init-Values for Progress-Display -->
				<EstimatedRunTime>10</EstimatedRunTime> <!-- 10 Minutes-->
				<DateTimeInterval>1</DateTimeInterval> <!-- 1 = Minutes  / 0 = Seconds-->				
				<SourceTemplateFile>
					<Directory>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileName">
							<xsl:with-param name="FileClassID" select="'MERGED_CONFIG'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
					</Name>
				</SourceTemplateFile>
				<ReadVaraibeList>
					<Variables>						
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>GUAM_FLAG</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_HSM/SECURITY_VARIANT</Xpath>
						</Variable>						
						<Variable>
							<Write2PSTLib>False</Write2PSTLib>
							<TrimValue>True</TrimValue>
							<ID>CFGEXP_MACHINE_TYPE</ID>
							<Xpath>//CONF/CFGEXP/CFGEXP_MACHINE_TYPE</Xpath>
						</Variable>							
					</Variables>
				</ReadVaraibeList>
			</Input>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
