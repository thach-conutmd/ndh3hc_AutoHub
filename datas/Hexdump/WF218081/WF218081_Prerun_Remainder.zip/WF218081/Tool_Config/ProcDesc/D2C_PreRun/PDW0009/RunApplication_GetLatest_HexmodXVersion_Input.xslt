<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Get HexmodX latest tool version from toolbase</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
          <Directory/>
          <Name/>
        </TargetTemplateFile>
				<Script></Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				  <CommandLine></CommandLine>
				<CommandLines>
				<CommandLine>
         <xsl:value-of select="' '" />
		  <xsl:value-of select="'&quot;'" /> 
		  <xsl:call-template name="GetWorkingDirectory"/>
            	<xsl:value-of select="'\LatestToolVersion_HexmodX.txt'"/>
			<xsl:value-of select="'&quot;'" /> 
			
       </CommandLine>
				

				</CommandLines>
				
			
				
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
		
    <CallInformation>
		<ToolName>Run Latest toolversion batch file</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation> 
		 <Directory>
			<xsl:call-template name="GetConfigFolder"></xsl:call-template>
          </Directory>
          <Name>	
		  <xsl:value-of select="'\'" /> 		  
		  <xsl:call-template name="Data_Value">
			  	<xsl:with-param name="ID" select="'LatestToolVersion_Batch'" />
			  </xsl:call-template>			
          </Name>
    </ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>