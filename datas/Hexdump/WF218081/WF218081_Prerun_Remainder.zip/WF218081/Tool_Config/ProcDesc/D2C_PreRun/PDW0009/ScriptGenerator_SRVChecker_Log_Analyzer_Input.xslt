 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="AddressModelFile"  select="concat($WorkingDir, '\AddressModel.xml')" />
<xsl:variable name="InfotableLogFile"  select="concat($WorkingDir, '\InfotableLog.xml')" />

<xsl:template match="/">

    <ToolInput>
    <Mode> Prepare Scripts </Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>					
			<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>CHECK_SRVCHECKER_ERROR</Key>
				<Comment>Script for findig error in SRV Checker</Comment>
				<ScriptTemplate>
				  <xsl:call-template name="GetEnvironmentValue">
				    <xsl:with-param name="LookUpItem" select="'CHECK_SRVCHECKER_ERROR'"/>
				  </xsl:call-template>
				</ScriptTemplate>
				<DataBase>
				  <Datas>
				 <SRVCheckerLog>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\SRVCheckerOutput\srvchecker.log'"/>							
				  </SRVCheckerLog>
				  </Datas>
				</DataBase>
			</Script>
			<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>CHECK_PVER_LABEL_COUNT</Key>
				<Comment>Script for affected label count</Comment>
				<ScriptTemplate>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'CHECK_PVER_LABEL_COUNT'" />
					</xsl:call-template>
				</ScriptTemplate>
				<DataBase>
				 <Datas>
					<ScanLSTFile>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>							
				  </ScanLSTFile>
				  </Datas>
				</DataBase>
			</Script>	
			<Script>
				<Write2PSTLib>False</Write2PSTLib>
				<Key>CHECK_AFFECTED_LABEL_COUNT</Key>
				<Comment>Script for affected label count</Comment>
				<ScriptTemplate>
					<xsl:call-template name="GetEnvironmentValue">
						<xsl:with-param name="LookUpItem" select="'CHECK_AFFECTED_LABEL_COUNT'" />
					</xsl:call-template>
				</ScriptTemplate>
				<DataBase>
				 <Datas>
					<SRVCheckerLog>
						<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						<xsl:value-of select="'\SRVCheckerOutput\srvchecker.log'"/>							
				  </SRVCheckerLog>
				  </Datas>
				</DataBase>
			</Script>				
			
		</Scripts>
		<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
