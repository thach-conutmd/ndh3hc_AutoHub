<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_APPLICATION_FILESLIST" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='DERIVE_APPLICATION_FILES_LIST']/tctypes:Value"/>
 <!-- <xsl:variable name="RT_SCAN_LST_FLAG" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='SCAN_LST_FLAG']/tctypes:Value"/> -->
 <xsl:variable name="RT_PVER_SCAN" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='SCAN_LST_FLAG']/tctypes:Value" />

 
</xsl:stylesheet>