 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Run ADAPTER</Mode>
    <Input>
    
    	<!-- Init-Values for Progress-Display -->
		<EstimatedRunTime>10</EstimatedRunTime>	<!-- 10 Minutes-->
		<DateTimeInterval>0</DateTimeInterval>				<!-- 1 = Minutes  / 0 = Seconds-->
		
     	<SourceTemplateFile>
			<Directory></Directory>
			<Name></Name>
		</SourceTemplateFile>
		<TargetTemplateFile>
			<Directory><xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template></Directory>
			<Name><xsl:value-of select="'\AdapterInput.json'"/></Name>
		</TargetTemplateFile>
		
		<Script>
			<xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'SCRIPT_ADAPTER_JSON'" />
			</xsl:call-template>
		</Script>
		<ScriptMandatory>1</ScriptMandatory>
		<Variables>
			<Variable>
				<Name>WorkingDirectory</Name>
				<Value><xsl:call-template name="jsonescape">
				<xsl:with-param name="Path">
						<xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template>						
				</xsl:with-param>
				</xsl:call-template></Value>
			</Variable>	
			<Variable>
				<Name>WorkingDirectory_Main</Name>
				<Value><xsl:call-template name="jsonescape">
				<xsl:with-param name="Path">
						<xsl:call-template name="GetMainWorkingDir">
						</xsl:call-template>						
				</xsl:with-param>
				</xsl:call-template></Value>
			</Variable>	
			<Variable>
				<Name>PVERPATH</Name>
				<Value>
				<xsl:call-template name="jsonescape"><xsl:with-param name="Path">
				<xsl:call-template name="GetPVER_Path"></xsl:call-template></xsl:with-param></xsl:call-template>
				</Value>						
							
			</Variable>
			<Variable>
				<Name>FL_PI</Name>
				<Value><xsl:call-template name="jsonescape">
				<xsl:with-param name="Path"><xsl:call-template name="GetWrapperPath">
						</xsl:call-template>
						<xsl:value-of select="'\FL_LIST.xml'"/></xsl:with-param>
						</xsl:call-template></Value>		
			</Variable>				
		</Variables>
		<CommandLine>
					<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>	
					<xsl:value-of select="'\AdapterInput.json'"/>
		</CommandLine>
    </Input>  
    <CallInformation>
		<ToolName>ADAPTER</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		
		<ToolLocation> 
		 <Directory><xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'Adapter_path'" />
					 </xsl:call-template></Directory>
          <Name>Adapter_Wrapper.exe</Name>
    </ToolLocation>
		
		     <!--  <xsl:call-template name="RunTime_Tool_Path">
        <xsl:with-param name="ToolName" select="'ADAPTER'"/>
      </xsl:call-template> -->
    
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
