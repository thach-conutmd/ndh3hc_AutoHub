import com.bosch.hexmodx.exception.HexmodXException;
import com.bosch.hexmodx.hexInterfaces.HexmodXLogLevel;
import com.bosch.hexmodx.hexInterfaces.IHexDataInterface;
import com.bosch.hexmodx.hexInterfaces.IInfoblockManager;
import com.bosch.hexmodx.hexUtils.HexUtils;
import com.bosch.hexmodx.hexmodel.HexObjectFactory;
import com.bosch.hexmodx.loggingframework.HexmodXLogger;
import com.bosch.hexmodx.mdg1.infoblock.core.AbstractInfoblockManagerFactory;
import com.bosch.hexmodx.mdg1.infoblock.core.InfoblockManager;
import com.bosch.hexmodx.mdg1.infoblock.core.MDGType;
import com.bosch.hexmodx.parsers.HexmodxFileParser;
import com.bosch.hexmodx.xmlParser.RulesParser;

    try {
	  String sMdgType = "";
      String inputHexFile = getProperty("1");
      String ibAddress = getProperty("2");
      String type = inputHexFile.substring(inputHexFile.lastIndexOf(".") + 1);
      type = type.equalsIgnoreCase("hex") ? "IHEX" : type;
      HexmodxFileParser parser = RulesParser.createHexmodXFileParser(type);
      IHexDataInterface hexObject = HexObjectFactory.createHexObject();

      parser.parse(hexObject, inputHexFile, true);

      IInfoblockManager infoblockManager = AbstractInfoblockManagerFactory.createInstance(ibAddress, hexObject);
      MDGType mdgType =
          ((InfoblockManager) infoblockManager).identifyMDGTypeFromHexFile(HexUtils.validateAndConvert(ibAddress));
      HexmodXLogger.logMessage(HexmodXLogLevel.INFO, "BSH-MDG-TYPE", "MDG_TYPE: " + mdgType);     
	  sMdgType = mdgType;
	  BufferedWriter out = new BufferedWriter(new FileWriter("MDGType.txt",true));  
	  out.write("MDG_TYPE: " + sMdgType);
	  out.close();	
	  System.out.println(mdgType);
    }
    catch (HexmodXException e) {
      HexmodXLogger.logMessage(HexmodXLogLevel.ERROR, "BSH-FAILED", e.getMessage());
      System.out.println(e.getMessage());
    }
