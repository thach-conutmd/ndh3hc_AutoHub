 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>


<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>


    <xsl:template match="/">
    <ToolInput>
    <Mode>Read VBF Header checksum</Mode>
    <Input>

      <LookUpFile>
        <Directory>
          <xsl:call-template name="RunTime_FileList_GetFileDirectory" >
            <xsl:with-param name="FileClassID" select="'VBF_Header_File_Checksum'"/>
            <xsl:with-param name="GetValue" select="'yes'"/>
          </xsl:call-template>
        </Directory>
        <Name>
          <xsl:value-of select="'\'"/>
          <xsl:call-template name="RunTime_FileList_GetFileName" >
            <xsl:with-param name="FileClassID" select="'VBF_Header_File_Checksum'"/>
            <xsl:with-param name="GetValue" select="'yes'"/>
          </xsl:call-template>
        </Name>
      </LookUpFile>   
		<LookUpPattern_VariableList><![CDATA[(?'Name'(file_checksum))[\s]*=[\s]*0x(?'Value'([0-9A-Fa-f]{8}))\;]]></LookUpPattern_VariableList>
		<!-- these RegEx are used for specific text-patterns in the LookUpFile -->
		<!-- Results will also be stored in Variable-List of Output-XML -->
		<!-- Functionality is not implemented yet -->
		<LookUpPattern_SingleValues>
			<Entry>
				<Name></Name>
				<Pattern></Pattern>
			</Entry>
		</LookUpPattern_SingleValues>
		
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation></ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
