 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
 <!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
 <xsl:param name="PUseCaseXML"/>
 
<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
    <xsl:template match="/">
    <ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		<Output>
			<ResultingFiles>							
				<File>
					<FileClassID>BIN_File</FileClassID>
					<FileClassName>BIN_File</FileClassName>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
							<xsl:value-of select="'.bin'"/></Name>
					</Location>
				</File>
				
        <!--#Added on 09.12.2009 -->
        <File>
          <FileClassID>VBF_HEADER_File</FileClassID>
          <FileClassName>VBF_HEADER_File</FileClassName>
          <Location>
            <Directory>
              <xsl:call-template name="GetWorkingDirectory">
              </xsl:call-template>
            </Directory>
            <Name>
              <xsl:call-template name="RunTime_FileList_GetFileName" >
                <xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
                <xsl:with-param name="GetValue" select="'yes'"/>
                <xsl:with-param name="GetExtension" select="'no'"/>
              </xsl:call-template>
              <xsl:value-of select="'.txt'"/>
            </Name>
          </Location>
        </File>
		<File>
					<FileClassID>BIN_DECRYPTED</FileClassID>
					<FileClassName>BIN_DECRYPTED</FileClassName>
					<Location>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'APPLIEDFILE_1'"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							<xsl:with-param name="GetExtension" select="'no'"/>
						</xsl:call-template>
							<xsl:value-of select="'_decrypted.bin'"/></Name>
					</Location>
				</File>
			</ResultingFiles>
			<VBF>
			</VBF>
		</Output>
		<ReturnInformation>
		<ReturnCode></ReturnCode>
		<TimeStart></TimeStart>
		<TimeFinish></TimeFinish>
		<ErrorInformation>
			<ErrorNumber/>
			<ErrorMessage/>
		</ErrorInformation>
	</ReturnInformation>    		
	</ToolOutput> 
  </xsl:template>
</xsl:stylesheet>
