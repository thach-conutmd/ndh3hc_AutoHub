<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
	<ToolInput>
		<Mode>Checkin Operation</Mode>
			<Input>
	<!-- Checkout=2 and check-in = 1 --> 
		<PDTDB_Mode>1</PDTDB_Mode>
			<Database>
				<xsl:call-template name="GetPDT_DB_Type"/>
			</Database>
		<ContainerName><xsl:call-template name="GetWorkFlowID"/></ContainerName>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"/></WorkingDirectory>
		 <Files>
			<File>
				<FileClassID>SSD_COMPLIANCE_CHECK</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_CHECK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_CHECK'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>
			<File>
				<FileClassID>RESIZED_APPLIEDFILES</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'RESIZED_APPLIEDFILES'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'RESIZED_APPLIEDFILES'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/>
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>
			<File>
				<FileClassID>SSD_COMPLIANCE_REFERENCE</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_REFERENCE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_REFERENCE'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/>				
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
			<File>
				<FileClassID>SSD_COMPLIANCE_A2L</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_A2L'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'SSD_COMPLIANCE_A2L'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
			<File>
				<FileClassID>CRITICAL_DATA_ACCESS_ULF</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_ULF'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_ULF'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
			<File>
				<FileClassID>CRITICAL_DATA_ACCESS_LST</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
			<File>
				<FileClassID>PRERUN_EXTERNAL_RESULT</FileClassID>
					<Name>
						<xsl:call-template name="GetWorkingDirectory"/>
						<xsl:value-of select="'\PreRun_Parameter_PDT_CC'"/><xsl:call-template name="GetController_ID_Suffix"></xsl:call-template>
							<xsl:value-of select="'.xml'"/>
					</Name>
					<Optional>false</Optional>
			</File>	
			
		</Files>
       
		<Global_FileList>
			<xsl:call-template name="GetConfigFolder"/>
			<xsl:value-of select="'\Global_FileList.txt'"/>
		</Global_FileList>
		
		<SystemConstants>
			<ExternalResult_File>
				<xsl:call-template name="GetWorkingDirectory"/>
				<xsl:value-of select="'\PreRun_Parameter_PDT_CC'"/>
							<xsl:call-template name="GetController_ID_Suffix"></xsl:call-template>
							<xsl:value-of select="'.xml'"/>
			</ExternalResult_File>
			<SystemConstantConfigFile>
				<xsl:call-template name="GetConfigFolder"/>
				<xsl:value-of select="'\Systconst_Configuration_checkin.xml'"/>
			</SystemConstantConfigFile>
			<ExportXml_File>
				<xsl:call-template name="GetWorkingDirectory"/>
				<xsl:value-of select="'\'"/>
				<xsl:call-template name="GetWorkFlowID"/>
				<xsl:value-of select="'_prerun_export.xml'"/>
			</ExportXml_File>

			<Variables>
			<!--<Variable>
					<Name>S-DrivePath</Name>
					<Value>
						<xsl:call-template name="GetRoot_PST_Folder">
						 <xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param> 
						</xsl:call-template>
					</Value>
					<Optional>false</Optional>
				</Variable>
	
				<Variable>
					<Name>PVER_Identification</Name>
					<Value>
						<xsl:call-template name="GetPVER_Label">
						<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param>
						</xsl:call-template>
					</Value>
					<Optional>false</Optional>
				</Variable>-->
				
				<xsl:call-template name="CreateVariableList" >
					<xsl:with-param name="File">
						<xsl:call-template name="GetConfigFolder"></xsl:call-template>
						<xsl:value-of select="'\'" />
						<xsl:value-of select="'PDTDB_Checkin_VariableList_V01.xml'" />
					</xsl:with-param>
				</xsl:call-template>
			</Variables>
		</SystemConstants>
	</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>