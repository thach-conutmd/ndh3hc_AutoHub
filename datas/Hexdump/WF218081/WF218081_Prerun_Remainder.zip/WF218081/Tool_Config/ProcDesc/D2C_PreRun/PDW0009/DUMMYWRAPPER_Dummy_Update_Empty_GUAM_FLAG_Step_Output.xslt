<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
		   <Output>	
				<GUAM_FLAG><xsl:call-template name="GetGUAM_FLAG"></xsl:call-template></GUAM_FLAG>
			</Output>
			<ReturnInformation>
				<ReturnCode></ReturnCode>
				<TimeStart></TimeStart>
				<TimeFinish></TimeFinish>
				<ErrorInformation>
					<ErrorNumber/>
					<ErrorMessage/>
				</ErrorInformation>
			</ReturnInformation>    		
	</ToolOutput> 
	</xsl:template>
</xsl:stylesheet>
