<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_PVER_SCAN" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECK_SRVCHECKER_ERROR_SCAN_LST_BUGGY_VERSION']/tctypes:Value" />
 <xsl:variable name="RT_BUGGY_SCAN_LST" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECK_SRVCHECKER_ERROR_SCAN_LST_BUGGY_VERSION']/tctypes:Value" />
 
 
</xsl:stylesheet>