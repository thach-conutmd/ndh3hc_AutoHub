<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

  <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:variable name="RT_BIN_File"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='BIN_File']/tctypes:Location"/>
<xsl:variable name="RT_VBF" select="tctypes:ToolOutput/tctypes:Output/tctypes:VBF"/>
  <!--#Added on 09.12.2009-->
  <xsl:variable name="RT_VBF_Header_File"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='VBF_HEADER_File']/tctypes:Location"/>  
  <xsl:variable name="RT_DECRYPT_BIN_File"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='BIN_DECRYPTED']/tctypes:Location"/>  
</xsl:stylesheet>

