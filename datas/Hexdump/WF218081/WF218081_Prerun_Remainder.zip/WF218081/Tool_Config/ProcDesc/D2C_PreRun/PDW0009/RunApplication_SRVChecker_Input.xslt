<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	<!-- To decide SCAN_LST_FLAG. 1 = TRUE, 0 = FALSE -->	
	<xsl:variable name="ScanLSTFlag">
		 <!-- <xsl:call-template name="RunTime_Data_Value">
			 <xsl:with-param name="DataClassID" select="'SCAN_LST_FLAG'" />
		 </xsl:call-template> -->
		  <xsl:call-template name="GetSRVChecker_PVER_Scan"/>
	 </xsl:variable>
	 
	 	
		 <xsl:variable name="SRV_A2L_FILE_CLS_ID">
		 		<xsl:call-template name="GetSRVA2L"></xsl:call-template>
	 </xsl:variable>
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Execute SRV Checker</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
          <Directory/>
          <Name/>
        </TargetTemplateFile>
				<Script></Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				  <CommandLine></CommandLine>
				<CommandLines>
				
					<xsl:if test="$ScanLSTFlag='0'">	
				<!-- If srvchecker_scan.lst is not created in D2C -->
				<CommandLine>
          <xsl:value-of select="' --root '" />
          <xsl:value-of select="'&quot;'" />
		  <xsl:call-template name="GetPVER_Path"></xsl:call-template>
                   <!-- <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder">
                                                    <xsl:with-param name="File">
                                                                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                <xsl:value-of select="'\AdapterParam.xml'" />
                                                    </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template>
			          <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder_FRA">
                                                  <xsl:with-param name="File">
                                                              <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                              <xsl:value-of select="'\AdapterParam.xml'" />
                                                  </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template> -->	
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' -o '" />
          <xsl:value-of select="'&quot;'" />          
          <xsl:call-template name="GetWorkingDirectory"/>
          <xsl:value-of select="'\SRVCheckerOutput'"/>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --no-backup '" />
       </CommandLine>
				</xsl:if>
				<!-- If srvchecker_scan.lst is created in D2C -->
					<xsl:if test="$ScanLSTFlag='1'">
				<CommandLine>
          <xsl:value-of select="' --input-lst '" />
          <xsl:value-of select="'&quot;'" />         
			<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
				<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
			</xsl:call-template>
            <xsl:value-of select="'\'" />
			<xsl:call-template name="RunTime_FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
			</xsl:call-template>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --output-path '" />
          <xsl:value-of select="'&quot;'" />          
          <xsl:call-template name="GetWorkingDirectory"/>
          <xsl:value-of select="'\SRVCheckerOutput'"/>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --a2l '" />
          <xsl:value-of select="'&quot;'" />          
			 <xsl:call-template name="GetWorkingDirectory"/>
            <xsl:value-of select="'\'" />
			<xsl:call-template name="RunTime_FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="$SRV_A2L_FILE_CLS_ID"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
			</xsl:call-template>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --hex '" />
          <xsl:value-of select="'&quot;'" /> 
			<xsl:call-template name="GetWorkingDirectory" />
          <xsl:value-of select="'\ApplicationFileList.lst'"/>
          <xsl:value-of select="'&quot;'" /> 
          <xsl:value-of select="' --log '" />
		   <xsl:value-of select="' --no-backup '" />
				</CommandLine>
				</xsl:if>
			
			<xsl:if test="$ScanLSTFlag='0'">	
				<!-- If srvchecker_scan.lst is not created in D2C -->
				<CommandLine>
          <xsl:value-of select="' --root '" />
          <xsl:value-of select="'&quot;'" />
		  <xsl:call-template name="GetPVER_Path"></xsl:call-template>
         <!--  <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder">
                                                <xsl:with-param name="File">
                                                            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                            <xsl:value-of select="'\AdapterParam.xml'" />
                                                </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template>
                    <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder_FRA">
                                                                                                <xsl:with-param name="File">
                                                                                                            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                                                            <xsl:value-of select="'\AdapterParam.xml'" />
                                                                                                </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template> -->		
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' -o '" />
          <xsl:value-of select="'&quot;'" />          
          <xsl:call-template name="GetWorkingDirectory"/>
          <xsl:value-of select="'\SRVCheckerOutput'"/>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --a2l '" />
          <xsl:value-of select="'&quot;'" />          
			<xsl:call-template name="GetWorkingDirectory"/>
			<xsl:value-of select="'\'" />
            <xsl:call-template name="RunTime_FileList_GetFileName" >
				<xsl:with-param name="FileClassID" select="$SRV_A2L_FILE_CLS_ID"/>
				<xsl:with-param name="GetValue" select="'yes'"/>
			</xsl:call-template>
          <xsl:value-of select="'&quot;'" />
          <xsl:value-of select="' --hex '" />
          <xsl:value-of select="'&quot;'" /> 
			<xsl:call-template name="GetWorkingDirectory"/>
          <xsl:value-of select="'\ApplicationFileList.lst'"/>
          <xsl:value-of select="'&quot;'" /> 
          <xsl:value-of select="' --log '" />
		  <xsl:value-of select="' --no-backup '" />
       </CommandLine>
				</xsl:if>
				
				
				</CommandLines>
				
			
				
				<LogFileAnalyser>
				<Files>
					<File>
						<Classification>SRVChecker</Classification>
						<Key></Key>
						<Directory><xsl:call-template name="GetWorkingDirectory">
									</xsl:call-template></Directory>
						<Name><xsl:value-of select="'\SRVCheckerOutput\srvchecker.log'"/></Name>
					</File>
				</Files>
				</LogFileAnalyser>
			</Input>
		
    <CallInformation>
		<ToolName>srvchecker</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
	<!--	<ToolLocation> 
		 <Directory>
			<xsl:call-template name="GetToolDirectoryFromConfig">
			<xsl:with-param name="File">
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\ToolListConfig.XML'" />
			</xsl:with-param>
			<xsl:with-param name="ToolNameValue">
				<xsl:value-of select="'SRVChecker'" />
			</xsl:with-param>
			</xsl:call-template>
          </Directory>
          <Name>
			<xsl:call-template name="GetToolNameFromConfig">
			<xsl:with-param name="File">
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\ToolListConfig.XML'" />
			</xsl:with-param>
			<xsl:with-param name="ToolNameValue">
				<xsl:value-of select="'SRVChecker'" />
			</xsl:with-param>
			</xsl:call-template>
          </Name>
    </ToolLocation>-->
	<ToolLocation>
		 <Directory>
			<xsl:call-template name="RunTime_FileListGeneral_GetFileDirectory">
							<xsl:with-param name="FileClassID" select="'SRVCHECKER_TOOL'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
		
          </Directory>
          <Name>
			<xsl:call-template name="RunTime_FileListGeneral_GetFileName">
							<xsl:with-param name="FileClassID" select="'SRVCHECKER_TOOL'" />
							<xsl:with-param name="GetValue" select="'yes'" />
						</xsl:call-template>
          </Name>
	</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
