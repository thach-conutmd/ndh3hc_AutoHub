<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 
 <xsl:variable name="RT_SSD_COMPLIANCE_CHECK"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_CHECK']/tctypes:Location"/>
 <xsl:variable name="RT_SSD_COMPLIANCE_REFERENCE"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_REFERENCE']/tctypes:Location"/>
<xsl:variable name="RT_SSD_COMPLIANCE_A2L"	select="tctypes:ToolOutput/tctypes:Output/tctypes:ResultingFiles/tctypes:File[child::tctypes:FileClassID='SSD_COMPLIANCE_A2L']/tctypes:Location"/>

  <xsl:variable name="RT_Toworkflow_Data_To_Usecase" select="tctypes:ToolOutput/tctypes:Output/tctypes:Toworkflow_Data"/> 

<!-- <xsl:variable name="RT_SSD_COMPLIANCE_LABEL_COUNT_A2L" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_LABEL_COUNT_A2L']/tctypes:Value"/>
<xsl:variable name="RT_SSD_COMPLIANCE_A2L_ERROR" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_A2L_ERROR']/tctypes:Value"/>
<xsl:variable name="RT_SSD_COMPLIANCE_LABEL_FAILURE_COUNT" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_LABEL_FAILURE_COUNT']/tctypes:Value"/>
<xsl:variable name="RT_SSD_COMPLIANCE_CHECK_ERROR" select="tctypes:ToolOutput/tctypes:Output/tctypes:Results/tctypes:Data[child::tctypes:DataClassID='SSD_COMPLIANCE_CHECK_ERROR']/tctypes:Value"/> -->

</xsl:stylesheet>