<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
	<ToolInput>
		<Mode>Checkin Operation</Mode>
			<Input>
	<!-- Checkout=2 and check-in = 1 --> 
		<PDTDB_Mode>1</PDTDB_Mode>
			<Database>
				<xsl:call-template name="GetPDT_DB_Type"/>
			</Database>
		<ContainerName><xsl:call-template name="GetContainerName_PST_Lib"/></ContainerName>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"/></WorkingDirectory>
		 <Files>
		 <File>
				<FileClassID>CRITICAL_DATA_ACCESS_ULF</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_ULF'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_ULF'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
			<File>
				<FileClassID>CRITICAL_DATA_ACCESS_LST</FileClassID>
					<Name>
						<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
						</xsl:call-template>
						<xsl:value-of select="'\'"/>
						<xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="'CRITICAL_DATA_ACCESS_LST'"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							<xsl:with-param name="GetExtension" select="'yes'"/> 
						</xsl:call-template>
					</Name>
					<Optional>true</Optional>
			</File>	
		</Files>
       
		<Global_FileList>
			<xsl:call-template name="GetConfigFolder"/>
			<xsl:value-of select="'\Global_FileList.txt'"/>
		</Global_FileList>
		
		<SystemConstants>
			<Variables>
			<Variable><Name></Name>
			<Value></Value></Variable></Variables>
		</SystemConstants>
	</Input>
			<CallInformation>
				<ToolName></ToolName>
				<CallType></CallType>
				<ToolVersion></ToolVersion>
				<ToolLocation></ToolLocation>
				<InputVerification></InputVerification>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>