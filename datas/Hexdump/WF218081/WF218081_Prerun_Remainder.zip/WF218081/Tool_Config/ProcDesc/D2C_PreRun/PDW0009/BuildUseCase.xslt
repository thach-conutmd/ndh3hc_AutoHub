<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:output method="xml" omit-xml-declaration='yes' indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<xsl:template mode="myCopy" match="*">
		<xsl:element name="{name(.)}">
			<xsl:copy-of select="@*" />
			<xsl:apply-templates mode="myCopy" />
		</xsl:element>
	</xsl:template>
	<xsl:template match ="*" >
     <xsl:if test="not(local-name()='AddressLayoutModel')">
       <xsl:element name ="{local-name()}" >
         <xsl:apply-templates select ="@* | node() | cdata | text " />
       </xsl:element>
     </xsl:if>
   </xsl:template>

   <xsl:template match ="@*" >
     <xsl:attribute name ="{local-name()}" >    
       <xsl:value-of select ="."/>       
     </xsl:attribute>
     <xsl:apply-templates/>
   </xsl:template>

<xsl:template match="Data">
	
	<UseCase>
		<Data>
			<AppliedFile_Extension>1</AppliedFile_Extension>
			<PVER_PATH_FOR_TOOL_RUN></PVER_PATH_FOR_TOOL_RUN>
			<ECUSECU_FILE></ECUSECU_FILE>
			<MDG_Type></MDG_Type>
			<SSD_A2L></SSD_A2L>
			<SRV_A2L></SRV_A2L>
			<A2L_FILE_Extension>0</A2L_FILE_Extension>
			<FindSecurityInformation>0</FindSecurityInformation>
			<SRVChecker_Buggy_Scan_LST>1</SRVChecker_Buggy_Scan_LST>
			<BOOTCRL_VERSION_HEX>INTEGRATIONFILE</BOOTCRL_VERSION_HEX>
			<GUAM_FLAG>1</GUAM_FLAG>
			<ToolchainMode></ToolchainMode>
			<VCFileCount></VCFileCount>
			<FlashLayout></FlashLayout>
			<!-- Start - derived Values from Readmatrix-Modul - used as Branchmethod -->
			<Ignition></Ignition>
			<AddressLayout></AddressLayout>
			<WorkFlowID WorkFlowSystem="Flow5">
					<xsl:value-of select="//Data/WorkFlowID"/>
			</WorkFlowID>
			<LCT_Vorb_ECUNUM_SY>Master</LCT_Vorb_ECUNUM_SY>
			<!-- End - derived Values from Readmatrix-Modul - used as Branchmethod -->
					<JobType><xsl:value-of select="'D2P'" /></JobType>
				<ExecutionMode><xsl:value-of select="'Live'" /></ExecutionMode>
				<ToolChainPath><xsl:value-of select="//Data/ProgramFilesDirectory"/></ToolChainPath>
			<NumberOfInfoBlocks>
					<xsl:value-of select="//Data/NumberOfInfoBlocks"/>
				</NumberOfInfoBlocks>
			<AddressLayoutModel>
					<InfoBlockCount><xsl:value-of select="//Data/AddressLayoutModel/InfoBlockCount"/></InfoBlockCount>
				<FlashBlocks></FlashBlocks>
				<InfoBlocks></InfoBlocks>
				<InfoBlockLinks></InfoBlockLinks>
				<Compatibility></Compatibility>
				<ABMBlocks></ABMBlocks>
				<Ueko_MemCopy></Ueko_MemCopy>
				<InfoConfigRanges></InfoConfigRanges>
				<Blocks></Blocks>
			</AddressLayoutModel>
			<!--Copy <Data> node from parameter xml file to Usecase xml file  -->
			<xsl:apply-templates select="*" />
		
		</Data>
      <RunTimeInformation>
        <Files> 
			
		<File>
				<FileClassID>RESIZED_APPLIEDFILES</FileClassID>
				<FileClassName>RESIZED_APPLIEDFILES</FileClassName>
				<Location></Location>
			</File> 
			<File>
				<FileClassID>HEX_FILE_LIST</FileClassID>
				<FileClassName>HEX_FILE_LIST</FileClassName>
				<Location></Location>
			</File> 
			
       
	            <File>
	  <FileClassID>SSD_COMPLIANCE_CHECK</FileClassID>
	  <FileClassName>SSD_COMPLIANCE_CHECK</FileClassName>
	  <Location></Location>
	  </File>
	            <File>
	  <FileClassID>SSD_COMPLIANCE_REFERENCE</FileClassID>
	  <FileClassName>SSD_COMPLIANCE_REFERENCE</FileClassName>
	  <Location></Location>
	  </File>
	  
          <File>
            <FileClassID>SSD_COMPLIANCE_A2L</FileClassID>
            <FileClassName>SSD_COMPLIANCE_A2L</FileClassName>
            <Location></Location>
          </File>
         		  <File>
						<FileClassID>BIN_File</FileClassID>
						<FileClassName>BIN_File</FileClassName>
						<Location></Location>
					</File>
					<File>
						<FileClassID>VBF_Header_File_Checksum</FileClassID>
						<FileClassName>VBF_Header_File_Checksum</FileClassName>
						<Location></Location>
					</File>
          <File>
            <FileClassID>BIN_checksum_file</FileClassID>
            <FileClassName>BIN_checksum_file</FileClassName>
            <Location></Location>
          </File>
          <File>
            <FileClassID>Converted_VBF_File</FileClassID>
            <FileClassName>Converted_VBF_File</FileClassName>
            <Location></Location>
          </File>		  
          <File>
            <FileClassID>HexmodX_BootCtrl_Version_xml</FileClassID>
            <FileClassName>HexmodX_BootCtrl_Version_xml</FileClassName>
            <Location></Location>
          </File>
		  
			<File>
						<FileClassID>BIN_DECRYPTED</FileClassID>
						<FileClassName>BIN_DECRYPTED</FileClassName>
						<Location></Location>
					</File>	
					<File>
						<FileClassID>HexModX_IntegrationFile_withoutData</FileClassID>
						<FileClassName>HexModX_IntegrationFile_withoutData</FileClassName>
						<Location>
						</Location>
					</File>
        
		<File>
						<FileClassID>SRVCHECKER_TOOL</FileClassID>
						<FileClassName>SRVCHECKER_TOOL</FileClassName>
						<Location>
						</Location>
					</File>	  
          <File>
            <FileClassID>BOOTCTRL_HEX</FileClassID>
            <FileClassName>BOOTCTRL_HEX</FileClassName>
            <Location></Location>
          </File>
        </Files>
        <Datas>
			<Data>
				<DataClassID>BOOTCTRL_VERSION</DataClassID>
				<DataClassName>BOOTCTRL_VERSION</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>MODETYPE</DataClassID>
				<DataClassName>MODETYPE</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>XADDRESS</DataClassID>
				<DataClassName>XADDRESS</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>A2L_FILE_FLAG</DataClassID>
				<DataClassName>A2L_FILE_FLAG</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>SECURITY_VERSION_MAIL_MESSAGE</DataClassID>
				<DataClassName>SECURITY_VERSION_MAIL_MESSAGE</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>ECUSECU_VERSION</DataClassID>
				<DataClassName>ECUSECU_VERSION</DataClassName>
				<Value></Value>
			</Data>
			<Data>
				<DataClassID>IS_SECURITY_VERSION_VALID</DataClassID>
				<DataClassName>IS_SECURITY_VERSION_VALID</DataClassName>
				<Value></Value>
			</Data>
			
			<Data>
				<DataClassID>SCAN_LST_FLAG</DataClassID>
				<DataClassName>SCAN_LST_FLAG</DataClassName>
				<Value></Value>
			</Data>
			
			<Data>
				<DataClassID>A2L_FILE_Extension</DataClassID>
				<DataClassName>A2L_FILE_Extension</DataClassName>
				<Value></Value>
			</Data>
			
			<Data>
				<DataClassID>TOOL_LIST</DataClassID>
				<DataClassName>TOOL_LIST</DataClassName>
				<Tools></Tools>
			</Data>
			
          <Data>
            <DataClassID>OTP_Reference</DataClassID>
            <DataClassName>OTP Reference Value</DataClassName>
            <Value></Value>
          </Data>
          <Data>
            <DataClassID>OTP_RefCode</DataClassID>
            <DataClassName>OTP_RefCode</DataClassName>
            <Value></Value>
          </Data>		 
		   <Data>
            <DataClassID>Root_PST_Folder</DataClassID>
            <DataClassName>Root_PST_Folder</DataClassName>
            <Value></Value>
          </Data>
		  <Data>
            <DataClassID>SRVCHECKER_ERROR</DataClassID>
            <DataClassName>SRVCHECKER_ERROR</DataClassName>
            <Value></Value>
          </Data>
		  <Data>
            <DataClassID>SRVCHECKER_AFFECTED_LABEL_COUNT</DataClassID>
            <DataClassName>SRVCHECKER_AFFECTED_LABEL_COUNT</DataClassName>
            <Value></Value>
          </Data>
		  <Data>
            <DataClassID>SRVCHECKER_PVER_LABEL_COUNT</DataClassID>
            <DataClassName>SRVCHECKER_PVER_LABEL_COUNT</DataClassName>
            <Value></Value>
          </Data>
		  
		  <Data>
				    <DataClassID>VBF_DataBlock_Info</DataClassID>
				    <DataClassName>VBF_DataBlock_Info</DataClassName>
				    <VBF>
				    <Blocks>
					    <NumberOfBlocks>1</NumberOfBlocks>
					    <Block Number = "1" >
						    <StartAddress>000FF000</StartAddress>
						    <EndAddress>100000</EndAddress>
						    <Length>00001000</Length>
						    <Checksum>E0CA</Checksum>
					    </Block>
				    </Blocks>
				  </VBF>
			  </Data>
			   <Data>
            <DataClassID>VBF_File_Checksum</DataClassID>
            <DataClassName>VBF_File_Checksum</DataClassName>
            <Value></Value>
          </Data>
          <Data>
            <DataClassID>BIN_File_Checksum</DataClassID>
            <DataClassName>BIN_File_Checksum</DataClassName>
            <Value></Value>
          </Data>

			<Data>
				<DataClassID>Script_BIN_TO_HEX_CONVERSION</DataClassID>
				<DataClassName>Script_BIN_TO_HEX_CONVERSION</DataClassName>
				<Value/>
			</Data>		
			<Data>
				<DataClassID>Script_CHECKSUM_VALIDATION</DataClassID>
				<DataClassName>Script_CHECKSUM_VALIDATION</DataClassName>
				<Value/>
			</Data>
			<Data>
				<DataClassID>SRVChecker_LatestToolVersion</DataClassID>
				<DataClassName>SRVChecker_LatestToolVersion</DataClassName>
				<Value/>
			</Data>	
			<Data>
				<DataClassID>SRVCHECKER_PVER_TOOLVERSION</DataClassID>
				<DataClassName>SRVCHECKER_PVER_TOOLVERSION</DataClassName>
				<Value/>
			</Data>		
			<Data>
				<DataClassID>MergedConfig_ModeType_XPATH</DataClassID>
				<DataClassName>MergedConfig_ModeType_XPATH</DataClassName>
				<Value/>
			</Data>	
			<Data>
				<DataClassID>ECUSECU_Test_Feature_Addr</DataClassID>
				<DataClassName>ECUSECU_Test_Feature_Addr</DataClassName>
				<Value/>
			</Data>	
			<Data>
				<DataClassID>CFGEXP_MACHINE_TYPE</DataClassID>
				<DataClassName>CFGEXP_MACHINE_TYPE</DataClassName>
				<Value/>
			</Data> 
        </Datas>
        <ToWorkFlow> 

          <WorkFlowData>
            <WorkFlowID>OTP_Reference</WorkFlowID>
            <WorkFlowName>OTP_Reference</WorkFlowName>
            <Data>
              <DataClassID>Data</DataClassID>
              <DataClassName>SystemConstants.OTP_Reference</DataClassName>
              <DataValue></DataValue>
              <DataType></DataType>
            </Data>
          </WorkFlowData>
          <WorkFlowData>
	              <WorkFlowID>OTP_RefCode</WorkFlowID>
	              <WorkFlowName>OTP_RefCode</WorkFlowName>
	              <Data>
	                <DataClassID>Data</DataClassID>
	                <DataClassName>SystemConstants.OTP_RefCode</DataClassName>
	                <DataValue></DataValue>
	                <DataType></DataType>
	              </Data>
          </WorkFlowData>
        				<WorkFlowData>
					              <WorkFlowID>Pat_Inf_Workflow</WorkFlowID>
					              <WorkFlowName>Pat_Inf_Workflow</WorkFlowName>
					              <Data>
					                <DataClassID>File</DataClassID>
					                <DataClassName>Pat_Inf_Workflow</DataClassName>
					                <DataValue></DataValue>
					                <DataType>String</DataType>
					              </Data>
          </WorkFlowData>
		  <WorkFlowData>
										<WorkFlowID>Datalist_HW_Reference</WorkFlowID>
										<WorkFlowName>HW_Reference</WorkFlowName>
										<Data>
											<DataClassID>Data</DataClassID>
											<DataClassName>SystemConstants.HW_Reference</DataClassName>
												<!-- Default values for HW_reference -->
												<DataValue></DataValue>
											<DataType>String</DataType>
										</Data>
									</WorkFlowData>
									<WorkFlowData>
									<WorkFlowID>Datalist_Reference_Job</WorkFlowID>
										<WorkFlowName>Reference_Job</WorkFlowName>
										<Data>
											<DataClassID>Data</DataClassID>
											<DataClassName>SystemConstants.Reference_Job</DataClassName>
											<!-- Default values for Reference Job -->
											<DataValue></DataValue>
											<DataType>String</DataType>
										</Data>
									</WorkFlowData>
          
        </ToWorkFlow>
      </RunTimeInformation>
      <Log>
      </Log>
    </UseCase>

  </xsl:template>
</xsl:stylesheet>
