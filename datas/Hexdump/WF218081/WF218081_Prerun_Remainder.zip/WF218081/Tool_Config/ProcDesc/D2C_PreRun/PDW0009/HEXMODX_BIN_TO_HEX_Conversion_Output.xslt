<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				<ResultingFiles>
				<File>
						<FileClassID>BIN_TO_HEX</FileClassID>
						<FileClassName>BIN_TO_HEX</FileClassName>
						<Location>
							<Directory>
								<xsl:call-template name="GetWorkingDirectory"/>
							</Directory>
							<Name>
								<xsl:value-of select="'bintoHex.hex'"/>
							</Name>
						</Location>
					</File>
					
				</ResultingFiles>
			</Output>
			<ReturnInformation>
				<ReturnCode/>
				<TimeStart/>
				<TimeFinish/>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
