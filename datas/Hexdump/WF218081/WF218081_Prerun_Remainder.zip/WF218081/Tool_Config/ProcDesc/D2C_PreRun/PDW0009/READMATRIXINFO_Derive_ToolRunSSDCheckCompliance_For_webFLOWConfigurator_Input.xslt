 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
<!-- Parameter for Usecase-xml and PST-Libray -->
 <xsl:param name="PLibraryXML"/>
  <xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
    <Mode>Derive value for Tool Run SSD</Mode>
    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<DefaultValueMessage>Derive value for Tool Run SSD</DefaultValueMessage>
		<ConfigFile>
			<Name><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'TOOLRUN_SSDCHECK_FOR_CONFIGURATOR_MATRIX_NAME'"/></xsl:call-template></Name>
			<Directory>
			<!-- <xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'TOOLRUN_OPTION_MATRIX_PATH'"/></xsl:call-template> -->
				<xsl:call-template name="GetConfigFolder"></xsl:call-template>
				<xsl:value-of select="'\'" />
				</Directory>
		</ConfigFile>
		<Variables>  			
			<Variable>
				<Name>DeliveryType</Name>
				<Value>
					 <xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'DeliveryType_CF'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>ReleaseClass</Name>
				<Value>
					 <xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'ReleaseClass'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>ReleaseScope</Name>
				<Value>
					 <xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'ReleaseScope'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>Limitations</Name>
				<Value>
					<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'Limitations'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>SafetyMonitoring_SWbyRB</Name>
				<Value>
					<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'Safety_Monitoring_SW_by_RB'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>SafetyCalibrationResponsibility</Name>
				<Value>
					<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'SafetyCalibrationResponsibility'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>CalibrationResponsibility</Name>
				<Value>
					<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'CalibrationResponsibility'" />
					 </xsl:call-template>
				</Value>
			</Variable>
			<Variable>
				<Name>DataIntegrationResponsibility</Name>
				<Value>
					<xsl:call-template name="Data_Value">
						<xsl:with-param name="ID" select="'DataIntegrationResponsibility'" />
					 </xsl:call-template>
				</Value>
			</Variable>
		</Variables>  
		<LogFileAnalyser>
			<Files>
			</Files>
		</LogFileAnalyser>	
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
