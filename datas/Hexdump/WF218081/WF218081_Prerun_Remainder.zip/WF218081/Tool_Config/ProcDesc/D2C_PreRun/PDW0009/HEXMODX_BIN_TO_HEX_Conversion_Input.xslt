<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>Hexmodx - BIN to HEX Conversion </Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
					<Directory>
						<xsl:call-template name="GetWorkingDirectory">
						</xsl:call-template>
					</Directory>
					<Name>
						<xsl:value-of select="'BinToHex_Conversion.bsh'"/>
					</Name>
				</TargetTemplateFile>
				<Script>
					<xsl:call-template name="RunTime_Data_Value">
						<xsl:with-param name="DataClassID" select="'Script_BIN_TO_HEX_CONVERSION'"/>
					</xsl:call-template>
				</Script>
				<ScriptMandatory>1</ScriptMandatory>
				<Variables>
				<Variable>
					<Name>BINFILE</Name>
					<Value><xsl:call-template name="RunTime_FileList_GetFileName">
								<xsl:with-param name="FileClassID" select="'BIN_DECRYPTED'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
				</Variables>
				<CommandLine>
					<xsl:value-of select="'&quot;'" />
					<xsl:value-of select="'/'" />					
					<xsl:value-of select="'BinToHex_Conversion.bsh'"/>
					<xsl:value-of select="'&quot;'" />
				</CommandLine>
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
			<CallInformation>
				<ToolName>HEXMODX</ToolName>
				<CallType></CallType>
				<ToolVersion/>
				<ToolLocation>
					<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
				</ToolLocation>
				<InputVerification/>
			</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
