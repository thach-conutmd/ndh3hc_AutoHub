<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<xsl:template match="/">
		<ToolInput>
			<Mode>GetPVERArchivePathFromKlaudiaService</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
          <Directory/>
          <Name/>
        </TargetTemplateFile>
		 	<Script></Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				  <CommandLine></CommandLine>
				<CommandLines>
				<CommandLine>
				<!--
				parameter 1: Script path
				parameter 2: URL
                parameter 3: workingDirectory
				parameter 4: PVER source path
				parameter 5: ECUSecu file path to check existance-->
		 
		 <xsl:call-template name="GetWrapperPath"></xsl:call-template>
		          <xsl:value-of select="'\GetArchivePath.vbs'" />
		          <xsl:value-of select="' '" />
				  <xsl:value-of select="'&quot;'" />
		<!-- <xsl:value-of select="'https://rb-klaudia.bosch.com/KLAUDIA.svc/Archiver/ArchivedPath?ID_VALUE='" /> -->
              <xsl:call-template name="GetPVER_Label">
						<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param>
						</xsl:call-template>
						<xsl:call-template name="GetPVER_Label_FRA">
						<xsl:with-param name="File">
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
							<xsl:value-of select="'\AdapterParam.xml'" />
						</xsl:with-param>
						</xsl:call-template>
						<xsl:value-of select="'&quot;'" />
			  
		  <xsl:value-of select="' '" />
		  <xsl:value-of select="'&quot;'" />
		 <xsl:call-template name="GetWorkingDirectory"/>
		 <xsl:value-of select="'&quot;'" />
		 
		 <xsl:value-of select="' '" />
		   <xsl:value-of select="'&quot;'" />
          <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder">
                                                <xsl:with-param name="File">
                                                            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                            <xsl:value-of select="'\AdapterParam.xml'" />
                                                </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template>
                    <xsl:call-template name="Removelastbackslash">
                                    <xsl:with-param name="Path">

													<xsl:call-template name="GetRoot_PST_Folder_FRA">
                                                                                                <xsl:with-param name="File">
                                                                                                            <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                                                            <xsl:value-of select="'\AdapterParam.xml'" />
                                                                                                </xsl:with-param>
                                                </xsl:call-template>

                                                </xsl:with-param>
                                    </xsl:call-template>		
          <xsl:value-of select="'&quot;'" />
		<xsl:value-of select="' '" />
		
		 
		  <xsl:value-of select="'&quot;'" />         
			 <xsl:call-template name="GetWorkingDirectory"/>
			  <xsl:value-of select="'\rba_EcuSecu_EcucValues'"/>
							<xsl:call-template name="GetController_ID_Suffix"></xsl:call-template>
							<xsl:value-of select="'.arxml'"/>

          <xsl:value-of select="'&quot;'" />
		 <xsl:value-of select="' '" />
		  <xsl:value-of select="'&quot;'" />         
			 <xsl:call-template name="GetWorkingDirectory"/>
			  <xsl:value-of select="'\'"/>
			  <xsl:call-template name="GetWorkFlowID"/>
			  <xsl:value-of select="'_Prerun_Remainder.zip'"/>
          <xsl:value-of select="'&quot;'" />
		 
		 
          
       </CommandLine>
				

				</CommandLines>
				
			
				
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
		
    <CallInformation>
		<ToolName>KlaudiaService_VBSScript</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation> 
		 <Directory> <xsl:call-template name="GetWrapperPath"></xsl:call-template></Directory>
          <Name>GetArchivePath.bat</Name>
    </ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>
