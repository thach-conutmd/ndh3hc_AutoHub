<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	
	
	<xsl:template match="/">
		<ToolInput>
			<Mode>Create Remainder Zip</Mode>
			<Input>
				<SourceTemplateFile>
					<Directory/>
					<Name/>
				</SourceTemplateFile>
				<TargetTemplateFile>
          <Directory/>
          <Name/>
        </TargetTemplateFile>
				<Script></Script>
				<ScriptMandatory>0</ScriptMandatory>
				<Variables/>
				  <CommandLine></CommandLine>
				<CommandLines>
				<CommandLine>
         	     <xsl:value-of select="' a -tzip '" /> 
         	     <xsl:value-of select="'-xr@'" />
			   <xsl:call-template name="GetWorkingDirectory"/>
			  <xsl:value-of select="'\'"/>
			  <xsl:call-template name="Data_Value">
			  	<xsl:with-param name="ID" select="'Remainder_ExcludeFilesListName'" />
			  </xsl:call-template>
			   <xsl:value-of select="' '" /> 
			  <xsl:call-template name="GetWorkingDirectory"/>
			  <xsl:value-of select="'\'"/>
			  <xsl:call-template name="GetWorkFlowID"/>
			  <xsl:value-of select="'_Prerun_Remainder.zip'"/>
		  <xsl:value-of select="' '" />
		  <xsl:call-template name="GetWorkingDirectory"/>
            	
			
       </CommandLine>
				

				</CommandLines>
				
			
				
				<LogFileAnalyser>
				</LogFileAnalyser>
			</Input>
		
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation> 
		 <Directory>
		
		  <xsl:value-of select="'C:\Program Files\7-Zip'" /> 
			    </Directory>
          <Name>
		  <xsl:value-of select="'7z.exe'" /> 
			 </Name>
    </ToolLocation>
		<InputVerification></InputVerification>
	</CallInformation>
		</ToolInput>
	</xsl:template>
</xsl:stylesheet>