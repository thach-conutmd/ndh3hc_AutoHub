<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

 <!-- Parameter for Usecase-xml file -->
 <xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 
 
  <xsl:variable name="RT_SRVCHECKER_ERROR" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECK_SRVCHECKER_ERROR']/tctypes:Value"/>
  <xsl:variable name="RT_SRVCHECKER_PVER_LABEL_COUNT" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECK_PVER_LABEL_COUNT']/tctypes:Value"/>
  <xsl:variable name="RT_SRVCHECKER_AFFECTED_LABEL_COUNT" select="tctypes:ToolOutput/tctypes:Output/tctypes:Scripts/tctypes:Item[child::tctypes:ID='CHECK_AFFECTED_LABEL_COUNT']/tctypes:Value"/>
 
 
 
</xsl:stylesheet>