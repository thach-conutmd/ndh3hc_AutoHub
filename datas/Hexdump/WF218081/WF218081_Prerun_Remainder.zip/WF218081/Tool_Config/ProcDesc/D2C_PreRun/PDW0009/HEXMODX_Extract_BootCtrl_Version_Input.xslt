 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

<xsl:template match="/">

    <ToolInput>
    <Mode>HexModX - Extract Boot Ctrl version from Integration Hex </Mode>

    <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>PatchCheckXML</Module>					
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_EXTRACT_BOOTCTRL_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_EXTRACT_BOOT_CTRL_VERSION_MAIN_XML'"/></xsl:call-template></Script>
     		<Variables>
 				<Variable>
					<Name>HEXMOD_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_EXTRACT_BOOTCTRL_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMOD_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_EXTRACT_BOOTCTRL_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>			   
			    <Variable>
					<Name>HEXMOD_VIEW_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_EXTRACT_BOOTCTRL_VIEW_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>				
			</Variables>
       	</MainXML>
     		
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_EXTRACT_BOOTCTRL_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_EXTRACT_BOOT_CTRL_VERSION_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value><xsl:call-template name="RunTime_FileListGeneral_GetFileDirectory">
								<xsl:with-param name="FileClassID" select="'BOOTCTRL_HEX'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template>
								<xsl:value-of select="'\'"/>
								<xsl:call-template name="RunTime_FileListGeneral_GetFileName">
								<xsl:with-param name="FileClassID" select="'BOOTCTRL_HEX'"/>
								<xsl:with-param name="GetValue" select="'yes'"/> 
								</xsl:call-template></Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>
					<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'MODETYPE'" />
						</xsl:call-template>           
					</Value>
				</Variable>
 			</Variables>     		   	
		</InputXML>
		
		<!-- PatchCheck - Config -->
     	<PatchCheckXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_EXTRACT_BOOTCTRL_VIEW_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_EXTRACT_BOOT_CTRL_VERSION_VIEW_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>SB_STARTADDRESS</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'XADDRESS'" />
						</xsl:call-template>           
					</Value>
				</Variable>
				<Variable>
					<Name>RESULTXMLFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\BOOTCTRL_Version.xml'"/></Value>
				</Variable>
				<Variable>
					<Name>CONTENTID</Name>
					<Value><xsl:value-of select="'0x0080'"/></Value>
				</Variable>
			</Variables>      			
		</PatchCheckXML>
     	
 	<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_EXTRACT_BOOTCTRL_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
				<File>
					<Classification>Hexmod17-Patch-Logfile</Classification>
					<Key>HEXMOD17_PATCHCHECK_LOGFILE</Key>
					<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
					<Name><xsl:value-of select="'BOOTCTRL_Version.xml'"/></Name>
				</File>
			</Files>
		</LogFileAnalyser>	
		<PST_Library>
		</PST_Library>	
    </HexModeInput>  
    <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
					<xsl:call-template name="RunTime_Tool_Path">
						<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
					</xsl:call-template>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
