<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainExtractionLib.xslt"/>
<xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
<xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
cdata-section-elements="Key SearchExpression"/>
<xsl:preserve-space elements="*"/>

<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

    <xsl:template match="/">
    <ToolInput>
		<Mode>Copy ECU Secu file from PVER to working directory</Mode>
	   	<Input>
			<CopyList>
				<Entry>
					<SourceFile>
						<Directory>

								<xsl:call-template name="GetECUSECU_File_Directory">
                                                    <xsl:with-param name="File">
                                                                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                <xsl:value-of select="'\AdapterFilelist.xml'" />
                                                    </xsl:with-param>
                                                </xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'\'" /><xsl:call-template name="GetECUSECU_FileName">
                                                    <xsl:with-param name="File">
                                                                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                <xsl:value-of select="'\AdapterFilelist.xml'" />
                                                    </xsl:with-param>
                                                </xsl:call-template></Name>
					</SourceFile>
					<TargetFile>
						<Directory>
							<xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
						</Directory>
						<Name><xsl:value-of select="'\'" />
							<xsl:call-template name="GetECUSECU_FileName">
                                                    <xsl:with-param name="File">
                                                                <xsl:call-template name="GetWorkingDirectory"></xsl:call-template>
                                                                <xsl:value-of select="'\AdapterFilelist.xml'" />
                                                    </xsl:with-param> 
                                                </xsl:call-template>
						</Name>
					</TargetFile>
					<OverwriteTarget>1</OverwriteTarget>
					<DeleteSource>0</DeleteSource>
				</Entry>
				
			</CopyList>
		</Input>   		
   		<CallInformation>
			<ToolName></ToolName>
			<CallType></CallType>
			<ToolVersion></ToolVersion>
			<ToolLocation>
			</ToolLocation>
			<InputVerification></InputVerification>
		</CallInformation>			  
   	</ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
