<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns="http://de.bosch.com/gs/tctypes"
xmlns:tctypes="http://de.bosch.com/gs/tctypes">
<xsl:import href="ToolChainWriteBackLib.xslt"/>

<!-- Parameter for Usecase-xml file -->
<xsl:param name="PUseCaseXML"/>
  
 <xsl:output method="xml"/>
 <xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="RT_PVER_PATH" select="tctypes:ToolOutput/tctypes:Output/tctypes:Variables/tctypes:Variable[child::tctypes:Name='Path']/tctypes:Value"/>
 <xsl:variable name="RT_ECU_SECU_FILE" select="tctypes:ToolOutput/tctypes:Output/tctypes:Variables/tctypes:Variable[child::tctypes:Name='Flag_ECU_Secu']/tctypes:Value"/>
   
</xsl:stylesheet>