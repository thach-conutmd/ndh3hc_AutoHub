<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tcmed17types="http://de.bosch.com/gs/tctypes">
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:import href="ToolChainEnvironmentExtraction.xslt" />
	<xsl:output method="xml" indent="yes" cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!-- Parameter for Usecase-xml and PST-Libray -->
	<xsl:param name="PLibraryXML" />
	<xsl:param name="PUseCaseXML" />
	<!-- Variables for UsecaseData and Libraryfile -->
	<xsl:variable name="LibraryXML" select="$PLibraryXML" />
	<xsl:variable name="UseCaseXML" select="$PUseCaseXML" />
	<!-- To decide SCAN_LST_FLAG. 1 = TRUE, 0 = FALSE -->	
	<xsl:variable name="ScanLSTFlag">
		 <xsl:call-template name="RunTime_Data_Value">
			 <xsl:with-param name="DataClassID" select="'SCAN_LST_FLAG'" />
		 </xsl:call-template>
	 </xsl:variable>
	<xsl:template match="/">
	
		<ToolOutput xmlns="http://de.bosch.com/gs/tctypes">
			<Output>
				 </Output>
			<ReturnInformation>
				<ReturnCode/>
				<TimeStart/>
				<TimeFinish/>
				<ErrorInformation>
					<ErrorNumber />
					<ErrorMessage />
				</ErrorInformation>
			</ReturnInformation>
		</ToolOutput>
	</xsl:template>
</xsl:stylesheet>
