rem Creates LT_Success text file at two folders up, overwrite the file if it already exists.\\
SET WorkingDir=%~dp0..\..\..\
ECHO SUCCESS > %WorkingDir%\LT_Success.txt
