 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression PED_RSA_SCRIPT ScriptTemplate"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>

 <xsl:variable name="WorkingDir" select="/tctypes:UseCase/tctypes:Data/tctypes:WorkingDirectory" />
<xsl:variable name="HexmodOutputFile"  select="concat($WorkingDir, '\Hexmodx_DATA_Value.xml')" />
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','Lib_EcuSecu_Series_Test_Feature.xml')" /> 

<xsl:template match="/">

    <ToolInput>
    <Mode>Script to Derive Test Series Flag</Mode>

    <Input>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Scripts>
			<Script>
										<Write2PSTLib>False</Write2PSTLib>
										<Key>TEST_SERIES_FLAG</Key>
										<Comment>Script to Derive GUAM Hex version </Comment>
										<ScriptTemplate>
											<xsl:call-template name="GetEnvironmentValue">
												<xsl:with-param name="LookUpItem" select="'SCRIPT_DERIVE_ECUSECU_TEST_SERIES_FLAG'" />
											</xsl:call-template>
										</ScriptTemplate>
										<DataBase>										
											<xsl:call-template name="GetXMLFromFile">
												<xsl:with-param  name="File"  select="$HexmodOutputFile" />
											</xsl:call-template>
										</DataBase>
			</Script>
				
		</Scripts>
		<PST_Library>
		</PST_Library>
    </Input>  
    <CallInformation>
		<ToolName></ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
		</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
