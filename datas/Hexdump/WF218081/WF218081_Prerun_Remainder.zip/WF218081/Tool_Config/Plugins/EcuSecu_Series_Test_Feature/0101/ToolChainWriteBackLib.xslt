<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes"
	xmlns:tctypes="http://de.bosch.com/gs/tctypes">      
	<xsl:import href="ToolChainExtractionLib.xslt" />
	<xsl:output method="xml" omit-xml-declaration='yes' cdata-section-elements="Key SearchExpression" />
	<xsl:preserve-space elements="*" />
	<!--
		Main Idea: Walk through the toolchain's data step by step. Copy each node using default-rules.
		Some parts of the toolchain's data can be overwritten without any knowledge about the internal
		structure.
		For each part there exist two variables:
		- The first has to be used by the calling stylesheet. It is prefixed by either "UC" (UseCase)
		  or "RT" (RunTime). It is initialized empty in this basic library. A calling stylesheet can
		  overwrite this initial value.
		- Correspondig to this externally used variable we have an internal reference. It is prefixed 
		  "REF" and contains an XPATH. This XPATH describes the part to be replaced.	
	    On principle it is assumed that in the toolchain's data the part to be overwritten already exists
	    It may be empty but it should exist. Occasionally it could be possible to newly introduce data.
	  
	    The Stylesheet calling this library only has 
		- to provide XPATHs for the variables mentioned abobve to be used for extracting data from the 
		  tool output 
		It is not necessary to call any template. This is done within the library.				
  -->

	<!-- Path to the toolchain's data file                        -->
	<xsl:variable name="UseCaseXML" select="''" />
	<!-- Variables to be used by the calling stylesheet(s)    -->
	
	<xsl:variable name="RT_ECUSECU_Test_Feature_Addr" select="''"/>
	   
   

	<xsl:variable name="Ref_ECUSECU_Test_Feature_Addr" select="document($UseCaseXML)/tctypes:UseCase/tctypes:RunTimeInformation/tctypes:Datas/tctypes:Data[child::tctypes:DataClassID='ECUSECU_Test_Feature_Addr']/tctypes:Value"/>

  <!-- Starting point -->
	<xsl:template match="/">
		<xsl:call-template name="WriteBack" />
	</xsl:template>
	<!-- The initial template. Starts processing of the toolcahin's data -->
	<xsl:template name="WriteBack">
		<xsl:apply-templates select="document($UseCaseXML)/*" />
	</xsl:template>
	<!-- recurcively step throug the toolchain's data -->
	<xsl:template match="*">
		<xsl:choose>
			
			
		<xsl:when test="count(. | $Ref_ECUSECU_Test_Feature_Addr)=1 and $RT_ECUSECU_Test_Feature_Addr">
			<xsl:element name="Value">
			<xsl:value-of select="$RT_ECUSECU_Test_Feature_Addr"/>
		</xsl:element>
	</xsl:when>	
	
			<xsl:otherwise>
				<xsl:element name="{name()}">
					<xsl:apply-templates select="@*" />
					<xsl:apply-templates />
				</xsl:element>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>       
	<xsl:template match="@*">
		<xsl:choose>
			<xsl:when test="false"/>
			<xsl:otherwise>
				<xsl:attribute name="{name()}">
					<xsl:value-of select="." />
				</xsl:attribute>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>
