 <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://de.bosch.com/gs/tctypes" xmlns:tctypes="http://de.bosch.com/gs/tctypes">
 <xsl:import href="ToolChainExtractionLib.xslt"/>
  <xsl:import href="ToolChainEnvironmentExtraction.xslt"/>
 <xsl:output method="xml" omit-xml-declaration='yes' indent="yes"
 cdata-section-elements="Key SearchExpression"/>
 <xsl:preserve-space elements="*"/>
 
<!-- Parameter for Usecase-xml and PST-Libray -->
<xsl:param name="PLibraryXML"/>
<xsl:param name="PUseCaseXML"/>
<xsl:param name="PInputFileClassID_InputHex_File"/>
  <xsl:param name="PCurrentXSLTDir">.</xsl:param>

<!-- Variables for UsecaseData and Libraryfile -->
<xsl:variable name="LibraryXML" select="$PLibraryXML"/>
<xsl:variable name="UseCaseXML" select="$PUseCaseXML"/>
 <xsl:variable name="PlugInLibraryXML" select="concat($PCurrentXSLTDir,'/','Lib_EcuSecu_Series_Test_Feature.xml')" />  
<xsl:variable name="InputFileClassID_InputHex_File" select="$PInputFileClassID_InputHex_File"/>

<xsl:template match="/">

    <ToolInput>
    <Mode>HexModX - Read Data from Hex file </Mode>
    <HexModeInput>
		<WorkingDirectory><xsl:call-template name="GetWorkingDirectory"></xsl:call-template></WorkingDirectory>
		<Modules>
			<Module>MainXML</Module>
			<Module>InputXML</Module>
			<Module>PatchCheckXML</Module>				
		</Modules>
		<!-- Main - Config -->
     	<MainXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HexMod_Read_Data_Main_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_DATA_MAIN_XML'"/></xsl:call-template></Script>
     		<Variables>
 				<Variable>
					<Name>HEXMODX_MAIN_LOGFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_DATA_LOG_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.LOG'"/></Value>
				</Variable>
			    <Variable>
					<Name>HEXMODX_INPUT_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_DATA_INPUT_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>			   
			    <Variable>
					<Name>HEXMODX_PATCHCHECK_XML_NAME</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"></xsl:call-template><xsl:value-of select="'\HEXMOD_READ_DATA_PATCHCHECK_'"/><xsl:call-template name="GetWorkFlowID">
								</xsl:call-template><xsl:value-of select="'.XML'"/></Value>
				</Variable>							
			</Variables>
       	</MainXML>
     		
     	<!-- Input Config-->
     	<InputXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_READ_DATA_INPUT_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_DATA_INPUT_XML'"/></xsl:call-template></Script>
     		<Variables>
    			<Variable>
					<Name>HEXFILE</Name>
					<Value>
							<xsl:call-template name="RunTime_FileList_GetFileDirectory" >
							<xsl:with-param name="FileClassID" select="$InputFileClassID_InputHex_File"/>
							<xsl:with-param name="GetValue" select="'yes'"/> 
							</xsl:call-template>
							<xsl:value-of select="'\'"/><xsl:call-template name="RunTime_FileList_GetFileName" >
							<xsl:with-param name="FileClassID" select="$InputFileClassID_InputHex_File"/>
							<xsl:with-param name="GetValue" select="'yes'"/>
							</xsl:call-template>
					</Value>
				</Variable>
       			<Variable>
					<Name>FILETYPE</Name>				
					<Value><xsl:call-template name="GetEnvironmentValue">
					<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>
				<Variable>
					<Name>MODETYPE</Name>						
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
							<xsl:with-param name="DataClassID" select="'MODETYPE'" />
						</xsl:call-template>           
					</Value>
				</Variable>
 			</Variables>     		   	
		</InputXML>
		
		<!-- PatchCheck - Config -->
     	<PatchCheckXML>
     		<TemplateFile>
     			<Directory><xsl:call-template name="GetWorkingDirectory">
								</xsl:call-template></Directory>
     			<Name><xsl:value-of select="'HEXMOD_READ_DATA_PATCHCHECK_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>.xml</Name>
     		</TemplateFile>
     		<Script><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMODX_READ_DATA_PATCHANDCHECK_XML'"/></xsl:call-template></Script>
     		<Variables>
				<Variable>
					<Name>ADDRESS</Name>
					<Value>
						<xsl:call-template name="RunTime_Data_Value">
										<xsl:with-param name="DataClassID" select="'ECUSECU_Test_Feature_Addr'"/>
									</xsl:call-template></Value>

				</Variable>	
				<Variable>
					<Name>FILETYPE</Name>				
				<Value><xsl:call-template name="GetEnvironmentValue">
				<xsl:with-param name="LookUpItem" select="'HEXMOD_FILETYPE'"/></xsl:call-template></Value>
				</Variable>			
				<Variable>
					<Name>RESULTXMLFILE</Name>
					<Value><xsl:call-template name="GetWorkingDirectory"/><xsl:value-of select="'\Hexmodx_DATA_Value.xml'"/></Value>
				</Variable>
			</Variables>      			
		</PatchCheckXML>     	
 	<LogFileAnalyser>
			<Files>
				<File>
				<Classification>Hexmod17-Main-Logfile</Classification>
				<Key>HEXMOD17_MAIN</Key>
				<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
				<Name><xsl:value-of select="'HEXMOD_READ_DATA_LOG_'"/>
								<xsl:call-template name="GetWorkFlowID">
								</xsl:call-template>
								<xsl:value-of select="'.LOG'"/></Name>
				</File>
				<File>
					<Classification>Hexmod17-Patch-Logfile</Classification>
					<Key>HEXMOD17_PATCHCHECK_LOGFILE</Key>
					<Directory><xsl:call-template name="GetWorkingDirectory">
							</xsl:call-template></Directory>
					<Name><xsl:value-of select="'Hexmodx_DATA_Value.xml'"/></Name>
				</File>
			</Files>
		</LogFileAnalyser>	
		<PST_Library>
		</PST_Library>	
    </HexModeInput>  
   <CallInformation>
		<ToolName>HEXMODX</ToolName>
		<CallType></CallType>
		<ToolVersion></ToolVersion>
		<ToolLocation>
			<xsl:call-template name="RunTime_Tool_Path">
				<xsl:with-param name="ToolName" select="'HEXMODXVERSION'"/>
			</xsl:call-template>
			</ToolLocation>
		<InputVerification></InputVerification>
	 </CallInformation>
     </ToolInput>     	
   </xsl:template>
</xsl:stylesheet>
