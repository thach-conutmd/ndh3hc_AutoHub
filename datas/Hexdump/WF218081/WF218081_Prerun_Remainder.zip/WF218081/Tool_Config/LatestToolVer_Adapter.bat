rem tbexcmd -useEnv:dgs -command EnableTool %1/*
tbexcmd -useEnv:dgs -command EnableTool pdt_adapter/v5.2.6
tbupdate -e

rem  texec %1/latest >%2
