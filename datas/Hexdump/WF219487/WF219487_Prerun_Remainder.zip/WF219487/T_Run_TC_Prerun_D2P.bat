START /WAIT "TC_SRL" "C:\toolbase\pdt_toolchain\1v72.1\ToolChain.exe"  -CS "|C:\temp\PDT\JAP\MDG1\Prerun_Toolchain\PreRun\MG1CS022\WF219487\P_Run_TC_Prerun_D2P.xml|"

